--[[---------------------------------------------------------
	V-City LVS: настройка положения кресел
	Часть 1 (общая): схема конфига, ключи кресел, помощники.

	Конфиг: data/vcity_rp/lvs_seats.json
	Ключ машины: имя класса (например lvs_wheeldrive_...),
	запасной ключ — путь к модели.
	Ключи кресел: "driver" (pod 1), "p2", "p3", ... (pod N).
	Наводчик — пассажирское кресло, к которому привязано оружие
	(в списке команд помечено «[оружие]»).
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}
VCityLVS.SeatFile = "vcity_rp/lvs_seats.json"
VCityLVS.SeatConfig = VCityLVS.SeatConfig or { version = 1, vehicles = {} }

-- "driver"/"1"/"d" -> "driver"; "2"/"p2"/"passenger4" -> "p2"/"p4"
function VCityLVS.SeatKey(str)
	if not str then return nil end
	str = string.lower(tostring(str):gsub("^%s+", ""):gsub("%s+$", ""))

	if str == "driver" or str == "d" or str == "1" then return "driver" end

	local n = tonumber(str) or tonumber(string.match(str, "^p?%a*_?(%d+)$") or "")
	if n and n >= 2 and n == math.floor(n) then return "p" .. n end

	return nil
end

-- Индекс пода -> ключ ("driver" = 1)
function VCityLVS.SeatKeyByIndex(index)
	if not isnumber(index) then return nil end
	if index == 1 then return "driver" end
	if index >= 2 then return "p" .. index end
	return nil
end

-- JSON {pos={x,y,z}, ang={p,y,r}} -> Vector, Angle; недостающее — из значений по умолчанию
function VCityLVS.ApplyOverride(ov, defPos, defAng)
	local pos, ang = defPos, defAng

	if istable(ov) and istable(ov.pos) and tonumber(ov.pos[1]) and tonumber(ov.pos[2]) and tonumber(ov.pos[3]) then
		pos = Vector(tonumber(ov.pos[1]), tonumber(ov.pos[2]), tonumber(ov.pos[3]))
	end

	if istable(ov) and istable(ov.ang) and tonumber(ov.ang[1]) and tonumber(ov.ang[2]) and tonumber(ov.ang[3]) then
		ang = Angle(tonumber(ov.ang[1]), tonumber(ov.ang[2]), tonumber(ov.ang[3]))
	end

	return pos, ang
end

function VCityLVS.PackPosAng(pos, ang)
	return {
		pos = { math.Round(pos.x, 2), math.Round(pos.y, 2), math.Round(pos.z, 2) },
		ang = { math.Round(ang.p, 2), math.Round(ang.y, 2), math.Round(ang.r, 2) },
	}
end

-- Форматирование для вывода в чат/консоль
function VCityLVS.FormatPosAng(pos, ang)
	return string.format("pos(%.1f, %.1f, %.1f) ang(%.1f, %.1f, %.1f)", pos.x, pos.y, pos.z, ang.p, ang.y, ang.r)
end

-- Поиск записи конфига: класс, иначе модель
function VCityLVS.FindVehicleEntry(ent)
	if not IsValid(ent) then return nil, nil end
	local vehicles = VCityLVS.SeatConfig and VCityLVS.SeatConfig.vehicles or {}

	local class = ent:GetClass()
	if istable(vehicles[class]) then return vehicles[class], class end

	local model = ent:GetModel()
	if isstring(model) and istable(vehicles[model]) then return vehicles[model], model end

	return nil, class
end

if SERVER then
	---------------------------------------------------------
	-- Часть 2 (сервер): загрузка/сохранение JSON
	---------------------------------------------------------

	local function LoadSeatConfig()
		file.CreateDir("vcity_rp")

		local raw = file.Read(VCityLVS.SeatFile, "DATA")
		if not raw or raw == "" then
			VCityLVS.SeatConfig = { version = 1, vehicles = {} }
			print("[V-City LVS] Конфиг кресел не найден, начинаем с пустого: data/" .. VCityLVS.SeatFile)
			return
		end

		local parsed = util.JSONToTable(raw)
		if not istable(parsed) or not istable(parsed.vehicles) then
			print("[V-City LVS] Ошибка чтения data/" .. VCityLVS.SeatFile .. " — работаю с пустым конфигом.")
			VCityLVS.SeatConfig = { version = 1, vehicles = {} }
			return
		end

		VCityLVS.SeatConfig = parsed
		local count = 0
		for _ in pairs(parsed.vehicles) do count = count + 1 end
		print("[V-City LVS] Загружен конфиг кресел: машин в нём — " .. count)
	end

	local function SaveSeatConfig()
		file.CreateDir("vcity_rp")
		file.Write(VCityLVS.SeatFile, util.TableToJSON(VCityLVS.SeatConfig, true))
		print("[V-City LVS] Конфиг кресел записан: data/" .. VCityLVS.SeatFile)
	end

	VCityLVS.SaveSeatConfig = SaveSeatConfig

	LoadSeatConfig()
	concommand.Add("vcity_rp_lvs_seat_reload", function(ply)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		LoadSeatConfig()
		if IsValid(ply) then ply:ChatPrint("[V-City LVS] Конфиг кресел перечитан.") end
	end)

	---------------------------------------------------------
	-- Часть 3 (сервер): обёртка AddDriverSeat / AddPassengerSeat
	---------------------------------------------------------

	local patched = {}

	-- Живая перестановка пода: отвязать -> в мир -> привязать.
	-- Движок не тестировался; вариант с повторным SetParent — самый надёжный из известных.
	local function MovePod(pod, veh, pos, ang)
		if not IsValid(pod) or not IsValid(veh) then return false end

		pod:SetParent(NULL)
		pod:SetPos(veh:LocalToWorld(pos))
		pod:SetAngles(veh:LocalToWorldAngles(ang))
		pod:SetParent(veh)

		return true
	end

	VCityLVS.MovePod = MovePod

	-- Машина под прицелом (или та, в которой сидит игрок)
	function VCityLVS.TraceVehicle(ply)
		if not IsValid(ply) then return NULL end

		local driven = ply.lvsGetVehicle and ply:lvsGetVehicle()
		if IsValid(driven) then return driven end

		local ent = ply:GetEyeTrace().Entity
		if not IsValid(ent) then return NULL end

		if ent.GetDriverSeat then return ent end

		-- под (сиденье) -> его машина
		local parent = ent:GetParent()
		if IsValid(parent) and parent.GetDriverSeat then return parent end

		local owner = ent:GetOwner()
		if IsValid(owner) and owner.GetDriverSeat then return owner end

		return NULL
	end

	-- Список подов машины
	function VCityLVS.ListSeats(veh)
		local out = {}
		if not IsValid(veh) then return out end

		local entries = {}

		local driver = veh.GetDriverSeat and veh:GetDriverSeat()
		if IsValid(driver) then
			table.insert(entries, { pod = driver, key = "driver", index = 1 })
		end

		if istable(veh.pSeats) then
			for _, pod in ipairs(veh.pSeats) do
				if IsValid(pod) then
					local index = pod:lvsGetPodIndex() or (#entries + 1)
					table.insert(entries, { pod = pod, key = VCityLVS.SeatKeyByIndex(index), index = index })
				end
			end
		end

		local configEntry = VCityLVS.FindVehicleEntry(veh)

		for _, e in ipairs(entries) do
			local pos = e.pod:GetPos()
			local localPos = IsValid(veh) and veh:WorldToLocal(pos) or pos
			local localAng = IsValid(veh) and veh:WorldToLocalAngles(e.pod:GetAngles()) or e.pod:GetAngles()

			local isGun = false
			if istable(veh.WEAPONS) and istable(veh.WEAPONS[e.index]) and next(veh.WEAPONS[e.index]) ~= nil then
				isGun = true
			end

			local overridden = istable(configEntry) and istable(configEntry[e.key])

			table.insert(out, {
				key = e.key,
				index = e.index,
				pos = localPos,
				ang = localAng,
				gun = isGun,
				overridden = overridden or false,
				pod = e.pod,
			})
		end

		return out
	end

	-- Обёртка методов кресел. Патчим только те таблицы классов,
	-- где метод определён (rawget): наследники найдут обёртку через
	-- цепочку BaseClass. Патч идемпотентен.
	local function PatchClass(tbl)
		if not istable(tbl) or patched[tbl] then return end
		patched[tbl] = true

		local rawDriver = rawget(tbl, "AddDriverSeat")
		if isfunction(rawDriver) then
			tbl.AddDriverSeat = function(self, pos, ang)
				local entry = VCityLVS.FindVehicleEntry(self)
				local ov = entry and entry["driver"]
				if istable(ov) then
					pos, ang = VCityLVS.ApplyOverride(ov, pos, ang)
				end
				return rawDriver(self, pos, ang)
			end
		end

		local rawPass = rawget(tbl, "AddPassengerSeat")
		if isfunction(rawPass) then
			tbl.AddPassengerSeat = function(self, pos, ang)
				-- Индекс следующего пода считаем так же, как сам LVS
				-- (pPodKeyIndex стартует с 2 и растёт на единицу)
				local nextIndex = self.pPodKeyIndex and (self.pPodKeyIndex + 1) or 2
				local key = VCityLVS.SeatKeyByIndex(nextIndex)
				local entry = VCityLVS.FindVehicleEntry(self)
				local ov = key and entry and entry[key]
				if istable(ov) then
					pos, ang = VCityLVS.ApplyOverride(ov, pos, ang)
				end
				return rawPass(self, pos, ang)
			end
		end
	end

	function VCityLVS.PatchAllSeatMethods()
		local list = scripted_ents.GetList()
		if istable(list) then
			for _, tbl in pairs(list) do
				if istable(tbl) then
					PatchClass(tbl)
				end
			end
		end

		local stored = scripted_ents.GetStored("lvs_base")
		if istable(stored) and istable(stored.t) then
			PatchClass(stored.t)
		end
	end

	-- До спавна любой карты/машины: Initialize идёт после загрузки всех аддонов
	hook.Add("Initialize", "VCityLVS.PatchSeats", function()
		VCityLVS.PatchAllSeatMethods()
	end)

	hook.Add("InitPostEntity", "VCityLVS.PatchSeatsLate", function()
		VCityLVS.PatchAllSeatMethods()
	end)

	-- На случай autorefresh/поздней загрузки
	VCityLVS.PatchAllSeatMethods()

	---------------------------------------------------------
	-- Часть 4 (сервер): команды
	---------------------------------------------------------

	local function Say(ply, msg)
		if IsValid(ply) then
			ply:ChatPrint("[V-City LVS] " .. msg)
		else
			print("[V-City LVS] " .. msg)
		end
	end

	local function Allowed(ply)
		if not IsValid(ply) then return true end
		if not ply:IsSuperAdmin() then
			Say(ply, "Команда доступна только суперадминам.")
			return false
		end
		return true
	end

	local function GetSeat(veh, key)
		local seats = VCityLVS.ListSeats(veh)
		for _, s in ipairs(seats) do
			if s.key == key then return s end
		end
		return nil
	end

	local function EnsureEntry(veh)
		local entry, key = VCityLVS.FindVehicleEntry(veh)
		if entry then return entry, key end

		key = veh:GetClass()
		VCityLVS.SeatConfig.vehicles[key] = VCityLVS.SeatConfig.vehicles[key] or {}
		return VCityLVS.SeatConfig.vehicles[key], key
	end

	concommand.Add("vcity_rp_lvs_seats", function(ply)
		if not Allowed(ply) then return end

		local veh = VCityLVS.TraceVehicle(ply)
		if not IsValid(veh) then
			Say(ply, "Не вижу LVS-машины: сядьте в неё или наведите прицел.")
			return
		end

		local _, configKey = VCityLVS.FindVehicleEntry(veh)
		Say(ply, "Машина: " .. veh:GetClass() .. " (ключ конфига: " .. tostring(configKey) .. ")")

		local seats = VCityLVS.ListSeats(veh)
		if #seats == 0 then
			Say(ply, "У машины не найдено кресел.")
			return
		end

		for _, s in ipairs(seats) do
			Say(ply, string.format(
				"%s (pod %d)%s%s — %s",
				s.key, s.index,
				s.gun and " [оружие]" or "",
				s.overridden and " *" or "",
				VCityLVS.FormatPosAng(s.pos, s.ang)
			))
		end
		Say(ply, "* — уже переопределено в конфиге. Дальше: vcity_rp_lvs_seat_set/move/here, потом _save.")
	end)

	local function ResolveArgsPosAng(args, startAt, defPos, defAng)
		local x = tonumber(args[startAt])
		local y = tonumber(args[startAt + 1])
		local z = tonumber(args[startAt + 2])
		if not x or not y or not z then return nil end

		local p = tonumber(args[startAt + 3]) or defAng.p
		local ya = tonumber(args[startAt + 4]) or defAng.y
		local r = tonumber(args[startAt + 5]) or defAng.r

		return Vector(x, y, z), Angle(p, ya, r)
	end

	local function SeatCommand(ply, args, mode)
		if not Allowed(ply) then return end

		local veh = VCityLVS.TraceVehicle(ply)
		if not IsValid(veh) then
			Say(ply, "Не вижу LVS-машины: сядьте в неё или наведите прицел.")
			return
		end

		local key = VCityLVS.SeatKey(args[1])
		if not key then
			Say(ply, "Кресло задаётся так: driver | 2 | 3 | ... (driver = водитель, 2 = второе кресло).")
			return
		end

		local seat = GetSeat(veh, key)
		if not seat then
			Say(ply, "Кресло " .. key .. " у этой машины не найдено. Список: vcity_rp_lvs_seats")
			return
		end

		local newPos, newAng

		if mode == "set" then
			newPos, newAng = ResolveArgsPosAng(args, 2, seat.pos, seat.ang)
			if not newPos then
				Say(ply, "Пример: vcity_rp_lvs_seat_set driver 0 10 5 [pitch yaw roll]")
				return
			end

		elseif mode == "move" then
			local dx = tonumber(args[2])
			local dy = tonumber(args[3])
			local dz = tonumber(args[4])
			if not dx or not dy or not dz then
				Say(ply, "Пример: vcity_rp_lvs_seat_move p2 0 5 0 [dpitch dyaw droll] — сдвинуть на 5 вбок.")
				return
			end
			newPos = seat.pos + Vector(dx, dy, dz)
			newAng = Angle(
				seat.ang.p + (tonumber(args[5]) or 0),
				seat.ang.y + (tonumber(args[6]) or 0),
				seat.ang.r + (tonumber(args[7]) or 0)
			)

		elseif mode == "here" then
			if not IsValid(ply) then
				Say(ply, "Из консоли эта команда недоступна.")
				return
			end
			newPos = veh:WorldToLocal(ply:GetPos())
			newAng = veh:WorldToLocalAngles(ply:EyeAngles())
		end

		if not MovePod(seat.pod, veh, newPos, newAng) then
			Say(ply, "Не удалось сдвинуть кресло.")
			return
		end

		local entry = EnsureEntry(veh)
		entry[key] = VCityLVS.PackPosAng(newPos, newAng)

		Say(ply, key .. " -> " .. VCityLVS.FormatPosAng(newPos, newAng) .. " (не забудьте vcity_rp_lvs_seat_save)")
	end

	concommand.Add("vcity_rp_lvs_seat_set", function(ply, _, args) SeatCommand(ply, args, "set") end)
	concommand.Add("vcity_rp_lvs_seat_move", function(ply, _, args) SeatCommand(ply, args, "move") end)
	concommand.Add("vcity_rp_lvs_seat_here", function(ply, _, args) SeatCommand(ply, args, "here") end)

	concommand.Add("vcity_rp_lvs_seat_save", function(ply)
		if not Allowed(ply) then return end
		SaveSeatConfig()
		Say(ply, "Конфиг кресел записан: data/" .. VCityLVS.SeatFile)
	end)

	concommand.Add("vcity_rp_lvs_seat_reset", function(ply, _, args)
		if not Allowed(ply) then return end

		local veh = VCityLVS.TraceVehicle(ply)
		if not IsValid(veh) then
			Say(ply, "Не вижу LVS-машины.")
			return
		end

		local entry, configKey = VCityLVS.FindVehicleEntry(veh)
		if not entry then
			Say(ply, "Для этой машины в конфиге ничего нет.")
			return
		end

		local key = VCityLVS.SeatKey(args[1])
		if key then
			if not entry[key] then
				Say(ply, "Кресло " .. key .. " и так без переопределений.")
				return
			end
			entry[key] = nil
			Say(ply, "Переопределение " .. key .. " сброшено. Вернётся на место после респавна машины.")
		else
			VCityLVS.SeatConfig.vehicles[configKey] = nil
			Say(ply, "Все переопределения машины сброшены. Вернутся на место после респавна машины.")
		end
	end)
end
