--[[---------------------------------------------------------
	V-City LVS: меню настройки седалища (команда vcity_rp_sidalishe)

	Настройка крепления тела экипажа к сиденью:
	— к точке модели (attachment — как рисует экипаж LVS),
	— к кости (bone — напрямую к башне),
	— к корпусу (без крепления).
	+ сдвиг положения тела (позиция и угол).

	Живой предпросмотр: полупрозрачное тело стоит на месте
	посадки прямо в меню. «Сохранить» пишет в
	data/vcity_rp/lvs_seats.json, «Применить» пересаживает
	реальные фейк-рэгдоллы в этом кресле.

	Команда и сохранение — только суперадминам.
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}

-- Проверка данных из меню (общая логика, тестируется)
-- data = { mode = "none"|"attach"|"bone", name = "...", attach_offset = {{x,y,z},{p,y,r}} }
function VCityLVS.ValidateSeatExtras(data)
	if not istable(data) then return nil end

	local mode = data.mode
	if mode ~= "none" and mode ~= "attach" and mode ~= "bone" then return nil end

	local out = { mode = mode }

	if mode ~= "none" then
		local name = isstring(data.name) and data.name or nil
		if not name or #name == 0 or #name > 64 then return nil end
		if not string.match(name, "^[%w_%-%. ]+$") then return nil end
		out.name = name
	end

	local offPos, offAng
	if VCityLVS.ParseOffset then
		offPos, offAng = VCityLVS.ParseOffset(data.attach_offset)
	else
		offPos, offAng = Vector(0, 0, 0), Angle(0, 0, 0)
	end

	local packed = VCityLVS.PackPosAng(offPos, offAng)
	out.attach_offset = { packed.pos, packed.ang }
	return out
end

if SERVER then
	util.AddNetworkString("vcity_lvs_seatui_open")
	util.AddNetworkString("vcity_lvs_seatui_save")

	local function SendMenu(ply, veh)
		local seats = VCityLVS.ListSeats(veh)
		local entry = VCityLVS.FindVehicleEntry(veh)

		local payload = {
			class = veh:GetClass(),
			model = veh:GetModel() or "",
			order = {},
			seats = {},
			camera = entry and VCityLVS.NormalizeCamMode and VCityLVS.NormalizeCamMode(entry.camera) or nil,
			cameras = entry and istable(entry.cameras) and entry.cameras or {},
		}

		for _, s in ipairs(seats) do
			local extra = entry and entry[s.key] or nil
			payload.seats[s.key] = {
				index = s.index,
				gun = s.gun or false,
				attach = extra and extra.attach or nil,
				bone = extra and extra.bone or nil,
				attach_offset = extra and extra.attach_offset or nil,
			}
			table.insert(payload.order, s.key)
		end

		local json = util.TableToJSON(payload)
		net.Start("vcity_lvs_seatui_open")
			net.WriteEntity(veh)
			net.WriteUInt(#json, 32)
			net.WriteData(json, #json)
		net.Send(ply)
	end

	concommand.Add("vcity_rp_sidalishe", function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then
			if IsValid(ply) then ply:ChatPrint("[V-City LVS] Команда доступна только суперадминам.") end
			return
		end

		local veh = VCityLVS.TraceVehicle(ply)
		if not IsValid(veh) then
			ply:ChatPrint("[V-City LVS] Сядьте в машину или наведите на неё прицел.")
			return
		end

		SendMenu(ply, veh)
	end)

	net.Receive("vcity_lvs_seatui_save", function(len, ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end

		local veh = net.ReadEntity()
		if not IsValid(veh) or not VCityLVS.IsLVSRelated(veh) then return end

		local key = VCityLVS.SeatKey(net.ReadString())
		if not key then return end

		local dataLen = net.ReadUInt(32)
		local raw = util.JSONToTable(tostring(net.ReadData(dataLen)))
		local extras = VCityLVS.ValidateSeatExtras(raw)
		if not extras then
			ply:ChatPrint("[V-City LVS] Некорректные данные крепления.")
			return
		end

		local apply = net.ReadBool()
		local persist = net.ReadBool()

		local entry, configKey = VCityLVS.FindVehicleEntry(veh)
		if not entry then
			configKey = veh:GetClass()
			VCityLVS.SeatConfig.vehicles[configKey] = VCityLVS.SeatConfig.vehicles[configKey] or {}
			entry = VCityLVS.SeatConfig.vehicles[configKey]
		end

		if extras.mode == "none" then
			entry[key] = nil
		else
			entry[key] = {
				attach = extras.mode == "attach" and extras.name or nil,
				bone = extras.mode == "bone" and extras.name or nil,
				attach_offset = extras.attach_offset,
			}
		end

		if persist then VCityLVS.SaveSeatConfig() end

		if apply then
			-- перепривязка настоящих тел через якорь (vcity_lvs_anchor.lua)
			if VCityLVS.ReattachSeatPlayers then
				VCityLVS.ReattachSeatPlayers(veh, key)
			end
		end

		if not persist then return end -- живая правка: без спама в чат

		ply:ChatPrint("[V-City LVS] Крепление " .. key .. " сохранено"
			.. (extras.mode == "none" and " (к корпусу)." or (" (" .. extras.mode .. " = " .. extras.name .. ")."))
			.. (apply and " Тела пересажены." or ""))
	end)

	print("[V-City LVS] Меню седалища готово: vcity_rp_sidalishe")
end

if CLIENT then
	surface.CreateFont("VCitySeatTitle", {
		font = "Arial", size = 17, weight = 700, antialias = true,
	})
	surface.CreateFont("VCitySeatText", {
		font = "Arial", size = 14, weight = 500, antialias = true,
	})

	local ACCENT = Color(255, 128, 40)
	local ACCENT_DIM = Color(255, 179, 115)
	local BG = Color(10, 11, 13, 245)
	local PANEL = Color(17, 18, 22, 240)
	local BORDER = Color(43, 44, 49, 220)
	local TEXT = Color(233, 234, 238)
	local TEXT_DIM = Color(143, 147, 157)
	local GREEN = Color(126, 205, 126)
	local RED = Color(224, 110, 96)

	local function PaintButton(pnl, w, h, text, baseCol, hoverCol)
		local grow = pnl:IsHovered() and 2 or 0
		surface.SetDrawColor(pnl:IsHovered() and (hoverCol or Color(52, 42, 32)) or (baseCol or Color(30, 31, 36)))
		surface.DrawRect(-grow / 2, -grow / 2, w + grow, h + grow)
		surface.SetDrawColor(BORDER)
		surface.DrawOutlinedRect(-grow / 2, -grow / 2, w + grow, h + grow, 1)
		draw.SimpleText(text, "VCitySeatText", w / 2, h / 2, pnl:IsHovered() and ACCENT_DIM or TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- ---------- предпросмотр тела ----------
	local ghost = nil

	local function RemoveGhost()
		if IsValid(ghost) then ghost:Remove() end
		ghost = nil
	end

	local function GhostTransform(veh, mode, name, offPos, offAng)
		if not IsValid(veh) then return nil end

		if mode == "attach" and name and name ~= "" then
			local id = veh:LookupAttachment(name)
			local att = (id and id > 0) and veh:GetAttachment(id) or nil
			if att then
				return LocalToWorld(offPos, offAng, att.Pos, att.Ang)
			end
		elseif mode == "bone" and name and name ~= "" then
			local bone = veh:LookupBone(name)
			if bone and bone >= 0 then
				local m = veh:GetBoneMatrix(bone)
				if m then
					return LocalToWorld(offPos, offAng, m:GetTranslation(), m:GetAngles())
				end
			end
		end

		return nil
	end

	local function UpdateGhost(veh, mode, name, offPos, offAng)
		local pos, ang = GhostTransform(veh, mode, name, offPos, offAng)
		if not pos then
			RemoveGhost()
			return
		end

		if not IsValid(ghost) then
			ghost = ClientsideModel(LocalPlayer():GetModel() or "models/player/group01/male_01.mdl", RENDERGROUP_TRANSLUCENT)
			if not IsValid(ghost) then return end
			ghost:SetNoDraw(true)
			ghost:SetSequence(ghost:LookupSequence("sit") ~= -1 and ghost:LookupSequence("sit") or 0)
		end

		ghost:SetPos(pos)
		ghost:SetAngles(ang)
		ghost.VCityGhostPos = pos
		ghost.VCityGhostAng = ang
	end

	hook.Add("PostDrawOpaqueRenderables", "VCityLVS.SeatGhost", function()
		if IsValid(ghost) and ghost.VCityGhostPos then
			ghost:SetRenderOrigin(ghost.VCityGhostPos)
			ghost:SetRenderAngles(ghost.VCityGhostAng)
			render.SetBlend(0.5)
			ghost:DrawModel()
			render.SetBlend(1)
		end
	end)

	-- ---------- само меню ----------
	function VCityLVS.OpenSeatMenu(veh, data)
		if IsValid(VCityLVS.SeatMenu) then
			VCityLVS.SeatMenu:Remove()
		end

		local order = data.order or {}
		local seats = data.seats or {}

		local frame = vgui.Create("DFrame")
		VCityLVS.SeatMenu = frame
		frame:SetSize(520, math.min(ScrH() - 30, 740))
		frame:Center()
		frame:MakePopup()
		frame:SetTitle("")
		frame:SetDraggable(true)
		frame.Paint = function(pnl, w, h)
			surface.SetDrawColor(BG)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(ACCENT)
			surface.DrawOutlinedRect(0, 0, w, h, 2)
			draw.SimpleText("Седалище — крепление тела", "VCitySeatTitle", w / 2, 16, ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(data.class or "", "VCitySeatText", w / 2, 38, TEXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		frame.btnClose.Paint = function(pnl, w, h)
			PaintButton(pnl, w, h, "X", nil, Color(80, 30, 24))
		end
		frame.btnMaxim:SetVisible(false)
		frame.btnMinim:SetVisible(false)
		frame.lblTitle:SetVisible(false)
		frame.OnRemove = function()
			RemoveGhost()
		end

		local y = 58

		-- Кресло
		local seatLabel = vgui.Create("DLabel", frame)
		seatLabel:SetPos(16, y)
		seatLabel:SetSize(120, 20)
		seatLabel:SetText("Кресло:")
		seatLabel:SetFont("VCitySeatText")
		seatLabel:SetTextColor(TEXT)

		local seatCombo = vgui.Create("DComboBox", frame)
		seatCombo:SetPos(140, y)
		seatCombo:SetSize(360, 22)
		seatCombo:SetSortItems(false)
		for _, key in ipairs(order) do
			local info = seats[key] or {}
			seatCombo:AddChoice(key .. (info.gun and "  [оружие]" or "") .. "  (pod " .. (info.index or "?") .. ")", key)
		end
		if #order > 0 then
			seatCombo:SetSelected(seatCombo:GetOptionText(1))
		end

		y = y + 34

		-- Режим крепления
		local modeLabel = vgui.Create("DLabel", frame)
		modeLabel:SetPos(16, y)
		modeLabel:SetSize(120, 20)
		modeLabel:SetText("Крепление:")
		modeLabel:SetFont("VCitySeatText")
		modeLabel:SetTextColor(TEXT)

		local modeCombo = vgui.Create("DComboBox", frame)
		modeCombo:SetPos(140, y)
		modeCombo:SetSize(360, 22)
		modeCombo:AddChoice("К точке модели (attachment)", "attach")
		modeCombo:AddChoice("К кости (bone)", "bone")
		modeCombo:AddChoice("К корпусу (без крепления)", "none")

		y = y + 34

		-- Имя точки/кости
		local nameLabel = vgui.Create("DLabel", frame)
		nameLabel:SetPos(16, y)
		nameLabel:SetSize(120, 20)
		nameLabel:SetText("Точка / кость:")
		nameLabel:SetFont("VCitySeatText")
		nameLabel:SetTextColor(TEXT)

		local nameCombo = vgui.Create("DComboBox", frame)
		nameCombo:SetPos(140, y)
		nameCombo:SetSize(360, 22)
		nameCombo:SetSortItems(true)

		y = y + 34

		-- Смещение и поворот: ползунки (значение можно и вписать вручную)
		local posWangs = {}
		local angWangs = {}

		local function MakeSlider(text, min, max, decimals, yy)
			local sl = vgui.Create("DNumSlider", frame)
			sl:SetPos(16, yy)
			sl:SetSize(488, 22)
			sl:SetText(text)
			sl:SetMin(min)
			sl:SetMax(max)
			sl:SetDecimals(decimals)
			sl:SetDefaultValue(0)
			sl:SetValue(0)
			sl.Label:SetFont("VCitySeatText")
			sl.Label:SetTextColor(TEXT)
			sl.Label:SetWide(110)
			return sl
		end

		local axes = { "Вперёд / назад (X)", "Влево / вправо (Y)", "Вверх / вниз (Z)" }
		for i = 1, 3 do
			posWangs[i] = MakeSlider(axes[i], -150, 150, 1, y)
			y = y + 24
		end

		local rots = { "Наклон (pitch)", "Поворот (yaw)", "Крен (roll)" }
		for i = 1, 3 do
			angWangs[i] = MakeSlider(rots[i], -180, 180, 1, y)
			y = y + 24
		end

		local liveCheck = vgui.Create("DCheckBoxLabel", frame)
		liveCheck:SetPos(16, y + 4)
		liveCheck:SetText("Двигать тело на лету (без записи в файл — запись кнопкой «Сохранить»)")
		liveCheck:SetFont("VCitySeatText")
		liveCheck:SetTextColor(TEXT)
		liveCheck:SizeToContents()

		y = y + 30

		local hint = vgui.Create("DLabel", frame)
		hint:SetPos(16, y)
		hint:SetSize(488, 32)
		hint:SetFont("VCitySeatText")
		hint:SetTextColor(TEXT_DIM)
		hint:SetWrap(true)
		hint:SetText("Полупрозрачное тело показывает, где сядет экипаж. Для танков начинай с точек вроде gunner / comm_seat — они ездят с башней.")

		y = y + 44

		-- текущее состояние
		local current = { key = order[1] or "driver", mode = "none", name = "" }

		local function RefreshNameCombo()
			nameCombo:Clear()
			local vehValid = IsValid(veh)

			if current.mode == "attach" and vehValid then
				for _, att in ipairs(veh:GetAttachments() or {}) do
					nameCombo:AddChoice(att.name)
				end
			elseif current.mode == "bone" and vehValid then
				for bone = 0, (veh:GetBoneCount() or 1) - 1 do
					local bname = veh:GetBoneName(bone)
					if bname and bname ~= "" then
						nameCombo:AddChoice(bname)
					end
				end
			end

			if current.name and current.name ~= "" then
				nameCombo:SetValue(current.name)
			end
		end

		local function ApplyToGhost()
			if not IsValid(veh) then return end
			UpdateGhost(veh, current.mode, current.name, Vector(posWangs[1]:GetValue(), posWangs[2]:GetValue(), posWangs[3]:GetValue()),
				Angle(angWangs[1]:GetValue(), angWangs[2]:GetValue(), angWangs[3]:GetValue()))
		end

		local function LoadSeat(key)
			local info = seats[key] or {}
			current.key = key

			if info.attach then
				current.mode, current.name = "attach", info.attach
			elseif info.bone then
				current.mode, current.name = "bone", info.bone
			else
				current.mode, current.name = "none", ""
			end

			modeCombo:SetValue(current.mode == "attach" and "К точке модели (attachment)"
				or current.mode == "bone" and "К кости (bone)" or "К корпусу (без крепления)")

			RefreshNameCombo()

			local off = info.attach_offset or {}
			local p = off[1] or { 0, 0, 0 }
			local a = off[2] or { 0, 0, 0 }
			for i = 1, 3 do
				posWangs[i]:SetValue(tonumber(p[i]) or 0)
				angWangs[i]:SetValue(tonumber(a[i]) or 0)
			end

			ApplyToGhost()
		end

		seatCombo.OnSelect = function(_, _, _, key)
			LoadSeat(key)
		end

		modeCombo.OnSelect = function(_, _, _, value)
			current.mode = value
			current.name = ""
			RefreshNameCombo()
			ApplyToGhost()
		end

		nameCombo.OnSelect = function(_, _, value)
			current.name = value
			ApplyToGhost()
		end

		local SendSave
		local function OnSliderChanged()
			ApplyToGhost()
			if liveCheck:GetChecked() and SendSave and current.mode ~= "none" then
				timer.Create("VCityLVS.LiveSeat", 0.3, 1, function()
					if IsValid(frame) then SendSave(true, false) end
				end)
			end
		end
		for _, wang in ipairs(posWangs) do
			wang.OnValueChanged = OnSliderChanged
		end
		for _, wang in ipairs(angWangs) do
			wang.OnValueChanged = OnSliderChanged
		end

		-- кнопки
		SendSave = function(apply, persist)
			local payload = {
				mode = current.mode,
				name = current.name,
				attach_offset = {
					{ posWangs[1]:GetValue(), posWangs[2]:GetValue(), posWangs[3]:GetValue() },
					{ angWangs[1]:GetValue(), angWangs[2]:GetValue(), angWangs[3]:GetValue() },
				},
			}
			local json = util.TableToJSON(payload)

			net.Start("vcity_lvs_seatui_save")
				net.WriteEntity(veh)
				net.WriteString(current.key)
				net.WriteUInt(#json, 32)
				net.WriteData(json, #json)
				net.WriteBool(apply or false)
				net.WriteBool(persist ~= false)
			net.SendToServer()
		end

		local btnY = y

		local saveBtn = vgui.Create("DButton", frame)
		saveBtn:SetPos(16, btnY)
		saveBtn:SetSize(150, 32)
		saveBtn:SetText("")
		saveBtn.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "Сохранить") end
		saveBtn.DoClick = function()
			surface.PlaySound("ui/buttonclick.wav")
			SendSave(false)
		end

		local applyBtn = vgui.Create("DButton", frame)
		applyBtn:SetPos(178, btnY)
		applyBtn:SetSize(190, 32)
		applyBtn:SetText("")
		applyBtn.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "Сохранить и применить") end
		applyBtn.DoClick = function()
			surface.PlaySound("ui/buttonclick.wav")
			SendSave(true)
		end

		local resetBtn = vgui.Create("DButton", frame)
		resetBtn:SetPos(380, btnY)
		resetBtn:SetSize(120, 32)
		resetBtn:SetText("")
		resetBtn.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "К корпусу", nil, Color(80, 30, 24)) end
		resetBtn.DoClick = function()
			surface.PlaySound("ui/buttonclick.wav")
			current.mode = "none"
			current.name = ""
			modeCombo:SetValue("К корпусу (без крепления)")
			RefreshNameCombo()
			RemoveGhost()
			SendSave(true)
		end

		-- ---------- камера: вся машина / выбранное кресло ----------
		local camY = btnY + 48
		local camLine = vgui.Create("DPanel", frame)
		camLine:SetPos(16, camY - 8)
		camLine:SetSize(488, 1)
		camLine.Paint = function(_, w, h) surface.SetDrawColor(BORDER) surface.DrawRect(0, 0, w, h) end

		local CAM_CHOICES = {
			{ "По умолчанию (глобальная настройка)", "default" },
			{ "Камера LVS", "lvs" },
			{ "Камера Z-City", "zcity" },
		}
		local CAM_TEXT = { default = CAM_CHOICES[1][1], lvs = CAM_CHOICES[2][1], zcity = CAM_CHOICES[3][1] }

		local function CamLabel(text, yy)
			local l = vgui.Create("DLabel", frame)
			l:SetPos(16, yy)
			l:SetSize(120, 20)
			l:SetText(text)
			l:SetFont("VCitySeatText")
			l:SetTextColor(TEXT)
		end

		local function SendCam(scope, mode)
			net.Start("vcity_lvs_cam_save")
				net.WriteEntity(veh)
				net.WriteString(scope)
				net.WriteString(mode)
			net.SendToServer()
		end

		CamLabel("Камера машины:", camY)
		local vehCam = vgui.Create("DComboBox", frame)
		vehCam:SetPos(140, camY)
		vehCam:SetSize(360, 22)
		vehCam:SetSortItems(false)
		for _, c in ipairs(CAM_CHOICES) do vehCam:AddChoice(c[1], c[2]) end
		vehCam:SetValue(CAM_TEXT[data.camera or "default"])
		vehCam.OnSelect = function(_, _, _, mode)
			data.camera = mode ~= "default" and mode or nil
			SendCam("vehicle", mode)
		end

		CamLabel("Камера кресла:", camY + 30)
		local seatCam = vgui.Create("DComboBox", frame)
		seatCam:SetPos(140, camY + 30)
		seatCam:SetSize(360, 22)
		seatCam:SetSortItems(false)
		for _, c in ipairs(CAM_CHOICES) do
			seatCam:AddChoice(c[1] == CAM_CHOICES[1][1] and "Как у машины" or c[1], c[2])
		end
		data.cameras = data.cameras or {}
		local function ShowSeatCam()
			local m = data.cameras[current.key]
			seatCam:SetValue(m and CAM_TEXT[m] or "Как у машины")
		end
		seatCam.OnSelect = function(_, _, _, mode)
			data.cameras[current.key] = mode ~= "default" and mode or nil
			SendCam(current.key, mode)
		end

		local camHint = vgui.Create("DLabel", frame)
		camHint:SetPos(16, camY + 58)
		camHint:SetSize(488, 32)
		camHint:SetFont("VCitySeatText")
		camHint:SetTextColor(TEXT_DIM)
		camHint:SetWrap(true)
		camHint:SetText("Камера сохраняется сразу. Приоритет: кресло > машина > глобальный конвар vcity_rp_lvs_zcity_camera. Вступает в силу при следующей посадке.")

		local baseSeatChange = seatCombo.OnSelect
		seatCombo.OnSelect = function(a, b, c, key)
			baseSeatChange(a, b, c, key)
			ShowSeatCam()
		end

		if #order > 0 then
			LoadSeat(order[1])
			ShowSeatCam()
		end
	end

	net.Receive("vcity_lvs_seatui_open", function()
		local veh = net.ReadEntity()
		local dataLen = net.ReadUInt(32)
		local json = util.JSONToTable(tostring(net.ReadData(dataLen)))

		if IsValid(veh) and istable(json) then
			VCityLVS.OpenSeatMenu(veh, json)
		end
	end)
end
