--[[---------------------------------------------------------
	V-City LVS ↔ Z-City: урон по экипажу при попадании в технику.

	Когда техника получает урон (пуля, снаряд, взрыв, удар),
	часть его достаётся людям внутри:

	* ПУЛЯ/СНАРЯД — броню пробивает только урон выше порога
	  (vcity_rp_lvs_crew_min). Чем выше урон над порогом, тем
	  больше шанс пробития. Пробитие ранит ближайшее к точке
	  попадания кресло; соседние кресла рядом (радиус осколков)
	  получают долю урона (vcity_rp_lvs_crew_spall).
	* ВЗРЫВ — все в радиусе (vcity_rp_lvs_crew_radius) от точки
	  взрыва, урон падает с расстоянием; бронёй не режется.
	* УДАР/ТАРАН — слабая травма всему экипажу при сильном ударе.

	Урон идёт через штатный TakeDamageInfo, поэтому Z-City сам
	считает раны, кровотечение и боль (фейк-рэгдолл). Если Z-City
	урон заблокировал — работает запасной путь: поля организма
	напрямую (как у сбития пешехода).

	Настройка машины (множитель, 0 = экипаж неуязвим):
	  vcity_rp_lvs_crewdmg <множитель>   (суперадмин, цель/кабина)
	  data/vcity_rp/lvs_seats.json: "crew_damage": 0.5

	Конвары: vcity_rp_lvs_crew (1/0), _scale, _min, _radius,
	_spall, _debug.

	Защита от «вечной рвоты кровью» (внутреннее кровотечение Z-City
	затухает ~1 ед. за 55 с, поэтому большие числа держатся часами):
	  _blast     множитель урона ВЗРЫВА по экипажу (корпус гасит часть), 0.4
	  _cap       потолок урона на человека за одно попадание, 60 (0 = без)
	  _window    сек: события урона в этом окне = одно попадание, 0.3
	  _ibleed    макс. прирост внутреннего кровотечения за удар, 10 (0 = без)
	  _fallback  запасной путь в обход Z-City (по умолч. ВЫКЛ: Z-City всегда
	             блокирует штатный урон игрока, и запасной путь бил ДВАЖДЫ)
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}
VCityLVS.Perf = VCityLVS.Perf or { fullTicks = 0, throttledTicks = 0, busyTicks = 0 }
VCityLVS.Perf.crewHits = VCityLVS.Perf.crewHits or 0

-- Чистая логика: кто и сколько получает (тестируется без движка).
-- seats = { {key=, x=, y=, z=}, ... } (только занятые), hit = {x=,y=,z=} или nil
-- kind = "bullet" | "blast" | "crush"
-- cfg = { scale, min, radius, spall, full = урон полного пробития }
-- roll = случайное 0..1 (на вход, чтобы тест был детерминирован)
function VCityLVS.CrewPlan(damage, kind, hit, seats, cfg, roll)
	local out = {}
	damage = tonumber(damage) or 0
	if damage <= 0 or #seats == 0 then return out end

	local scale = cfg.scale or 1
	local function dist(s)
		if not hit then return 0 end
		local dx, dy, dz = s.x - hit.x, s.y - hit.y, s.z - hit.z
		return math.sqrt(dx * dx + dy * dy + dz * dz)
	end

	if kind == "blast" then
		local radius = math.max(cfg.radius or 300, 1)
		for _, s in ipairs(seats) do
			local d = dist(s)
			if d < radius then
				local fall = 1 - d / radius
				out[#out + 1] = { key = s.key, damage = damage * scale * fall * 0.6 * (cfg.blast or 1) }
			end
		end

	elseif kind == "crush" then
		if damage < 40 then return out end
		for _, s in ipairs(seats) do
			out[#out + 1] = { key = s.key, damage = damage * scale * 0.15 }
		end

	else -- bullet
		local min = cfg.min or 15
		if damage < min then return out end

		local full = math.max(cfg.full or 120, min + 1)
		local chance = math.min((damage - min) / (full - min), 1) * 0.85 + 0.15
		if (roll or 0) > chance then return out end

		table.sort(seats, function(a, b) return dist(a) < dist(b) end)
		local first = seats[1]
		out[#out + 1] = { key = first.key, damage = damage * scale * 0.5 }

		local spallR = 80
		for i = 2, #seats do
			if dist(seats[i]) - dist(first) < spallR then
				out[#out + 1] = { key = seats[i].key, damage = damage * scale * 0.5 * (cfg.spall or 0.35) }
			end
		end
	end

	return out
end

if not SERVER then return end

local cvOn = CreateConVar("vcity_rp_lvs_crew", "1", FCVAR_ARCHIVE, "Урон по экипажу LVS-техники при попадании (1/0)")
local cvScale = CreateConVar("vcity_rp_lvs_crew_scale", "1", FCVAR_ARCHIVE, "Общий множитель урона по экипажу")
local cvMin = CreateConVar("vcity_rp_lvs_crew_min", "15", FCVAR_ARCHIVE, "Пороговый урон, с которого пуля/снаряд пробивает броню")
local cvRadius = CreateConVar("vcity_rp_lvs_crew_radius", "300", FCVAR_ARCHIVE, "Радиус поражения экипажа взрывом, юниты")
local cvSpall = CreateConVar("vcity_rp_lvs_crew_spall", "0.35", FCVAR_ARCHIVE, "Доля урона для соседних кресел (осколки)")
local cvDebug = CreateConVar("vcity_rp_lvs_crew_debug", "0", FCVAR_ARCHIVE, "Печатать попадания по экипажу")
local cvBlast = CreateConVar("vcity_rp_lvs_crew_blast", "0.4", FCVAR_ARCHIVE, "Множитель урона ВЗРЫВА по экипажу (корпус гасит часть)")
local cvCap = CreateConVar("vcity_rp_lvs_crew_cap", "60", FCVAR_ARCHIVE, "Потолок урона на человека за одно попадание (0 = без потолка)")
local cvWindow = CreateConVar("vcity_rp_lvs_crew_window", "0.3", FCVAR_ARCHIVE, "Окно (сек): события урона внутри считаются одним попаданием")
local cvIBleed = CreateConVar("vcity_rp_lvs_crew_ibleed", "10", FCVAR_ARCHIVE, "Макс. прирост внутреннего кровотечения за один удар (0 = без ограничения)")
local cvFallback = CreateConVar("vcity_rp_lvs_crew_fallback", "0", FCVAR_ARCHIVE, "Запасной путь урона мимо Z-City (обычно НЕ нужен, бьёт дважды)")

local guard = false
local lastTook = nil

local function Kind(dmg)
	local t = dmg:GetDamageType()
	if bit.band(t, DMG_BLAST + DMG_BLAST_SURFACE) ~= 0 then return "blast" end
	if bit.band(t, DMG_CRUSH + DMG_VEHICLE) ~= 0 then return "crush" end
	if bit.band(t, DMG_BULLET + DMG_AIRBOAT + DMG_SNIPER + DMG_BUCKSHOT + DMG_SLASH + DMG_CLUB) ~= 0 then return "bullet" end
	return nil -- огонь, электричество и т.п. экипажу не передаём
end

-- Живая запись «множитель машины»
local function VehMultiplier(veh)
	local entry = VCityLVS.FindVehicleEntry and VCityLVS.FindVehicleEntry(veh) or nil
	local m = istable(entry) and tonumber(entry.crew_damage) or nil
	if m == nil then return 1 end
	return math.Clamp(m, 0, 5)
end

local function ApplyDirect(ply, d)
	local org = ply.organism
	if not istable(org) or org.godmode then return end
	org.pain = math.min((org.pain or 0) + d * 0.4, 255)
	local ibCap = cvIBleed:GetFloat()
	org.internalBleed = math.min((org.internalBleed or 0) + d * 0.25, ibCap > 0 and ibCap or 100)
	org.bleed = math.min((org.bleed or 0) + d * 0.02, 20)
end

local function HurtCrew(ply, veh, pod, amount, kind, attacker, inflictor)
	if amount < 1 then return end

	-- Потолок на «одно попадание»: один снаряд даёт по технике несколько событий урона
	-- (прямое + сплэш + детали), раньше они суммировались.
	local cap = cvCap:GetFloat()
	if cap > 0 then
		local now = CurTime()
		local w = ply.VCityLVSCrewWin
		if not w or now - w.t > cvWindow:GetFloat() then
			w = { t = now, sum = 0 }
			ply.VCityLVSCrewWin = w
		end
		amount = math.min(amount, cap - w.sum)
		if amount < 1 then return end
		w.sum = w.sum + amount
	end

	local info = DamageInfo()
	info:SetDamage(amount)
	info:SetAttacker(IsValid(attacker) and attacker or veh)
	info:SetInflictor(IsValid(inflictor) and inflictor or veh)
	info:SetDamageType(kind == "blast" and DMG_BLAST or kind == "crush" and DMG_CLUB or DMG_BULLET)
	info:SetDamagePosition(pod:GetPos() + Vector(0, 0, 30))
	info:SetDamageForce(vector_origin)

	local ibBefore = istable(ply.organism) and tonumber(ply.organism.internalBleed) or nil

	-- штатный путь Z-City: он сам считает раны, боль и кровотечение
	lastTook = nil
	guard = true
	ply:TakeDamageInfo(info)
	guard = false

	-- Внутреннее кровотечение — причина «вечной рвоты кровью» (затухает ~1/55 ед. в секунду).
	-- Ограничиваем ПРИРОСТ от этого удара; прежнее значение (от других ран) не трогаем.
	local maxAdd = cvIBleed:GetFloat()
	if maxAdd > 0 and ibBefore then
		local function clamp()
			local org = IsValid(ply) and ply.organism
			if not istable(org) then return end
			local now = tonumber(org.internalBleed) or ibBefore
			if now - ibBefore > maxAdd then org.internalBleed = ibBefore + maxAdd end
		end
		clamp()
		timer.Simple(0, clamp) -- на случай, если Z-City дописывает организм с задержкой
	end

	-- Z-City ВСЕГДА блокирует штатный урон игрока (took == false), поэтому запасной путь
	-- по умолчанию выключен: иначе урон применялся дважды.
	if cvFallback:GetBool() and lastTook == false then
		ApplyDirect(ply, amount)
	end

	VCityLVS.Perf.crewHits = VCityLVS.Perf.crewHits + 1
	if cvDebug:GetBool() then
		print(string.format("[V-City LVS] экипаж: %s получил %.1f (%s)", ply:Nick(), amount, kind))
	end
end

hook.Add("PostEntityTakeDamage", "VCityLVS.CrewTookDamage", function(ent, dmg, took)
	-- (1) ответ на наш же TakeDamageInfo: прошёл или нет
	if guard then
		if ent:IsPlayer() then lastTook = took end
		return
	end

	-- (2) попадание в технику
	if not cvOn:GetBool() then return end
	if not IsValid(ent) or not ent.GetDriverSeat then return end

	local kind = Kind(dmg)
	if not kind then return end

	local damage = dmg:GetDamage()
	if damage <= 0 then return end

	local mult = VehMultiplier(ent)
	if mult <= 0 then return end

	-- занятые кресла
	local seats, byKey = {}, {}
	for _, s in ipairs(VCityLVS.ListSeats(ent)) do
		local ply = IsValid(s.pod) and s.pod:GetDriver() or NULL
		if IsValid(ply) and ply:IsPlayer() and ply:Alive() then
			local p = s.pod:GetPos()
			seats[#seats + 1] = { key = s.key, x = p.x, y = p.y, z = p.z }
			byKey[s.key] = { ply = ply, pod = s.pod }
		end
	end
	if #seats == 0 then return end

	local hitPos = dmg:GetDamagePosition()
	local hit = (hitPos and hitPos ~= vector_origin) and { x = hitPos.x, y = hitPos.y, z = hitPos.z } or nil

	local plan = VCityLVS.CrewPlan(damage, kind, hit, seats, {
		scale = cvScale:GetFloat() * mult,
		min = cvMin:GetFloat(),
		radius = cvRadius:GetFloat(),
		spall = cvSpall:GetFloat(),
		blast = cvBlast:GetFloat(),
		full = 120,
	}, math.Rand(0, 1))

	-- DamageInfo живёт только внутри хука, поэтому берём нужное заранее
	local attacker, inflictor = dmg:GetAttacker(), dmg:GetInflictor()

	for _, p in ipairs(plan) do
		local t = byKey[p.key]
		if t and IsValid(t.ply) then
			local ply, pod, amount = t.ply, t.pod, p.damage
			-- Урон по экипажу применяем на СЛЕДУЮЩЕМ тике: попадание в машину часто приходит
			-- из физического колбэка (ракета, снаряд), а Z-City в ответ на урон меняет
			-- рэгдоллы/сварки/коллизии. Менять физику внутри колбэка нельзя (краш сервера).
			timer.Simple(0, function()
				if IsValid(ply) and ply:Alive() and IsValid(ent) and IsValid(pod) and pod:GetDriver() == ply then
					HurtCrew(ply, ent, pod, amount, kind, attacker, inflictor)
				end
			end)
		end
	end
end)

-- Множитель урона по экипажу для машины под прицелом / в которой вы сидите
concommand.Add("vcity_rp_lvs_crewdmg", function(ply, _, args)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end

	local function say(msg)
		if IsValid(ply) then ply:ChatPrint("[V-City LVS] " .. msg) else print("[V-City LVS] " .. msg) end
	end

	local veh = VCityLVS.TraceVehicle(ply)
	if not IsValid(veh) then return say("Не вижу LVS-машины: сядьте в неё или наведите прицел.") end

	local m = tonumber(args[1])
	if not m then
		return say(veh:GetClass() .. ": множитель урона по экипажу = " .. VehMultiplier(veh) .. " (0 — неуязвим). Задать: vcity_rp_lvs_crewdmg 0.5")
	end

	local entry, key = VCityLVS.FindVehicleEntry(veh)
	if not entry then
		key = veh:GetClass()
		VCityLVS.SeatConfig.vehicles[key] = VCityLVS.SeatConfig.vehicles[key] or {}
		entry = VCityLVS.SeatConfig.vehicles[key]
	end
	entry.crew_damage = math.Clamp(m, 0, 5)
	VCityLVS.SaveSeatConfig()
	say(key .. ": множитель урона по экипажу = " .. entry.crew_damage .. " (сохранено)")
end)

print("[V-City LVS] Урон по экипажу подключён.")
