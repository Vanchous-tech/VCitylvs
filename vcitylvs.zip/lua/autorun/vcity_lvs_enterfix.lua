--[[---------------------------------------------------------
	V-City LVS: «кресло не пускает после первой посадки».

	Причина (Z-City, homigrad/fake/sv_tier_0.lua):
	* при посадке рэгдолл игрока кладётся в список pod.rags;
	* убирается оттуда ТОЛЬКО в колбэке сварки "removeOwO";
	* перед входом fake_enterveh вызывает hg.RemoveDeadBodies(pod):
	  любая запись в pod.rags считается «трупом» -> вход запрещён.

	Мост (vcity_lvs_anchor.lua) для кресел с якорем этот колбэк
	отключает (иначе Z-City выкинет игрока), поэтому «призрак»
	оставался в pod.rags навсегда, и во второй раз кресло не пускало.

	Что делает этот файл:
	1. VCityLVS.ForgetRagdoll(ragdoll) — убрать рэгдолл из rags
	   (зовётся из Detach в vcity_lvs_anchor.lua).
	2. Страховка: перед hg.RemoveDeadBodies чистим pod.rags LVS-кресла
	   от мёртвых ссылок и от рэгдоллов живых игроков, которые уже
	   не сидят в этом кресле. Настоящие трупы не трогаем.
	3. vcity_rp_lvs_unstick — разблокировать кресла машины под прицелом.
	4. vcity_rp_lvs_enter_debug 1 — лог входов/выходов и ТРЕЙСБЕК каждого
	   ExitVehicle (кто именно выкинул игрока из техники).
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}

if not SERVER then return end

local cvDebug = CreateConVar("vcity_rp_lvs_enter_debug", "0", FCVAR_ARCHIVE,
	"Отладка входа/выхода из LVS-техники: кто выкинул игрока, почему кресло не пустило")

local function dbg(...)
	if cvDebug:GetBool() then print("[V-City LVS][enter]", ...) end
end

local function IsLVSPod(pod)
	return IsValid(pod) and isfunction(pod.lvsGetVehicle) and IsValid(pod:lvsGetVehicle())
end

local function RemoveAll(list, value)
	if not istable(list) then return end
	for i = #list, 1, -1 do
		if list[i] == value then table.remove(list, i) end
	end
end

---------------------------------------------------------------------------
-- 1. Убрать рэгдолл из rags (то, что делал бы "removeOwO")
---------------------------------------------------------------------------
function VCityLVS.ForgetRagdoll(ragdoll)
	if not IsValid(ragdoll) then return end

	local seen = {}
	local function scrub(ent)
		if not IsValid(ent) or seen[ent] then return end
		seen[ent] = true
		RemoveAll(ent.rags, ragdoll)
	end

	local pod = ragdoll.VCityLVSPod
	scrub(pod)

	if IsValid(pod) then
		scrub(pod:GetParent())
		if isfunction(pod.lvsGetVehicle) then scrub(pod:lvsGetVehicle()) end
	end

	local owner = ragdoll.ply
	if IsValid(owner) then scrub(owner:GetVehicle()) end
end

---------------------------------------------------------------------------
-- 2. Страховка: чистим rags перед проверкой «трупов в кресле»
---------------------------------------------------------------------------
-- Возвращает, сколько записей удалено.
local function PruneRags(pod)
	local rags = pod.rags
	if not istable(rags) then return 0 end

	local removed = 0

	for i = #rags, 1, -1 do
		local r = rags[i]
		local drop = not IsValid(r)

		if not drop then
			local owner = r.ply
			if not IsValid(owner) and r.GetNWEntity then owner = r:GetNWEntity("ply") end

			-- рэгдолл живого игрока, который уже не сидит в этом кресле — не труп
			if IsValid(owner) and owner:IsPlayer() and owner:Alive() and owner:GetVehicle() ~= pod then
				drop = true
			end
		end

		if drop then
			table.remove(rags, i)
			removed = removed + 1
		end
	end

	return removed
end

VCityLVS.PruneSeatRags = PruneRags

local function InstallWrap()
	if not istable(hg) or not isfunction(hg.RemoveDeadBodies) then return false end
	if hg.__vcityLvsRagsWrapped then return true end
	hg.__vcityLvsRagsWrapped = true

	local original = hg.RemoveDeadBodies

	-- fake_enterveh вызывает именно hg.RemoveDeadBodies(...) по имени в момент входа,
	-- поэтому подмена не зависит от порядка хуков.
	hg.RemoveDeadBodies = function(veh, ...)
		if IsLVSPod(veh) then
			local before = istable(veh.rags) and #veh.rags or 0
			local removed = PruneRags(veh)
			if removed > 0 then
				dbg(string.format("кресло %s: убрано %d устаревших записей rags (было %d)", tostring(veh), removed, before))
			end
		end
		return original(veh, ...)
	end

	return true
end

if not InstallWrap() then
	hook.Add("InitPostEntity", "VCityLVS.EnterFixWrap", InstallWrap)
	timer.Create("VCityLVS.EnterFixWrapRetry", 1, 30, function()
		if InstallWrap() then timer.Remove("VCityLVS.EnterFixWrapRetry") end
	end)
end

---------------------------------------------------------------------------
-- 3. Ручная разблокировка кресел
---------------------------------------------------------------------------
concommand.Add("vcity_rp_lvs_unstick", function(ply)
	if IsValid(ply) and not ply:IsSuperAdmin() then return end

	local function say(msg)
		if IsValid(ply) then ply:ChatPrint("[V-City LVS] " .. msg) else print("[V-City LVS] " .. msg) end
	end

	local veh = VCityLVS.TraceVehicle and VCityLVS.TraceVehicle(ply) or NULL
	if not IsValid(veh) then return say("Не вижу LVS-машины: сядьте в неё или наведите прицел.") end

	local total = 0
	for _, s in ipairs(VCityLVS.ListSeats(veh)) do
		if IsValid(s.pod) then
			local n = PruneRags(s.pod)
			total = total + n
		end
	end

	say(veh:GetClass() .. ": убрано устаревших записей rags — " .. total)
end)

---------------------------------------------------------------------------
-- 4. Отладка
---------------------------------------------------------------------------
-- Кто вызвал ExitVehicle: подмена ставится ТОЛЬКО пока включён vcity_rp_lvs_enter_debug
-- (в обычной работе родной ExitVehicle не трогаем).
do
	local PLAYER = FindMetaTable("Player")
	local originalExit

	local function SetExitTrace(on)
		if not PLAYER then return end
		if on and not originalExit then
			originalExit = PLAYER.ExitVehicle
			PLAYER.ExitVehicle = function(self, ...)
				if IsValid(self) and self:InVehicle() then
					print(string.format("[V-City LVS][enter] ExitVehicle(%s), кресло=%s\n%s",
						self:Nick(), tostring(self:GetVehicle()), debug.traceback("", 2)))
				end
				return originalExit(self, ...)
			end
		elseif not on and originalExit then
			PLAYER.ExitVehicle = originalExit
			originalExit = nil
		end
	end

	cvars.AddChangeCallback("vcity_rp_lvs_enter_debug", function(_, _, new)
		SetExitTrace(tobool(new))
	end, "VCityLVS.ExitTrace")

	SetExitTrace(cvDebug:GetBool())
end

-- Монитор (с ULib не влияет на результат, всегда возвращает nil)
hook.Add("CanPlayerEnterVehicle", "VCityLVS.EnterDebug", function(ply, pod)
	if not cvDebug:GetBool() or not IsLVSPod(pod) then return end
	local rags = istable(pod.rags) and #pod.rags or 0
	dbg(string.format("попытка входа: %s -> кресло %s (pod %s), в rags записей: %d",
		IsValid(ply) and ply:Nick() or "?", tostring(pod), tostring(pod:lvsGetPodIndex()), rags))
end, HOOK_MONITOR_HIGH)

hook.Add("PlayerEnteredVehicle", "VCityLVS.EnterDebug", function(ply, pod)
	if cvDebug:GetBool() and IsLVSPod(pod) then
		dbg(string.format("%s сел: кресло %s (pod %s)", ply:Nick(), tostring(pod), tostring(pod:lvsGetPodIndex())))
	end
end)

hook.Add("PlayerLeaveVehicle", "VCityLVS.EnterDebug", function(ply, pod)
	if cvDebug:GetBool() and IsLVSPod(pod) then
		dbg(string.format("%s вышел: кресло %s (pod %s)", ply:Nick(), tostring(pod), tostring(pod:lvsGetPodIndex())))
	end
end)

print("[V-City LVS] Фикс «кресло не пускает после первой посадки» подключён.")
