--[[---------------------------------------------------------
	V-City LVS: якорь тела экипажа.

	Прямой порт sv_gunner_anchor.lua с БРДМ-2 «dobruja digger»
	(структура сохранена функция в функцию), обобщение одно:
	класс машины, точка крепления и смещение берутся из
	конфига кресел (data/vcity_rp/lvs_seats.json, меню
	vcity_rp_sidalishe), а не захардкожены.

	Как это работает (как в БРДМ):
	* Z-City при посадке делает рэгдолл и приваривает таз/ноги
	  к корпусу. Мы снимаем сварки (колбэк "removeOwO" отключается
	  первым — иначе он выкинет игрока из машины) и создаём
	  невидимый якорь, который каждый тик переезжает за точкой
	  крепления (attachment или кость).
	* Рэгдолл переносится так, чтобы таз попал в цель, и
	  приваривается к якорю.
	* Якорь едет с упреждением по скорости (компенсация
	  отставания тика на скорости).

	Смещение (attach_offset) — в осях ТОЧКИ КРЕПЛЕНИЯ:
	X — вперёд, Y — влево, Z — вверх; углы — pitch/yaw/roll.

	Отладка: vcity_rp_lvs_anchor_debug 1, vcity_rp_lvs_anchor_mode 1.
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}

if not SERVER then return end

local cvDebug = CreateConVar("vcity_rp_lvs_anchor_debug", "0", FCVAR_ARCHIVE, "V-City LVS anchor debug")
local cvMode = CreateConVar("vcity_rp_lvs_anchor_mode", "0", FCVAR_ARCHIVE, "0 = shadow (UpdateShadow), 1 = frozen + SetPos")
local cvLead = CreateConVar("vcity_rp_lvs_anchor_lead", "1", FCVAR_ARCHIVE, "Упреждение якоря на N тиков вперёд (компенсация отставания на скорости)")

local PINNED_BONES = {
	["ValveBiped.Bip01_Pelvis"] = true,
	["ValveBiped.Bip01_L_Thigh"] = true,
	["ValveBiped.Bip01_R_Thigh"] = true,
	["ValveBiped.Bip01_L_Calf"] = true,
	["ValveBiped.Bip01_R_Calf"] = true,
}

local ActiveAnchors = {} -- [anchor] = veh

local function dbg(...)
	if cvDebug:GetBool() then print("[V-City LVS]", ...) end
end

---------------------------------------------------------------------------
-- Контекст сиденья: pod -> машина -> ключ кресла -> конфиг крепления
---------------------------------------------------------------------------
-- Обобщение GetBRDMSeatContext: вместо захардкоженного класса/роли —
-- любая LVS-машина и ключ кресла из конфига.
local function GetSeatContext(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:InVehicle() then return end

	local pod = ply:GetVehicle()
	if not IsValid(pod) then return end

	local base = ply.lvsGetVehicle and ply:lvsGetVehicle() or nil
	if not IsValid(base) then
		base = pod:GetParent()
		if not IsValid(base) or not base.GetDriverSeat then return end
	end

	local key = VCityLVS.SeatKeyByIndex(pod:lvsGetPodIndex() or 1)
	if not key then return end

	local entry = VCityLVS.FindVehicleEntry(base)
	local extra = entry and entry[key] or nil
	if not istable(extra) then return end
	if not extra.attach and not extra.bone then return end

	return pod, base, key, extra
end

---------------------------------------------------------------------------
-- Точка крепления: текущий transform (как GetAttachmentNow в БРДМ,
-- с той же защитой от мусорных данных)
---------------------------------------------------------------------------
local function GetAttachmentNow(base, extra)
	if extra.attach then
		local id = base:LookupAttachment(extra.attach)
		if not isnumber(id) or id <= 0 then return end

		local att = base:GetAttachment(id)
		if not att then return end

		-- защита от мусорных данных (NaN или далеко от корпуса)
		local pos = att.Pos
		if pos.x ~= pos.x or pos.y ~= pos.y or pos.z ~= pos.z then return end
		if pos:DistToSqr(base:GetPos()) > 400 * 400 then return end

		return pos, att.Ang
	end

	if extra.bone then
		local bone = base:LookupBone(extra.bone)
		if not isnumber(bone) or bone < 0 then return end

		local m = base:GetBoneMatrix(bone)
		if not m then return end

		local pos = m:GetTranslation()
		if pos.x ~= pos.x or pos.y ~= pos.y or pos.z ~= pos.z then return end
		if pos:DistToSqr(base:GetPos()) > 400 * 400 then return end

		return pos, m:GetAngles()
	end
end

---------------------------------------------------------------------------
-- Перенос рэгдолла (как MoveRagdollRigid в БРДМ)
---------------------------------------------------------------------------
local function MoveRagdollRigid(ragdoll, pelvisNum, tpos, tang)
	local pelvis = ragdoll:GetPhysicsObjectNum(pelvisNum)
	if not IsValid(pelvis) then return end

	local cpos, cang = pelvis:GetPos(), pelvis:GetAngles()
	local results = {}

	for i = 0, ragdoll:GetPhysicsObjectCount() - 1 do
		local ph = ragdoll:GetPhysicsObjectNum(i)
		if IsValid(ph) then
			local lp, la = WorldToLocal(ph:GetPos(), ph:GetAngles(), cpos, cang)
			local np, na = LocalToWorld(lp, la, tpos, tang)
			results[i] = { np, na }
		end
	end

	for i, r in pairs(results) do
		local ph = ragdoll:GetPhysicsObjectNum(i)
		if IsValid(ph) then
			ph:SetPos(r[1])
			ph:SetAngles(r[2])
			ph:SetVelocityInstantaneous(vector_origin)
			ph:AddAngleVelocity(-ph:GetAngleVelocity())
		end
	end
end

---------------------------------------------------------------------------
-- Якорь (как CreateGunnerAnchor в БРДМ)
---------------------------------------------------------------------------
local function CreateGunnerAnchor(base, pos, ang)
	local anchor = ents.Create("prop_physics")
	if not IsValid(anchor) then return nil end

	anchor:SetModel("models/props_junk/PopCan01a.mdl")
	anchor:SetPos(pos)
	anchor:SetAngles(ang)
	anchor:Spawn()
	anchor:Activate()
	anchor:SetCollisionGroup(COLLISION_GROUP_WORLD)

	if cvDebug:GetBool() then
		anchor:SetNoDraw(false)
		anchor:SetColor(Color(255, 0, 0))
		anchor:SetRenderMode(RENDERMODE_TRANSALPHA)
	else
		anchor:SetNoDraw(true)
	end

	local phys = anchor:GetPhysicsObject()
	if not IsValid(phys) then
		anchor:Remove()
		return nil
	end

	phys:SetMass(50)
	phys:EnableGravity(false)
	phys:EnableDrag(false)

	if cvMode:GetInt() == 1 then
		phys:EnableMotion(false)
	else
		anchor:MakePhysicsObjectAShadow(false, false)
		phys:Wake()
	end

	anchor.VCityLVSMode = cvMode:GetInt()
	ActiveAnchors[anchor] = base
	if IsValid(base) then base:DeleteOnRemove(anchor) end

	return anchor
end

-- Каждый тик переносим якорь: точка крепления(t) * offset
-- (как BRDM2_GunnerAnchorFollow в БРДМ — с упреждением по скорости)
hook.Add("Tick", "VCityLVS_GunnerAnchorFollow", function()
	for anchor, base in pairs(ActiveAnchors) do
		if not IsValid(anchor) or not IsValid(base) then
			ActiveAnchors[anchor] = nil
			if IsValid(anchor) then anchor:Remove() end
		else
			local apos, aang = GetAttachmentNow(base, anchor.VCityLVSExtra)
			local phys = anchor:GetPhysicsObject()

			if apos and anchor.VCityLVSOffPos and anchor.VCityLVSOffAng and IsValid(phys) then
				local pos, ang = LocalToWorld(anchor.VCityLVSOffPos, anchor.VCityLVSOffAng, apos, aang)

				-- Tick идёт ДО шага физики: точка отстаёт от машины на тик,
				-- на скорости это метры. Упреждаем по скорости корпуса.
				local lead = cvLead:GetFloat() * engine.TickInterval()
				if lead > 0 then
					local bphys = base:GetPhysicsObject()
					if IsValid(bphys) then
						pos = pos + bphys:GetVelocityAtPoint(pos) * lead
					end
				end

				if anchor.VCityLVSMode == 1 then
					phys:SetPos(pos)
					phys:SetAngles(ang)
				else
					phys:UpdateShadow(pos, ang, engine.TickInterval())
				end
			end
		end
	end
end)

---------------------------------------------------------------------------
-- Привязка рагдолла (как Detach / Finish / Attach в БРДМ)
---------------------------------------------------------------------------
local function Detach(ragdoll)
	-- Z-City убирает рэгдолл из pod.rags в колбэке "removeOwO". Мы этот колбэк
	-- отключаем (иначе игрока выкинет из машины), значит чистим список сами —
	-- иначе в кресле остаётся «призрак» и fake_enterveh больше не пускает (см. vcity_lvs_enterfix.lua).
	if VCityLVS.ForgetRagdoll then VCityLVS.ForgetRagdoll(ragdoll) end

	-- Старые сварки Z-City (и наши, если это перепривязка). Колбэк "removeOwO"
	-- у Z-City выкидывает игрока из машины при удалении сварки, а Entity:Remove()
	-- откладывает колбэки на конец кадра, поэтому отключаем сам колбэк.
	ragdoll.removingwelds = true
	for _, weld in ipairs(ragdoll.welds or {}) do
		if IsValid(weld) then
			weld:RemoveCallOnRemove("removeOwO")
			weld:Remove()
		end
	end
	ragdoll.welds = nil

	local old = ragdoll.VCityLVSAnchor
	if IsValid(old) then
		ActiveAnchors[old] = nil
		old:Remove()
	end
	ragdoll.VCityLVSAnchor = nil

	timer.Simple(0.5, function()
		if IsValid(ragdoll) then ragdoll.removingwelds = nil end
	end)
end

local function Finish(ragdoll, base, extra, token)
	if not IsValid(ragdoll) or not IsValid(base) then return end
	if ragdoll.VCityLVSToken ~= token then return end -- уже есть более новая перепривязка

	local pinned, pelvisNum = {}, nil
	for physNum = 0, ragdoll:GetPhysicsObjectCount() - 1 do
		local boneID = ragdoll:TranslatePhysBoneToBone(physNum)
		if boneID >= 0 then
			local name = ragdoll:GetBoneName(boneID)
			if PINNED_BONES[name] then pinned[#pinned + 1] = physNum end
			if name == "ValveBiped.Bip01_Pelvis" then pelvisNum = physNum end
		end
	end

	if #pinned == 0 or pelvisNum == nil then
		print("[V-City LVS] Не нашёл кости таза/ног у рагдолла.")
		return
	end

	-- Цель для таза: точка крепления * смещение из конфига
	local apos, aang = GetAttachmentNow(base, extra)
	if not apos then
		dbg("точка крепления не найдена.")
		return
	end

	local offPos, offAng = VCityLVS.ParseOffset(extra.attach_offset)
	local tpos, tang = LocalToWorld(offPos, offAng, apos, aang)

	ragdoll:SetParent(NULL) -- паррент на корпус от Z-City дерётся со сваркой
	MoveRagdollRigid(ragdoll, pelvisNum, tpos, tang)

	local anchor = CreateGunnerAnchor(base, tpos, tang)
	if not IsValid(anchor) then
		print("[V-City LVS] Не удалось создать якорь.")
		return
	end

	anchor.VCityLVSExtra = extra
	anchor.VCityLVSOffPos = offPos
	anchor.VCityLVSOffAng = offAng

	local newWelds = {}
	for _, physNum in ipairs(pinned) do
		local weld = constraint.Weld(ragdoll, anchor, physNum, 0, 0, false, false)
		if IsValid(weld) then newWelds[#newWelds + 1] = weld end
	end

	if #newWelds ~= #pinned then
		for _, weld in ipairs(newWelds) do
			if IsValid(weld) then weld:Remove() end
		end
		ActiveAnchors[anchor] = nil
		anchor:Remove()
		print("[V-City LVS] Не все сварки создались.")
		return
	end

	if not ragdoll.VCityLVSNoCollided then
		ragdoll.VCityLVSNoCollided = true
		for physNum = 0, ragdoll:GetPhysicsObjectCount() - 1 do
			constraint.NoCollide(ragdoll, base, physNum, 0)
		end
	end

	ragdoll.welds = newWelds
	ragdoll.VCityLVSAnchor = anchor

	dbg("рагдолл привязан к", extra.attach or extra.bone, offPos)

	if not ragdoll.VCityLVSCleanupSet then
		ragdoll.VCityLVSCleanupSet = true
		ragdoll:CallOnRemove("VCityLVS_AnchorCleanup", function()
			local a = ragdoll.VCityLVSAnchor
			if IsValid(a) then
				ActiveAnchors[a] = nil
				a:Remove()
			end
		end)
	end
end

local function Attach(ragdoll, base, extra)
	ragdoll.VCityLVSToken = (ragdoll.VCityLVSToken or 0) + 1
	local token = ragdoll.VCityLVSToken

	Detach(ragdoll)

	-- Даём движку тик-другой, чтобы старые сварки реально исчезли
	-- (удаление отложенное), иначе они дёрнут перенесённый рагдолл назад.
	timer.Simple(0.06, function() Finish(ragdoll, base, extra, token) end)
end

---------------------------------------------------------------------------
-- Точки входа (как хуки в БРДМ)
---------------------------------------------------------------------------
hook.Add("Ragdoll_Create", "VCityLVS_GunnerSeatRagdollAnchor", function(ply, ragdoll)
	if not IsValid(ragdoll) then return end

	local pod, base, _, extra = GetSeatContext(ply)
	if not IsValid(base) or not extra then return end

	-- кресло, в чьём списке rags Z-City держит этот рэгдолл
	ragdoll.VCityLVSPod = pod

	-- Z-City может повторно использовать тот же FakeRagdoll после выхода
	-- из сиденья. Если старый якорь уже очищен, привязываем снова.
	if ragdoll.VCityLVSDefault then
		if not IsValid(ragdoll.VCityLVSAnchor) then
			Attach(ragdoll, base, extra)
		end
		return
	end

	-- Запоминаем, куда Z-City посадила таз (в осях корпуса)
	local pelvisNum
	for physNum = 0, ragdoll:GetPhysicsObjectCount() - 1 do
		local boneID = ragdoll:TranslatePhysBoneToBone(physNum)
		if boneID >= 0 and ragdoll:GetBoneName(boneID) == "ValveBiped.Bip01_Pelvis" then
			pelvisNum = physNum
		end
	end
	if pelvisNum == nil then return end

	local pelvisPhys = ragdoll:GetPhysicsObjectNum(pelvisNum)
	if not IsValid(pelvisPhys) then return end

	ragdoll.VCityLVSDefault = {
		pos = base:WorldToLocal(pelvisPhys:GetPos()),
		ang = base:WorldToLocalAngles(pelvisPhys:GetAngles()),
	}

	Attach(ragdoll, base, extra)
end)

hook.Add("PlayerLeaveVehicle", "VCityLVS_GunnerSeatAnchorCleanup", function(ply, pod)
	if not IsValid(ply) or not IsValid(pod) then return end

	local ragdoll = ply.FakeRagdoll
	if not IsValid(ragdoll) then return end

	-- трогаем только рэгдоллы, с которыми работал якорь
	if not ragdoll.VCityLVSDefault and not IsValid(ragdoll.VCityLVSAnchor) then return end

	ragdoll.VCityLVSToken = (ragdoll.VCityLVSToken or 0) + 1 -- отменяем отложенную привязку
	Detach(ragdoll)
end)

---------------------------------------------------------------------------
-- Перепривязка/живая правка из меню «Седалище» (vcity_rp_sidalishe)
---------------------------------------------------------------------------
function VCityLVS.ReattachSeatPlayers(veh, key)
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and ply:InVehicle() then
			local pod = ply:GetVehicle()
			local base = ply.lvsGetVehicle and ply:lvsGetVehicle() or nil
			if IsValid(base) and base == veh then
				local pkey = VCityLVS.SeatKeyByIndex((IsValid(pod) and pod:lvsGetPodIndex()) or 1)
				if pkey == key then
					local entry = VCityLVS.FindVehicleEntry(veh)
					local extra = entry and entry[key] or nil
					local ragdoll = ply.FakeRagdoll

					if IsValid(ragdoll) and istable(extra) and (extra.attach or extra.bone) then
						local anchor = ragdoll.VCityLVSAnchor
						if IsValid(anchor) then
							-- Живая правка: у якоря меняется только смещение —
							-- тело плавно переедет, без перепривязки (как в БРДМ)
							local offPos, offAng = VCityLVS.ParseOffset(extra.attach_offset)
							anchor.VCityLVSExtra = extra
							anchor.VCityLVSOffPos = offPos
							anchor.VCityLVSOffAng = offAng
						else
							Attach(ragdoll, base, extra)
						end
					end
				end
			end
		end
	end
end

print("[V-City LVS] Якорь тела экипажа подключён (порт схемы БРДМ).")
