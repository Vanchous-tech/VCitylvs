--[[---------------------------------------------------------
	Тулган «V-City LVS Seats» — быстрая настройка кресел.
	ЛКМ — выбрать машину (наведите прицел), в чат придёт список кресел.
	Колесо/R (Reload) — переключить активное кресло (водитель -> p2 -> p3...).
	ПКМ — поставить активное кресло в точку прицела.

	Точная доводка — команды vcity_rp_lvs_seat_set/move/here, затем _save.
-----------------------------------------------------------]]

TOOL.Category = "V-City"
TOOL.Name = "V-City LVS Seats"

if SERVER then
	util.AddNetworkString("VCityLVS.ToolSay")

	local function Say(ply, msg)
		if IsValid(ply) then ply:ChatPrint("[V-City LVS] " .. msg) end
	end

	local function Allowed(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then
			Say(ply, "Инструмент доступен только суперадминам.")
			return false
		end
		return true
	end

	function TOOL:LeftClick(trace)
		if CLIENT then return true end
		local ply = self:GetOwner()
		if not Allowed(ply) then return true end

		local veh = VCityLVS.TraceVehicle(ply)
		if not IsValid(veh) then
			Say(ply, "Не вижу LVS-машины: сядьте в неё или наведите прицел.")
			return true
		end

		ply:SetNWEntity("VCityLVS_Selected", veh)
		ply:SetNWInt("VCityLVS_ActivePod", 1)

		local seats = VCityLVS.ListSeats(veh)
		Say(ply, "Выбрана " .. veh:GetClass() .. ", кресел: " .. #seats .. ". Активное — driver. Колесо мыши/R — следующее кресло.")
		for _, s in ipairs(seats) do
			Say(ply, string.format("%s%s — %s", s.key, s.gun and " [оружие]" or "", VCityLVS.FormatPosAng(s.pos, s.ang)))
		end

		return true
	end

	function TOOL:Reload(trace)
		if CLIENT then return true end
		local ply = self:GetOwner()
		if not Allowed(ply) then return true end

		local veh = ply:GetNWEntity("VCityLVS_Selected")
		if not IsValid(veh) then
			Say(ply, "Сначала выберите машину (ЛКМ).")
			return true
		end

		local seats = VCityLVS.ListSeats(veh)
		if #seats == 0 then
			Say(ply, "У машины нет кресел.")
			return true
		end

		local current = ply:GetNWInt("VCityLVS_ActivePod", 1)
		local nextIndex = (current % #seats) + 1
		ply:SetNWInt("VCityLVS_ActivePod", nextIndex)

		Say(ply, "Активное кресло: " .. seats[nextIndex].key)
		return true
	end

	function TOOL:RightClick(trace)
		if CLIENT then return true end
		local ply = self:GetOwner()
		if not Allowed(ply) then return true end

		local veh = ply:GetNWEntity("VCityLVS_Selected")
		if not IsValid(veh) then
			Say(ply, "Сначала выберите машину (ЛКМ).")
			return true
		end

		local seats = VCityLVS.ListSeats(veh)
		local index = ply:GetNWInt("VCityLVS_ActivePod", 1)
		local seat = seats[index]
		if not seat then
			Say(ply, "Активное кресло не найдено.")
			return true
		end

		if not trace or not trace.Hit then
			Say(ply, "Наведите инструмент на поверхность — кресло встанет в точку прицела.")
			return true
		end

		local newPos = veh:WorldToLocal(trace.HitPos)
		if not VCityLVS.MovePod(seat.pod, veh, newPos, seat.ang) then
			Say(ply, "Не удалось сдвинуть кресло.")
			return true
		end

		local entry = VCityLVS.FindVehicleEntry(veh)
		if not entry then
			local key = veh:GetClass()
			VCityLVS.SeatConfig.vehicles[key] = {}
			entry = VCityLVS.SeatConfig.vehicles[key]
		end
		entry[seat.key] = VCityLVS.PackPosAng(newPos, seat.ang)

		Say(ply, seat.key .. " -> " .. VCityLVS.FormatPosAng(newPos, seat.ang) .. " (vcity_rp_lvs_seat_save, чтобы закрепить)")
		return true
	end
end

if CLIENT then
	function TOOL:DrawHUD()
		local ply = LocalPlayer()
		local veh = ply:GetNWEntity("VCityLVS_Selected")
		if not IsValid(veh) then return end

		local index = ply:GetNWInt("VCityLVS_ActivePod", 1)
		local pod = nil

		if index == 1 then
			pod = veh.GetDriverSeat and veh:GetDriverSeat()
		else
			pod = istable(veh.pSeats) and veh.pSeats[index - 1] or nil
		end
		if not IsValid(pod) then return end

		local pos = pod:GetPos()
		local ang = pod:GetAngles()

		cam.Start3D()
			render.DrawWireframeBox(pos, ang, Vector(-8, -8, -8), Vector(8, 8, 8), Color(255, 128, 40, 230), true)
		cam.End3D()

		local screen = pos:ToScreen()
		if screen.visible then
			draw.SimpleTextOutlined(
				"кресло " .. index .. " (R — сюда, колесо — следующее)",
				"DermaDefault",
				screen.x, screen.y - 16,
				Color(255, 128, 40),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER,
				1, Color(9, 10, 12)
			)
		end
	end
end
