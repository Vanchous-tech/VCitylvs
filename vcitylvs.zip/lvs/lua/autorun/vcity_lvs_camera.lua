--[[---------------------------------------------------------
	V-City LVS ↔ Z-City: камера по машинам (и по креслам).

	Какой вид получает игрок в LVS-технике:
	  "lvs"   — камера LVS (башня, прицел, sight/gunner_eye)
	  "zcity" — камера Z-City (голова/рэгдолл, как в обычной игре)

	Приоритет (от высшего к низшему):
	  1. настройка КРЕСЛА   (cameras["driver"|"p2"|...])
	  2. настройка МАШИНЫ   (camera)
	  3. глобальный конвар  vcity_rp_lvs_zcity_camera (1 = LVS, 0 = Z-City)

	Конфиг — тот же data/vcity_rp/lvs_seats.json, запись машины:
	  "lvs_wheeldrive_xxx": {
	      "camera": "zcity",
	      "cameras": { "p3": "lvs" },     -- необязательно, по креслам
	      "driver": { ... крепление ... }
	  }

	Клиент получает настройки через NWString на машине:
	  VCityLVS_Cam            — по умолчанию для машины ("" = глобальный)
	  VCityLVS_Cam_<ключ>     — для кресла ("" = как у машины)

	Команды (суперадмин):
	  vcity_rp_lvs_camera                      — показать текущие
	  vcity_rp_lvs_camera lvs|zcity|default    — вся машина
	  vcity_rp_lvs_camera lvs|zcity|default 2  — одно кресло (driver | 2 | 3 ...)
	Сохраняется сразу. Меню: vcity_rp_sidalishe (блок «Камера»).
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}

-- "lvs"/"zcity" -> то же; "default"/""/мусор -> nil
function VCityLVS.NormalizeCamMode(value)
	if not isstring(value) then return nil end
	value = string.lower(value)
	if value == "lvs" or value == "zcity" then return value end
	return nil
end

-- Чистая логика выбора (тестируется): seatMode, vehMode — "lvs"/"zcity"/nil
function VCityLVS.PickCamMode(seatMode, vehMode, globalLVS)
	return VCityLVS.NormalizeCamMode(seatMode)
		or VCityLVS.NormalizeCamMode(vehMode)
		or (globalLVS and "lvs" or "zcity")
end

-- Машина + ключ кресла по любой сущности (машина или под). Ключ может быть nil.
function VCityLVS.CamHost(ent)
	if not IsValid(ent) then return NULL, nil end

	if ent.LVS == true and isfunction(ent.GetDriverSeat) then return ent, nil end

	local parent = ent:GetParent()
	if IsValid(parent) and parent.LVS == true and isfunction(parent.GetDriverSeat) then
		local index = ent.lvsGetPodIndex and ent:lvsGetPodIndex() or nil
		return parent, VCityLVS.SeatKeyByIndex and VCityLVS.SeatKeyByIndex(index) or nil
	end

	return NULL, nil
end

-- Итоговый режим камеры: "lvs" или "zcity". ent — машина или под, key — ключ кресла (необязательно).
function VCityLVS.ResolveCamera(ent, key)
	local host, podKey = VCityLVS.CamHost(ent)
	key = key or podKey

	local globalLVS = true
	local cv = VCityLVS.cvCamera
	if cv then globalLVS = cv:GetBool() end

	if not IsValid(host) then return globalLVS and "lvs" or "zcity" end

	local seatMode = key and host:GetNWString("VCityLVS_Cam_" .. key, "") or nil
	local vehMode = host:GetNWString("VCityLVS_Cam", "")

	return VCityLVS.PickCamMode(seatMode, vehMode, globalLVS)
end

if SERVER then
	util.AddNetworkString("vcity_lvs_cam_save")

	local function Say(ply, msg)
		if IsValid(ply) then ply:ChatPrint("[V-City LVS] " .. msg) else print("[V-City LVS] " .. msg) end
	end

	-- Записать настройки конфига в NWString машины
	function VCityLVS.PublishCamera(veh)
		if not IsValid(veh) or veh.LVS ~= true or not isfunction(veh.GetDriverSeat) then return end

		local entry = VCityLVS.FindVehicleEntry and VCityLVS.FindVehicleEntry(veh) or nil
		local cams = istable(entry) and istable(entry.cameras) and entry.cameras or {}

		veh:SetNWString("VCityLVS_Cam", VCityLVS.NormalizeCamMode(istable(entry) and entry.camera or nil) or "")

		-- ключи кресел: driver + p2..pN (с запасом; лишние — пустые строки)
		local keys = { "driver" }
		for i = 2, 16 do keys[#keys + 1] = "p" .. i end
		for _, k in ipairs(keys) do
			veh:SetNWString("VCityLVS_Cam_" .. k, VCityLVS.NormalizeCamMode(cams[k]) or "")
		end
	end

	function VCityLVS.PublishAllCameras()
		for _, ent in ipairs(ents.GetAll()) do
			if IsValid(ent) and ent.LVS == true and isfunction(ent.GetDriverSeat) then
				VCityLVS.PublishCamera(ent)
			end
		end
	end

	hook.Add("OnEntityCreated", "VCityLVS.PublishCamera", function(ent)
		timer.Simple(0, function()
			if IsValid(ent) and ent.LVS == true and isfunction(ent.GetDriverSeat) then
				VCityLVS.PublishCamera(ent)
			end
		end)
	end)

	-- Конфиг читается в vcity_lvs_seats.lua позже этого файла: публикуем после старта
	hook.Add("InitPostEntity", "VCityLVS.PublishCameraInit", function()
		VCityLVS.PublishAllCameras()
	end)

	-- Установить режим (scope: nil = вся машина, иначе ключ кресла); mode: "lvs"/"zcity"/nil
	function VCityLVS.SetCameraMode(veh, scope, mode)
		if not IsValid(veh) or veh.LVS ~= true or not isfunction(veh.GetDriverSeat) then return false, "Выберите машину LVS." end

		local entry, configKey = VCityLVS.FindVehicleEntry(veh)
		if not entry then
			configKey = veh:GetClass()
			VCityLVS.SeatConfig.vehicles[configKey] = VCityLVS.SeatConfig.vehicles[configKey] or {}
			entry = VCityLVS.SeatConfig.vehicles[configKey]
		end

		mode = VCityLVS.NormalizeCamMode(mode)

		if scope then
			entry.cameras = istable(entry.cameras) and entry.cameras or {}
			entry.cameras[scope] = mode
			if next(entry.cameras) == nil then entry.cameras = nil end
		else
			entry.camera = mode
		end

		-- настройка применяется ко ВСЕМ машинам того же класса/модели
		VCityLVS.PublishAllCameras()

        if VCityLVS.SaveSeatConfig then
            local ok, why = VCityLVS.SaveSeatConfig()
            if not ok then return false, why end
        end
		return true
	end

	local MODE_NAMES = { lvs = "камера LVS", zcity = "камера Z-City" }

	local function Describe(veh)
		local host = veh
		local lines = {}
		local globalName = (VCityLVS.cvCamera and VCityLVS.cvCamera:GetBool()) and "LVS" or "Z-City"
		local vehMode = host:GetNWString("VCityLVS_Cam", "")
		lines[#lines + 1] = "Машина: " .. (MODE_NAMES[vehMode] or ("по умолчанию (глобально: " .. globalName .. ")"))

		for _, s in ipairs(VCityLVS.ListSeats(veh)) do
			local m = host:GetNWString("VCityLVS_Cam_" .. s.key, "")
			if m ~= "" then
				lines[#lines + 1] = "  " .. s.key .. ": " .. (MODE_NAMES[m] or m)
			end
		end
		return lines
	end

	concommand.Add("vcity_rp_lvs_camera", function(ply, _, args)
		if IsValid(ply) and not ply:IsSuperAdmin() then
			Say(ply, "Команда доступна только суперадминам.")
			return
		end

		local veh = VCityLVS.TraceVehicle(ply)
		if not IsValid(veh) then
			Say(ply, "Не вижу LVS-машины: сядьте в неё или наведите прицел.")
			return
		end

		if not args[1] then
			Say(ply, "Класс: " .. veh:GetClass())
			for _, l in ipairs(Describe(veh)) do Say(ply, l) end
			Say(ply, "Задать: vcity_rp_lvs_camera lvs|zcity|default [кресло: driver|2|3...]")
			return
		end

		local word = string.lower(args[1])
		if word ~= "lvs" and word ~= "zcity" and word ~= "default" then
			Say(ply, "Режим: lvs | zcity | default")
			return
		end

		local scope
		if args[2] then
			scope = VCityLVS.SeatKey(args[2])
			if not scope then
				Say(ply, "Кресло задаётся так: driver | 2 | 3 ...")
				return
			end
		end

        local ok, why = VCityLVS.SetCameraMode(veh, scope, word)
        if not ok then Say(ply, "Не сохранено: " .. tostring(why) .. " Изменения только в памяти.") return end
		Say(ply, (scope and ("Кресло " .. scope) or "Машина " .. veh:GetClass()) .. " -> " .. (MODE_NAMES[word] or "по умолчанию") .. " (сохранено)")
	end)

	-- Из меню седалища
	net.Receive("vcity_lvs_cam_save", function(_, ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end

		local veh = net.ReadEntity()
		if not IsValid(veh) or veh.LVS ~= true or not isfunction(veh.GetDriverSeat) then return end

		local scopeRaw = net.ReadString()
		local scope = nil
		if scopeRaw ~= "" and scopeRaw ~= "vehicle" then
			scope = VCityLVS.SeatKey(scopeRaw)
			if not scope then return end
		end

		local word = string.lower(net.ReadString())
		if word ~= "lvs" and word ~= "zcity" and word ~= "default" then return end

        local ok, why = VCityLVS.SetCameraMode(veh, scope, word)
        if not ok then Say(ply, "Не сохранено: " .. tostring(why) .. " Изменения только в памяти.") return end
		Say(ply, (scope and ("Кресло " .. scope) or "Машина") .. ": " .. (MODE_NAMES[word] or "камера по умолчанию") .. " (сохранено)")
	end)
end
