--[[---------------------------------------------------------
	V-City LVS: меню настройки седалища (команда vcity_rp_sidalishe)

    Единая настройка тела: опора на корпус, attachment или кость.
    Туловище и ноги фиксируются, руки и голова остаются свободными.

	Живой предпросмотр: полупрозрачное тело стоит на месте
	посадки прямо в меню. «Сохранить» пишет в
	data/vcity_rp/lvs_seats.json, «Применить» пересаживает
	реальные фейк-рэгдоллы в этом кресле.

	Команда и сохранение — только суперадминам.
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}

-- Проверка данных из меню (общая логика, тестируется)
-- data = { mode = "none"|"attach"|"bone", name = "...", attach_offset = {{x,y,z},{p,y,r}} }
function VCityLVS.ValidateSeatExtras(data)
	if not istable(data) then return nil end

	local mode = data.mode
	if mode ~= "none" and mode ~= "attach" and mode ~= "bone" then return nil end

    local pose = data.pose or "default"
    if pose ~= "default" and pose ~= "sit" and pose ~= "lie" then return nil end
    if data.body_lock ~= nil and type(data.body_lock) ~= "boolean" then return nil end
	local out = { mode = mode, pose = pose, body_lock = data.body_lock == true }

	if mode ~= "none" then
		local name = isstring(data.name) and data.name or nil
		if not name or #name == 0 or #name > 128 or string.find(name, "%c") then return nil end
		out.name = name
	end

    if data.attach_offset ~= nil then
        local off = data.attach_offset
        if not istable(off) or not istable(off[1]) or not istable(off[2]) then return nil end
        for part = 1, 2 do
            local limit = part == 1 and 8192 or 36000
            for i = 1, 3 do
                local n = tonumber(off[part][i])
                if not n or n ~= n or math.abs(n) > limit then return nil end
            end
        end
    end
	local offPos, offAng
	if VCityLVS.ParseOffset then
		offPos, offAng = VCityLVS.ParseOffset(data.attach_offset)
	else
		offPos, offAng = Vector(0, 0, 0), Angle(0, 0, 0)
	end

	local packed = VCityLVS.PackPosAng(offPos, offAng)
	out.attach_offset = { packed.pos, packed.ang }
	return out
end

if SERVER then
	util.AddNetworkString("vcity_lvs_seatui_open")
	util.AddNetworkString("vcity_lvs_seatui_save")
    util.AddNetworkString("vcity_lvs_seatui_origin")

	local function SendMenu(ply, veh)
		local seats = VCityLVS.ListSeats(veh)
		local entry = VCityLVS.FindVehicleEntry(veh)

		local payload = {
			class = veh:GetClass(),
			model = veh:GetModel() or "",
			order = {},
			seats = {},
			camera = entry and VCityLVS.NormalizeCamMode and VCityLVS.NormalizeCamMode(entry.camera) or nil,
			cameras = entry and istable(entry.cameras) and entry.cameras or {},
            body_draw = entry and VCityLVS.NormalizeBodyDraw(entry.body_draw) or nil,
            body_draw_seats = entry and istable(entry.body_draw_seats) and entry.body_draw_seats or {},
		}

		for _, s in ipairs(seats) do
			local extra = entry and entry[s.key] or nil
			payload.seats[s.key] = {
				index = s.index,
				gun = s.gun or false,
				attach = extra and extra.attach or nil,
				bone = extra and extra.bone or nil,
				attach_offset = extra and extra.attach_offset or nil,
                pose = extra and extra.pose or "default",
                body_lock = extra and extra.body_lock == true or false,
                body_origin = extra and extra.body_origin or nil,
			}
			table.insert(payload.order, s.key)
		end

		local json = util.TableToJSON(payload)
		net.Start("vcity_lvs_seatui_open")
			net.WriteEntity(veh)
			net.WriteUInt(#json, 32)
			net.WriteData(json, #json)
		net.Send(ply)
	end

    -- Re-open with fresh values after a successful server-side import.
    VCityLVS.SendSeatMenu = SendMenu

	concommand.Add("vcity_rp_sidalishe", function(ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then
			if IsValid(ply) then ply:ChatPrint("[V-City LVS] Команда доступна только суперадминам.") end
			return
		end

		local veh = VCityLVS.TraceVehicle(ply)
		if not IsValid(veh) then
			ply:ChatPrint("[V-City LVS] Сядьте в машину или наведите на неё прицел.")
			return
		end

		SendMenu(ply, veh)
	end)

    -- Capture once, at explicit save, using this seat's original pelvis (not
    -- its current, possibly already offset, position). An empty seat uses the
    -- seat transform. No client may supply the saved anchor coordinates.
    local function CaptureBodyOrigin(veh, key)
        if not isfunction(VCityLVS.ListSeats) then return nil end
        local pod
        for _, item in ipairs(VCityLVS.ListSeats(veh) or {}) do
            if item.key == key then pod = item.pod break end
        end
        if not IsValid(pod) then return nil end
        local driver = isfunction(pod.GetDriver) and pod:GetDriver() or nil
        local rag = IsValid(driver) and driver.FakeRagdoll or nil
        local pos, ang
        if IsValid(rag) and (not IsValid(rag.VCityLVSPod) or rag.VCityLVSPod == pod) then
            local original = rag.VCityLVSPod == pod and rag.VCityLVSOriginalSeat or nil
            if istable(original) and original.pos and original.ang then
                pos, ang = original.pos, original.ang
            elseif isfunction(rag.LookupBone) and isfunction(rag.TranslateBoneToPhysBone)
                and isfunction(rag.GetPhysicsObjectNum) then
                local bone = rag:LookupBone("ValveBiped.Bip01_Pelvis")
                local physID = bone and rag:TranslateBoneToPhysBone(bone) or -1
                local phys = physID >= 0 and rag:GetPhysicsObjectNum(physID) or nil
                if IsValid(phys) then
                    pos = veh:WorldToLocal(phys:GetPos())
                    ang = veh:WorldToLocalAngles(phys:GetAngles())
                end
            end
        end
        if not pos then
            pos = veh:WorldToLocal(pod:GetPos())
            ang = veh:WorldToLocalAngles(pod:GetAngles())
        end
        local packed = VCityLVS.PackPosAng(pos, ang)
        if VCityLVS.ValidBodyOrigin(packed) then return packed end
        return nil
    end

	net.Receive("vcity_lvs_seatui_save", function(len, ply)
		if not IsValid(ply) or not ply:IsSuperAdmin() then return end

		local veh = net.ReadEntity()
		if not IsValid(veh) or not VCityLVS.IsLVSRelated(veh) then return end

		local key = VCityLVS.SeatKey(net.ReadString())
		if not key then return end

		local dataLen = net.ReadUInt(32)
        if dataLen == 0 or dataLen > 8192 or dataLen * 8 > len then return end
		local raw = util.JSONToTable(tostring(net.ReadData(dataLen)))
		local extras = VCityLVS.ValidateSeatExtras(raw)
		if not extras then
			ply:ChatPrint("[V-City LVS] Некорректные данные крепления.")
			return
		end

		local apply = net.ReadBool()
		local persist = net.ReadBool()

        -- Refuse a missing named target BEFORE touching any saved seat data.
        if extras.mode == "attach" then
            local id = veh:LookupAttachment(extras.name)
            if not isnumber(id) or id <= 0 then
                ply:ChatPrint("[V-City LVS] Аттачмент не найден на этой машине. Настройки не изменены.")
                return
            end
        elseif extras.mode == "bone" then
            local id = veh:LookupBone(extras.name)
            if not isnumber(id) or id < 0 then
                ply:ChatPrint("[V-City LVS] Кость не найдена на этой машине. Настройки не изменены.")
                return
            end
        end

		local entry, configKey = VCityLVS.FindVehicleEntry(veh)
		if not entry then
			configKey = veh:GetClass()
			VCityLVS.SeatConfig.vehicles[configKey] = VCityLVS.SeatConfig.vehicles[configKey] or {}
			entry = VCityLVS.SeatConfig.vehicles[configKey]
		end

        -- Change just the fields managed by this menu. Preserve seat pos/ang
        -- set by the tool or console, and any other future per-seat fields.
        local seat = istable(entry[key]) and entry[key] or {}
        local origin = seat.body_origin
        if extras.body_lock and extras.mode == "none" and persist and not VCityLVS.ValidBodyOrigin(origin) then
            origin = CaptureBodyOrigin(veh, key)
            if not origin then
                ply:ChatPrint("[V-City LVS] Не удалось запомнить опорную точку: кресло не найдено. Ничего не сохранено.")
                return
            end
        end
        if not extras.body_lock then origin = nil end
        seat.body_origin = origin
        seat.attach = extras.mode == "attach" and extras.name or nil
        seat.bone = extras.mode == "bone" and extras.name or nil
        seat.body_lock = extras.body_lock and true or nil
        seat.attach_offset = (extras.mode ~= "none" or VCityLVS.HasBodyOffset(extras.attach_offset)) and extras.attach_offset or nil
        seat.pose = extras.pose ~= "default" and extras.pose or nil
        entry[key] = next(seat) and seat or nil

        if persist then
            local ok, why = VCityLVS.SaveSeatConfig()
            if not ok then
                ply:ChatPrint("[V-City LVS] Не сохранено: " .. tostring(why) .. " Изменения только в памяти.")
                return
            end
        end

		if apply then
			-- перепривязка настоящих тел через якорь (vcity_lvs_anchor.lua)
			if VCityLVS.ReattachSeatPlayers then
				VCityLVS.ReattachSeatPlayers(veh, key, ply, persist)
			end
		end

        if not persist then return end -- живая правка: без спама в чат
        -- Return the actual server-captured hull reference for accurate preview.
        net.Start("vcity_lvs_seatui_origin")
            net.WriteEntity(veh)
            net.WriteString(key)
            net.WriteBool(VCityLVS.ValidBodyOrigin(origin))
            if VCityLVS.ValidBodyOrigin(origin) then
                local op, oa = VCityLVS.ParseOffset({origin.pos, origin.ang})
                net.WriteVector(op)
                net.WriteAngle(oa)
            end
        net.Send(ply)
        local target = extras.mode == "none" and "корпус" or ((extras.mode == "attach" and "аттачмент: " or "кость: ") .. extras.name)
		ply:ChatPrint("[V-City LVS] Крепление " .. key .. " сохранено"
            .. (extras.body_lock and (" (опора: " .. target .. "; режим фиксации туловища и ног).") or extras.mode == "none" and " (без фиксирования; перепосадите игрока)." or (" (опора: " .. target .. ")."))
			.. (apply and " Применение запущено; ошибки появятся в чате и консоли сервера." or ""))
	end)

	print("[V-City LVS] Меню седалища готово: vcity_rp_sidalishe")
end

if CLIENT then
	surface.CreateFont("VCitySeatTitle", {
		font = "Arial", size = 17, weight = 700, antialias = true, extended = true,
	})
	surface.CreateFont("VCitySeatText", {
		font = "Arial", size = 14, weight = 500, antialias = true, extended = true,
	})

	local ACCENT = Color(255, 128, 40)
	local ACCENT_DIM = Color(255, 179, 115)
	local BG = Color(10, 11, 13, 245)
	local PANEL = Color(17, 18, 22, 240)
	local BORDER = Color(43, 44, 49, 220)
	local TEXT = Color(233, 234, 238)
	local TEXT_DIM = Color(143, 147, 157)
	local GREEN = Color(126, 205, 126)
	local RED = Color(224, 110, 96)

	local function PaintButton(pnl, w, h, text, baseCol, hoverCol)
		local grow = pnl:IsHovered() and 2 or 0
		surface.SetDrawColor(pnl:IsHovered() and (hoverCol or Color(52, 42, 32)) or (baseCol or Color(30, 31, 36)))
		surface.DrawRect(-grow / 2, -grow / 2, w + grow, h + grow)
		surface.SetDrawColor(BORDER)
		surface.DrawOutlinedRect(-grow / 2, -grow / 2, w + grow, h + grow, 1)
		draw.SimpleText(text, "VCitySeatText", w / 2, h / 2, pnl:IsHovered() and ACCENT_DIM or TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	-- ---------- предпросмотр тела ----------
	local ghost = nil

    -- Helpful when a custom player model contains no usable sitting sequence.
    concommand.Add("vcity_lvs_poseinfo", function()
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        print("[V-City LVS] Модель игрока: " .. tostring(ply:GetModel()))
        local model = IsValid(ghost) and ghost or ply
        local ok, candidates = pcall(VCityLVS.PoseSequenceCandidates, model, "sit")
        if not ok or not candidates or #candidates == 0 then
            print("[V-City LVS] Сидячие анимации не найдены.")
            return
        end
        for _, candidate in ipairs(candidates) do
            print("[V-City LVS] Кандидат: " .. candidate.name .. " (" .. tostring(candidate.id) .. "), кадр " .. tostring(candidate.cycle))
        end
    end)

	local function RemoveGhost()
		if IsValid(ghost) then ghost:Remove() end
		ghost = nil
	end

	local function GhostTransform(veh, mode, name, offPos, offAng, seatKey, origin)
		if not IsValid(veh) then return nil end

		if mode == "attach" and name and name ~= "" then
			local id = veh:LookupAttachment(name)
			local att = (id and id > 0) and veh:GetAttachment(id) or nil
			if att then
				return LocalToWorld(offPos, offAng, att.Pos, att.Ang)
			end
		elseif mode == "bone" and name and name ~= "" then
			local bone = veh:LookupBone(name)
			if bone and bone >= 0 then
				local m = veh:GetBoneMatrix(bone)
				if m then
					return LocalToWorld(offPos, offAng, m:GetTranslation(), m:GetAngles())
				end
			end
		end

        if mode == "none" then
            if VCityLVS.ValidBodyOrigin(origin) then
                local refPos, refAng = VCityLVS.ParseOffset({origin.pos, origin.ang})
                return LocalToWorld(offPos, offAng, veh:LocalToWorld(refPos), veh:LocalToWorldAngles(refAng))
            end
            local pod = seatKey == "driver" and veh:GetDriverSeat() or nil
            if not IsValid(pod) and isfunction(veh.GetPassengerSeats) then
                for _, candidate in pairs(veh:GetPassengerSeats()) do
                    if IsValid(candidate) and candidate.lvsGetPodIndex
                        and VCityLVS.SeatKeyByIndex(candidate:lvsGetPodIndex()) == seatKey then
                        pod = candidate
                        break
                    end
                end
            end
            if IsValid(pod) then return LocalToWorld(offPos, offAng, pod:GetPos(), pod:GetAngles()) end
        end
		return nil
	end

    local function PoseStatus(text, isError)
        local label = VCityLVS.SeatPoseStatus
        if not IsValid(label) then return end
        label:SetText(text)
        label:SetTextColor(isError and RED or TEXT_DIM)
    end

    local function PlaceGhost(model)
        if not IsValid(model) or not model.VCityTargetPos or not model.VCityTargetAng then return end
        local pos = model.VCityTargetPos
        local base = model.VCityTargetAng
        local ang = Angle(base.p, base.y, base.r)
        if model.VCityPoseRotate then ang:RotateAroundAxis(ang:Right(), 90) end
        model:SetRenderOrigin(nil)
        model:SetRenderAngles(nil)
        model:SetPos(pos)
        model:SetAngles(ang)
        if model.VCityPoseReady then
            -- The attachment/offset targets the physics pelvis, not the model's
            -- feet/origin. Align the preview pelvis to that point as well.
            model:InvalidateBoneCache()
            model:SetupBones()
            local pelvis = model:LookupBone("ValveBiped.Bip01_Pelvis")
            local mat = pelvis and model:GetBoneMatrix(pelvis) or nil
            if mat then
                local delta = mat:GetTranslation() - pos
                if delta:LengthSqr() < 128 * 128 then pos = pos - delta end
            end
        end
        model:SetPos(pos)
        model:SetAngles(ang)
        model.VCityGhostPos, model.VCityGhostAng = pos, ang
    end

    local function BeginGhostPose(model, pose, preferDriver)
        model.VCityPoseRevision = (model.VCityPoseRevision or 0) + 1
        local revision = model.VCityPoseRevision
        model.VCityPoseReady, model.VCityPoseRotate = false, false
        PoseStatus("Подбираю анимацию для модели игрока…", false)
        -- ClientsideModel has just received a model: sequence operations must
        -- wait until the next tick, rather than silently leaving a standing pose.
        timer.Simple(0, function()
            if not IsValid(model) or model ~= ghost or model.VCityPoseRevision ~= revision then return end
            local previewPose = pose == "default" and "sit" or pose
            local ok, candidates = pcall(VCityLVS.PoseSequenceCandidates, model, previewPose, preferDriver)
            if not ok then candidates = {} end
            local index = 0
            local function tryNext()
                if not IsValid(model) or model ~= ghost or model.VCityPoseRevision ~= revision then return end
                index = index + 1
                local candidate = candidates[index]
                if not candidate then
                    model.VCityPoseReady = false
                    PoseStatus("Для этой модели не удалось найти подходящую позу. Предпросмотр скрыт; проверьте консоль сервера.", true)
                    return
                end
                model:ResetSequence(candidate.id)
                model:SetPlaybackRate(0)
                model:SetCycle(candidate.cycle)
                model.VCityPoseRotate = candidate.rotate
                PlaceGhost(model)
                timer.Simple(0, function()
                    if not IsValid(model) or model ~= ghost or model.VCityPoseRevision ~= revision then return end
                    model:InvalidateBoneCache()
                    model:SetupBones()
                    if previewPose == "sit" then
                        local measured, seated = pcall(VCityLVS.IsSittingPose, model)
                        if not measured or seated ~= true then tryNext() return end
                    end
                    model.VCityPoseReady = true
                    PlaceGhost(model)
                    PoseStatus("Голубое тело — примерная поза (" .. candidate.name .. "). Проверяйте реальное тело после применения.", false)
                end)
            end
            tryNext()
        end)
    end

	local function UpdateGhost(veh, mode, name, offPos, offAng, pose, seatKey, origin)
		local pos, ang = GhostTransform(veh, mode, name, offPos, offAng, seatKey, origin)
		if not pos then
			RemoveGhost()
            PoseStatus(mode == "none" and "Кресло для предпросмотра не найдено." or "Выберите существующую точку / кость на этой машине.", true)
			return
		end

		if not IsValid(ghost) then
			ghost = ClientsideModel(LocalPlayer():GetModel() or "models/player/group01/male_01.mdl", RENDERGROUP_TRANSLUCENT)
			if not IsValid(ghost) then
                PoseStatus("Не удалось создать модель предпросмотра.", true)
                return
            end
			ghost:SetNoDraw(true)
		end
        ghost.VCityTargetPos, ghost.VCityTargetAng = pos, ang
        local preferDriver = false -- preview the ordinary seated pose, not steering hands
        if ghost.VCityRequestedPose ~= pose or ghost.VCityRequestedDriver ~= preferDriver then
            ghost.VCityRequestedPose, ghost.VCityRequestedDriver = pose, preferDriver
            BeginGhostPose(ghost, pose, preferDriver)
        end
        PlaceGhost(ghost)
	end

	hook.Add("PostDrawOpaqueRenderables", "VCityLVS.SeatGhost", function()
		if IsValid(ghost) and ghost.VCityPoseReady and ghost.VCityGhostPos then
			ghost:SetRenderOrigin(ghost.VCityGhostPos)
			ghost:SetRenderAngles(ghost.VCityGhostAng)
            render.SetColorModulation(0.45, 0.85, 1)
			render.SetBlend(0.5)
			ghost:DrawModel()
			render.SetBlend(1)
            render.SetColorModulation(1, 1, 1)
		end
	end)

	-- ---------- само меню ----------
	function VCityLVS.OpenSeatMenu(veh, data)
		if IsValid(VCityLVS.SeatMenu) then
			VCityLVS.SeatMenu:Remove()
		end

		local order = data.order or {}
		local seats = data.seats or {}

		local frame = vgui.Create("DFrame")
		VCityLVS.SeatMenu = frame
        frame.VCityVehicle = veh
		frame:SetSize(520, math.min(ScrH() - 30, 740))
		frame:Center()
		frame:MakePopup()
		frame:SetTitle("")
		frame:SetDraggable(true)
		frame.Paint = function(pnl, w, h)
			surface.SetDrawColor(BG)
			surface.DrawRect(0, 0, w, h)
			surface.SetDrawColor(ACCENT)
			surface.DrawOutlinedRect(0, 0, w, h, 2)
			draw.SimpleText("Седалище — крепление тела", "VCitySeatTitle", w / 2, 16, ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			draw.SimpleText(data.class or "", "VCitySeatText", w / 2, 38, TEXT_DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		frame.btnClose.Paint = function(pnl, w, h)
			PaintButton(pnl, w, h, "X", nil, Color(80, 30, 24))
		end
		frame.btnMaxim:SetVisible(false)
		frame.btnMinim:SetVisible(false)
		frame.lblTitle:SetVisible(false)
		frame.OnRemove = function()
			RemoveGhost()
            VCityLVS.SeatPoseStatus = nil
            hook.Remove("PostDrawTranslucentRenderables", "VCityLVS.WheelTargetPreview")
		end

        local content = vgui.Create("DScrollPanel", frame)
        content:SetPos(0, 50)
        content:SetSize(518, math.max(100, frame:GetTall() - 58))
		local y = 8

		-- Кресло
		local seatLabel = vgui.Create("DLabel", content)
		seatLabel:SetPos(16, y)
		seatLabel:SetSize(120, 20)
		seatLabel:SetText("Кресло:")
		seatLabel:SetFont("VCitySeatText")
		seatLabel:SetTextColor(TEXT)

		local seatCombo = vgui.Create("DComboBox", content)
		seatCombo:SetPos(140, y)
		seatCombo:SetSize(360, 22)
		seatCombo:SetSortItems(false)
		for _, key in ipairs(order) do
			local info = seats[key] or {}
			seatCombo:AddChoice(key .. (info.gun and "  [оружие]" or "") .. "  (pod " .. (info.index or "?") .. ")", key)
		end
		if #order > 0 then
			seatCombo:SetValue(seatCombo:GetOptionText(1))
		end

		y = y + 34

        local modeLabel = vgui.Create("DLabel", content)
        modeLabel:SetPos(16, y) modeLabel:SetSize(120, 20)
        modeLabel:SetText("Опора тела:") modeLabel:SetFont("VCitySeatText") modeLabel:SetTextColor(TEXT)
        local modeCombo = vgui.Create("DComboBox", content)
        modeCombo:SetPos(140, y) modeCombo:SetSize(360, 22) modeCombo:SetSortItems(false)
        modeCombo:AddChoice("Корпус машины", "none")
        modeCombo:AddChoice("Аттачмент модели", "attach")
        modeCombo:AddChoice("Кость модели", "bone")
        modeCombo:SetTooltip("Тело закрепляется к выбранной опоре. Голова и руки остаются свободными.")
        y = y + 30
        local nameLabel = vgui.Create("DLabel", content)
        nameLabel:SetPos(16, y) nameLabel:SetSize(120, 20)
        nameLabel:SetText("Точка / кость:") nameLabel:SetFont("VCitySeatText") nameLabel:SetTextColor(TEXT)
        local nameCombo = vgui.Create("DComboBox", content)
        nameCombo:SetPos(140, y) nameCombo:SetSize(360, 22) nameCombo:SetSortItems(true)
        nameCombo:SetTooltip("Список точек и костей именно этой модели машины. Для корпуса выбор не нужен.")
        y = y + 30
        local lockLabel = vgui.Create("DLabel", content)
        lockLabel:SetPos(16, y) lockLabel:SetSize(488, 24)
        lockLabel:SetFont("VCitySeatText") lockLabel:SetTextColor(TEXT)
        lockLabel:SetText("Туловище и ноги закрепляются к выбранной опоре")
        lockLabel:SetTooltip("Настройте положение и нажмите «Сохранить и закрепить». Руки и голова не привариваются.")
        y = y + 34

        local poseLabel = vgui.Create("DLabel", content)
        poseLabel:SetPos(16, y)
        poseLabel:SetSize(120, 20)
        poseLabel:SetText("Поза тела:")
        poseLabel:SetFont("VCitySeatText")
        poseLabel:SetTextColor(TEXT)
        local poseCombo = vgui.Create("DComboBox", content)
        poseCombo:SetPos(140, y)
        poseCombo:SetSize(360, 22)
        poseCombo:SetSortItems(false)
        poseCombo:AddChoice("Без изменений", "default")
        poseCombo:AddChoice("Сидит", "sit")
        poseCombo:AddChoice("Лежит", "lie")
        poseCombo:SetTooltip("Физическая поза. Для некоторых моделей нужна поддержка анимации; проверяйте в игре.")

        y = y + 34

		-- Смещение и поворот: ползунки (значение можно и вписать вручную)
		local posWangs = {}
		local angWangs = {}

		local function MakeSlider(text, min, max, decimals, yy)
			local sl = vgui.Create("DNumSlider", content)
			sl:SetPos(16, yy)
			sl:SetSize(488, 22)
			sl:SetText(text)
			sl:SetMin(min)
			sl:SetMax(max)
			sl:SetDecimals(decimals)
			sl:SetDefaultValue(0)
			sl:SetValue(0)
			sl.Label:SetFont("VCitySeatText")
			sl.Label:SetTextColor(TEXT)
			sl.Label:SetWide(110)
			return sl
		end

		local axes = { "Вперёд / назад (X)", "Влево / вправо (Y)", "Вверх / вниз (Z)" }
		for i = 1, 3 do
			posWangs[i] = MakeSlider(axes[i], -150, 150, 1, y)
			y = y + 24
		end

		local rots = { "Наклон (pitch)", "Поворот (yaw)", "Крен (roll)" }
		for i = 1, 3 do
			angWangs[i] = MakeSlider(rots[i], -180, 180, 1, y)
			y = y + 24
		end

		local liveCheck = vgui.Create("DCheckBoxLabel", content)
		liveCheck:SetPos(16, y + 4)
		liveCheck:SetText("Двигать тело на лету (без записи в файл — запись кнопкой «Сохранить»)")
		liveCheck:SetFont("VCitySeatText")
		liveCheck:SetTextColor(TEXT)
		liveCheck:SizeToContents()

		y = y + 30

        local doorControls = vgui.Create("DButton", content)
        doorControls:SetPos(16, y)
        doorControls:SetSize(280, 24)
        doorControls:SetText("Клавиша двери / люка изнутри…")
        doorControls:SetTooltip("Выбор и копирование команды bind. Доступно также обычным игрокам: vcity_lvs_controls.")
        doorControls.DoClick = function() RunConsoleCommand("vcity_lvs_controls") end
        y = y + 30

        local headCheck = vgui.Create("DCheckBoxLabel", content)
        headCheck:SetPos(16, y + 2)
        headCheck:SetText("Уменьшать свою голову от первого лица (локально)")
        headCheck:SetFont("VCitySeatText")
        headCheck:SetTextColor(TEXT)
        local headCV = GetConVar("vcity_lvs_small_head")
        headCheck:SetValue((not headCV or headCV:GetBool()) and 1 or 0)
        headCheck:SizeToContents()
        headCheck:SetTooltip("Только локальная модель и её рэгдолл в LVS; при выходе или виде от третьего лица масштаб восстанавливается.")
        headCheck.OnChange = function(_, checked) RunConsoleCommand("vcity_lvs_small_head", checked and "1" or "0") end
        y = y + 30

		local hint = vgui.Create("DLabel", content)
		hint:SetPos(16, y)
		hint:SetSize(488, 32)
		hint:SetFont("VCitySeatText")
		hint:SetTextColor(TEXT_DIM)
		hint:SetWrap(true)
		hint:SetText("Превью приблизительное; поза зависит от анимаций модели. Проверяйте реальную физику в игре.")
        VCityLVS.SeatPoseStatus = hint

		y = y + 44

		-- текущее состояние
		local current = { key = order[1] or "driver", mode = "none", name = "", pose = "default" }

        local MODE_LABEL = {none = "Корпус машины", attach = "Аттачмент модели", bone = "Кость модели"}
        local function RefreshNameCombo()
            nameCombo:Clear()
            local usable = current.mode ~= "none" and IsValid(veh)
            nameCombo:SetEnabled(usable)
            if usable and current.mode == "attach" then
                for _, att in ipairs(veh:GetAttachments() or {}) do
                    if isstring(att.name) and att.name ~= "" then nameCombo:AddChoice(att.name, att.name) end
                end
            elseif usable and current.mode == "bone" then
                for bone = 0, (veh:GetBoneCount() or 0) - 1 do
                    local name = veh:GetBoneName(bone)
                    if isstring(name) and name ~= "" then nameCombo:AddChoice(name, name) end
                end
            end
            nameCombo:SetValue(usable and (current.name ~= "" and current.name or "Выберите из списка") or "Не требуется для корпуса")
        end
		local function ApplyToGhost()
			if not IsValid(veh) then return end
            local info = seats[current.key] or {}
			UpdateGhost(veh, current.mode, current.name, Vector(posWangs[1]:GetValue(), posWangs[2]:GetValue(), posWangs[3]:GetValue()),
				Angle(angWangs[1]:GetValue(), angWangs[2]:GetValue(), angWangs[3]:GetValue()), current.pose, current.key, info.body_origin)
		end
        frame.SyncSeatOrigin = function(_, key, origin)
            seats[key] = seats[key] or {}
            seats[key].body_origin = origin
            if current.key == key then ApplyToGhost() end
        end
        -- Keep preview on moving bones/attachments while the menu is open.
        local nextPreview = 0
        local baseThink = frame.Think
        frame.Think = function(self)
            if isfunction(baseThink) then baseThink(self) end
            if CurTime() >= nextPreview then nextPreview = CurTime() + 0.1; ApplyToGhost() end
        end

		local function LoadSeat(key)
            timer.Remove("VCityLVS.LiveSeat")
            current.loading = true
			local info = seats[key] or {}
			current.key = key
            current.pose = VCityLVS.NormalizeBodyPose(info.pose)
            poseCombo:SetValue(current.pose == "sit" and "Сидит" or current.pose == "lie" and "Лежит" or "Без изменений")

            if info.attach then current.mode, current.name = "attach", info.attach
            elseif info.bone then current.mode, current.name = "bone", info.bone
            else current.mode, current.name = "none", "" end
            modeCombo:SetValue(MODE_LABEL[current.mode])
            RefreshNameCombo()
            lockLabel:SetText(info.body_lock and "Туловище и ноги закреплены — сохранено"
                or (info.attach or info.bone) and "Старое крепление: сохраните, чтобы закрепить туловище и ноги"
                or "Туловище и ноги закрепятся после сохранения")

			local off = info.attach_offset or {}
			local p = off[1] or { 0, 0, 0 }
			local a = off[2] or { 0, 0, 0 }
			for i = 1, 3 do
				posWangs[i]:SetValue(tonumber(p[i]) or 0)
				angWangs[i]:SetValue(tonumber(a[i]) or 0)
			end

            current.loading = false
			ApplyToGhost()
		end

		seatCombo.OnSelect = function(_, _, _, key)
			LoadSeat(key)
		end

		local SendSave
		local function OnSliderChanged()
            if current.loading then return end
			ApplyToGhost()
			if liveCheck:GetChecked() and SendSave then
				timer.Create("VCityLVS.LiveSeat", 0.3, 1, function()
					if IsValid(frame) then SendSave(true, false) end
				end)
			end
		end
        modeCombo.OnSelect = function(_, _, _, value)
            if current.loading then return end
            timer.Remove("VCityLVS.LiveSeat")
            current.mode, current.name = value, ""
            RefreshNameCombo()
            if value == "none" then OnSliderChanged() else ApplyToGhost() end
        end
        nameCombo.OnSelect = function(_, _, text, value)
            if current.loading then return end
            current.name = value or text or ""
            OnSliderChanged()
        end
        poseCombo.OnSelect = function(_, _, _, value)
            current.pose = VCityLVS.NormalizeBodyPose(value)
            OnSliderChanged()
        end
		for _, wang in ipairs(posWangs) do
			wang.OnValueChanged = OnSliderChanged
		end
		for _, wang in ipairs(angWangs) do
			wang.OnValueChanged = OnSliderChanged
		end

		-- кнопки
		SendSave = function(apply, persist, unlock)
            if not IsValid(veh) then
                lockLabel:SetText("Машина больше не существует — ничего не сохранено")
                return
            end
            if not unlock and current.mode ~= "none" then
                if current.name == "" then
                    lockLabel:SetText("Сначала выберите точку или кость из списка — ничего не сохранено")
                    return
                end
                local id
                if current.mode == "attach" then id = veh:LookupAttachment(current.name)
                else id = veh:LookupBone(current.name) end
                local valid = isnumber(id) and (current.mode == "attach" and id > 0 or current.mode == "bone" and id >= 0)
                if not valid then
                    lockLabel:SetText("Точка / кость отсутствует у этой машины — ничего не сохранено")
                    return
                end
            end
			local payload = {
				mode = current.mode,
				name = current.name,
                pose = current.pose,
                body_lock = not unlock,
				attach_offset = {
					{ posWangs[1]:GetValue(), posWangs[2]:GetValue(), posWangs[3]:GetValue() },
					{ angWangs[1]:GetValue(), angWangs[2]:GetValue(), angWangs[3]:GetValue() },
				},
			}
            local info = seats[current.key] or {}
            info.attach = current.mode == "attach" and current.name or nil
            info.bone = current.mode == "bone" and current.name or nil
            if unlock then info.body_origin = nil end
            info.body_lock = payload.body_lock
            info.attach_offset = payload.attach_offset
            info.pose = current.pose
            lockLabel:SetText(info.body_lock and "Крепление: запрос отправлен — проверьте чат"
                or "Сброс запрошен — после сохранения сядьте снова")
            seats[current.key] = info
			local json = util.TableToJSON(payload)

			net.Start("vcity_lvs_seatui_save")
				net.WriteEntity(veh)
				net.WriteString(current.key)
				net.WriteUInt(#json, 32)
				net.WriteData(json, #json)
				net.WriteBool(apply or false)
				net.WriteBool(persist ~= false)
			net.SendToServer()
		end

		local btnY = y

		local saveBtn = vgui.Create("DButton", content)
		saveBtn:SetPos(16, btnY)
		saveBtn:SetSize(150, 32)
		saveBtn:SetText("")
		saveBtn.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "Сохранить") end
		saveBtn.DoClick = function()
			surface.PlaySound("ui/buttonclick.wav")
			SendSave(false)
		end

		local applyBtn = vgui.Create("DButton", content)
		applyBtn:SetPos(178, btnY)
		applyBtn:SetSize(190, 32)
		applyBtn:SetText("")
		applyBtn.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "Сохранить и закрепить") end
		applyBtn.DoClick = function()
			surface.PlaySound("ui/buttonclick.wav")
			SendSave(true)
		end

		local resetBtn = vgui.Create("DButton", content)
		resetBtn:SetPos(380, btnY)
		resetBtn:SetSize(120, 32)
		resetBtn:SetText("")
		resetBtn.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "Сбросить", nil, Color(80, 30, 24)) end
        resetBtn:SetTooltip("Снимает сохранённое закрепление и сбрасывает позу/смещения. Игроку нужно выйти и снова сесть.")
        resetBtn.DoClick = function()
            timer.Remove("VCityLVS.LiveSeat")
            current.mode, current.name, current.pose = "none", "", "default"
            current.loading = true
            poseCombo:SetValue("Без изменений")
            modeCombo:SetValue(MODE_LABEL.none)
            RefreshNameCombo()
            for i = 1, 3 do posWangs[i]:SetValue(0) angWangs[i]:SetValue(0) end
            current.loading = false
            ApplyToGhost()
            SendSave(false, true, true)
        end

        local copyY = btnY + 44
        local copyBtn = vgui.Create("DButton", content)
        copyBtn:SetPos(16, copyY) copyBtn:SetSize(235, 26)
        copyBtn:SetText("Скопировать из этого кресла")
        copyBtn:SetTooltip("Копирует опору, название точки, позу и смещения. Камера, видимость и опорные координаты корпуса не копируются.")
        copyBtn.DoClick = function()
            VCityLVS.SeatClipboard = {
                pose = current.pose, mode = current.mode, name = current.name,
                pos = {posWangs[1]:GetValue(), posWangs[2]:GetValue(), posWangs[3]:GetValue()},
                ang = {angWangs[1]:GetValue(), angWangs[2]:GetValue(), angWangs[3]:GetValue()},
            }
            copyBtn:SetText("Скопировано: " .. tostring(current.key))
        end
        local pasteBtn = vgui.Create("DButton", content)
        pasteBtn:SetPos(261, copyY) pasteBtn:SetSize(239, 26)
        pasteBtn:SetText("Вставить в это кресло")
        pasteBtn:SetTooltip("Вставляет значения в меню без записи. Затем нажмите «Сохранить» или «Сохранить и закрепить». Проверьте результат на другой машине.")
        pasteBtn.DoClick = function()
            local c = VCityLVS.SeatClipboard
            if not istable(c) then pasteBtn:SetText("Сначала скопируйте кресло") return end
            timer.Remove("VCityLVS.LiveSeat")
            current.loading = true
            current.mode, current.name, current.pose = c.mode or "none", c.name or "", c.pose
            modeCombo:SetValue(MODE_LABEL[current.mode] or MODE_LABEL.none)
            RefreshNameCombo()
            poseCombo:SetValue(current.pose == "sit" and "Сидит" or current.pose == "lie" and "Лежит" or "Без изменений")
            for i = 1, 3 do posWangs[i]:SetValue(c.pos[i]) angWangs[i]:SetValue(c.ang[i]) end
            current.loading = false
            ApplyToGhost()
            pasteBtn:SetText("Вставлено — сохраните")
        end

		-- ---------- камера: вся машина / выбранное кресло ----------
		local camY = copyY + 42
		local camLine = vgui.Create("DPanel", content)
		camLine:SetPos(16, camY - 8)
		camLine:SetSize(488, 1)
		camLine.Paint = function(_, w, h) surface.SetDrawColor(BORDER) surface.DrawRect(0, 0, w, h) end

		local CAM_CHOICES = {
			{ "По умолчанию (глобальная настройка)", "default" },
			{ "Камера LVS", "lvs" },
			{ "Камера Z-City", "zcity" },
		}
		local CAM_TEXT = { default = CAM_CHOICES[1][1], lvs = CAM_CHOICES[2][1], zcity = CAM_CHOICES[3][1] }

		local function CamLabel(text, yy)
			local l = vgui.Create("DLabel", content)
			l:SetPos(16, yy)
			l:SetSize(120, 20)
			l:SetText(text)
			l:SetFont("VCitySeatText")
			l:SetTextColor(TEXT)
		end

		local function SendCam(scope, mode)
			net.Start("vcity_lvs_cam_save")
				net.WriteEntity(veh)
				net.WriteString(scope)
				net.WriteString(mode)
			net.SendToServer()
		end

		CamLabel("Камера машины:", camY)
		local vehCam = vgui.Create("DComboBox", content)
		vehCam:SetPos(140, camY)
		vehCam:SetSize(360, 22)
		vehCam:SetSortItems(false)
		for _, c in ipairs(CAM_CHOICES) do vehCam:AddChoice(c[1], c[2]) end
		vehCam:SetValue(CAM_TEXT[data.camera or "default"])
		vehCam.OnSelect = function(_, _, _, mode)
			data.camera = mode ~= "default" and mode or nil
			SendCam("vehicle", mode)
		end

		CamLabel("Камера кресла:", camY + 30)
		local seatCam = vgui.Create("DComboBox", content)
		seatCam:SetPos(140, camY + 30)
		seatCam:SetSize(360, 22)
		seatCam:SetSortItems(false)
		for _, c in ipairs(CAM_CHOICES) do
			seatCam:AddChoice(c[1] == CAM_CHOICES[1][1] and "Как у машины" or c[1], c[2])
		end
		data.cameras = data.cameras or {}
		local function ShowSeatCam()
			local m = data.cameras[current.key]
			seatCam:SetValue(m and CAM_TEXT[m] or "Как у машины")
		end
		seatCam.OnSelect = function(_, _, _, mode)
			data.cameras[current.key] = mode ~= "default" and mode or nil
			SendCam(current.key, mode)
		end

		local camHint = vgui.Create("DLabel", content)
		camHint:SetPos(16, camY + 58)
		camHint:SetSize(488, 32)
		camHint:SetFont("VCitySeatText")
		camHint:SetTextColor(TEXT_DIM)
		camHint:SetWrap(true)
		camHint:SetText("Камера сохраняется сразу. Приоритет: кресло > машина > глобальный конвар vcity_rp_lvs_zcity_camera. Вступает в силу при следующей посадке.")

        -- Own-body visibility, same inheritance and immediate save as camera.
        local bodyY = camY + 100
        local bodyLine = vgui.Create("DPanel", content)
        bodyLine:SetPos(16, bodyY - 8)
        bodyLine:SetSize(488, 1)
        bodyLine.Paint = function(_, w, h) surface.SetDrawColor(BORDER) surface.DrawRect(0, 0, w, h) end
        local BODY_TEXT = {show = "Показывать", hide = "Скрывать"}
        local function SendBody(scope, value)
            net.Start("vcity_lvs_body_visibility_save")
                net.WriteEntity(veh)
                net.WriteString(scope)
                net.WriteString(value)
            net.SendToServer()
        end
        CamLabel("Тело в машине:", bodyY)
        local vehBody = vgui.Create("DComboBox", content)
        vehBody:SetPos(140, bodyY)
        vehBody:SetSize(360, 22)
        vehBody:SetSortItems(false)
        vehBody:AddChoice("По умолчанию (глобальная настройка)", "default")
        vehBody:AddChoice("Показывать", "show")
        vehBody:AddChoice("Скрывать", "hide")
        vehBody:SetValue(BODY_TEXT[data.body_draw] or "По умолчанию (глобальная настройка)")
        vehBody.OnSelect = function(_, _, _, value)
            data.body_draw = value ~= "default" and value or nil
            SendBody("vehicle", value)
        end
        CamLabel("Тело в кресле:", bodyY + 30)
        local seatBody = vgui.Create("DComboBox", content)
        seatBody:SetPos(140, bodyY + 30)
        seatBody:SetSize(360, 22)
        seatBody:SetSortItems(false)
        seatBody:AddChoice("Как у машины", "default")
        seatBody:AddChoice("Показывать", "show")
        seatBody:AddChoice("Скрывать", "hide")
        data.body_draw_seats = data.body_draw_seats or {}
        local function ShowSeatBody()
            seatBody:SetValue(BODY_TEXT[data.body_draw_seats[current.key]] or "Как у машины")
        end
        seatBody.OnSelect = function(_, _, _, value)
            data.body_draw_seats[current.key] = value ~= "default" and value or nil
            SendBody(current.key, value)
        end
        local bodyHint = vgui.Create("DLabel", content)
        bodyHint:SetPos(16, bodyY + 58)
        bodyHint:SetSize(488, 32)
        bodyHint:SetFont("VCitySeatText")
        bodyHint:SetTextColor(TEXT_DIM)
        bodyHint:SetWrap(true)
        bodyHint:SetText("Только своё тело; сохраняется сразу. Приоритет: кресло > машина > vcity_rp_lvs_ragdoll_draw. Других игроков настройка не скрывает.")

        -- Previous wheel-centre controls removed with the steering-hand feature.
        local importY = bodyY + 100
        local importLine = vgui.Create("DPanel", content)
        importLine:SetPos(16, importY - 8)
        importLine:SetSize(488, 1)
        importLine.Paint = function(_, w, h) surface.SetDrawColor(BORDER) surface.DrawRect(0, 0, w, h) end
        CamLabel("Импорт JSON:", importY)
        local importCombo = vgui.Create("DComboBox", content)
        importCombo:SetPos(140, importY)
        importCombo:SetSize(248, 22)
        importCombo:SetSortItems(false)
        importCombo:SetValue("Выберите файл на сервере")
        local chosenImport
        importCombo.OnSelect = function(_, _, _, name) chosenImport = name end
        frame.SetImportFiles = function(_, names)
            importCombo:Clear()
            local stillFound = false
            for _, name in ipairs(names) do
                importCombo:AddChoice(name, name)
                if chosenImport == name then stillFound = true end
            end
            if not stillFound then chosenImport = nil end
            importCombo:SetValue(chosenImport or (#names == 0 and "JSON-файлов не найдено" or "Выберите файл на сервере"))
        end
        local function RequestImports()
            net.Start("vcity_lvs_import_list")
            net.SendToServer()
        end
        local importRefresh = vgui.Create("DButton", content)
        importRefresh:SetPos(394, importY)
        importRefresh:SetSize(106, 22)
        importRefresh:SetText("")
        importRefresh.VCityImportRefresh = true
        importRefresh.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "Обновить") end
        importRefresh.DoClick = RequestImports
        local importButton = vgui.Create("DButton", content)
        importButton:SetPos(16, importY + 30)
        importButton:SetSize(200, 30)
        importButton:SetText("")
        importButton.VCityImportButton = true
        importButton.Paint = function(pnl, w, h) PaintButton(pnl, w, h, "Импортировать") end
        importButton.DoClick = function()
            if not chosenImport or not IsValid(veh) then return end
            local filename = chosenImport
            Derma_Query("Запись для класса " .. tostring(data.class or "") .. " будет заменена настройками из " .. filename
                .. ". Другие классы не изменятся. Затронуты все машины этого класса. Продолжить?", "Импорт настроек LVS",
                "Импортировать", function()
                    if not IsValid(frame) or not IsValid(veh) then return end
                    net.Start("vcity_lvs_import_run")
                        net.WriteEntity(veh)
                        net.WriteString(filename)
                    net.SendToServer()
                end,
                "Отмена", function() end)
        end
        local importHint = vgui.Create("DLabel", content)
        importHint:SetPos(16, importY + 66)
        importHint:SetSize(488, 56)
        importHint:SetFont("VCitySeatText")
        importHint:SetTextColor(TEXT_DIM)
        importHint:SetWrap(true)
        importHint:SetText("Положите JSON моста в data/vcity_rp/lvs_import/ на сервере и обновите список. Импорт заменяет настройки данного класса; перед записью создаётся резервная копия. Кресла и позы — после пересоздания машины.")
        RequestImports()

		local baseSeatChange = seatCombo.OnSelect
		seatCombo.OnSelect = function(a, b, c, key)
			baseSeatChange(a, b, c, key)
			ShowSeatCam()
            ShowSeatBody()
		end

		if #order > 0 then
			LoadSeat(order[1])
			ShowSeatCam()
            ShowSeatBody()
		end
        -- Ensure the scroll canvas extends beyond the final explanatory text.
        local bottom = vgui.Create("DPanel", content)
        bottom:SetPos(0, importY + 126)
        bottom:SetSize(1, 1)
        bottom.Paint = function() end
	end

    net.Receive("vcity_lvs_seatui_origin", function()
        local veh = net.ReadEntity()
        local key = net.ReadString()
        local origin
        if net.ReadBool() then
            local pos, ang = net.ReadVector(), net.ReadAngle()
            origin = VCityLVS.PackPosAng(pos, ang)
        end
        local frame = VCityLVS.SeatMenu
        if IsValid(frame) and frame.VCityVehicle == veh and isfunction(frame.SyncSeatOrigin) then frame:SyncSeatOrigin(key, origin) end
    end)

    net.Receive("vcity_lvs_import_list", function()
        local count = net.ReadUInt(8)
        if count > 128 then return end
        local names = {}
        for i = 1, count do names[i] = net.ReadString() end
        local frame = VCityLVS.SeatMenu
        if IsValid(frame) and isfunction(frame.SetImportFiles) then frame:SetImportFiles(names) end
    end)

	net.Receive("vcity_lvs_seatui_open", function()
		local veh = net.ReadEntity()
		local dataLen = net.ReadUInt(32)
		local json = util.JSONToTable(tostring(net.ReadData(dataLen)))

		if IsValid(veh) and istable(json) then
			VCityLVS.OpenSeatMenu(veh, json)
		end
	end)
end
