-- Local-only head hiding for first-person LVS views. Does not change physics.
if SERVER then AddCSLuaFile() return end
VCityLVS = VCityLVS or {}
local cv = CreateClientConVar("vcity_lvs_small_head", "1", true, false,
    "Уменьшать собственную голову от первого лица в LVS", 0, 1)
local scale = Vector(0.01, 0.01, 0.01)
local saved = {}

local function ownRagdoll(ply)
    local rag = ply.FakeRagdoll
    if not IsValid(rag) then rag = ply:GetNWEntity("FakeRagdoll") end
    if not IsValid(rag) then rag = ply:GetNWEntity("VCityLVS_SandboxRagdoll") end
    return rag
end

local function firstPerson(ply)
    if not cv:GetBool() or not IsValid(ply) or not ply:Alive() or not ply:InVehicle()
        or not isfunction(ply.lvsGetVehicle) or not IsValid(ply:lvsGetVehicle()) then return false end
    local pod = ply:GetVehicle()
    if not IsValid(pod) or (isfunction(pod.GetThirdPersonMode) and pod:GetThirdPersonMode()) then return false end
    local third = GetConVar("hg_thirdperson")
    local gopro = GetConVar("hg_gopro")
    if (third and third:GetBool()) or (gopro and gopro:GetBool()) then return false end
    local view = GetViewEntity()
    if IsValid(view) and view ~= ply and view ~= ownRagdoll(ply) then return false end
    return true
end

local function restore(ent, data)
    if IsValid(ent) and data and data.bone ~= nil then ent:ManipulateBoneScale(data.bone, data.scale) end
end
local function shrink(ent)
    if not IsValid(ent) then return end
    local bone = ent:LookupBone("ValveBiped.Bip01_Head1")
    if bone == nil or bone < 0 then return end
    local data = saved[ent]
    if data and data.bone ~= bone then restore(ent, data) saved[ent] = nil data = nil end
    if not data then
        local old = ent:GetManipulateBoneScale(bone)
        if not old then return end
        data = {bone = bone, scale = Vector(old.x, old.y, old.z)}
        saved[ent] = data
    end
    local current = ent:GetManipulateBoneScale(bone)
    if not current or not current:IsEqualTol(scale, 0.001) then ent:ManipulateBoneScale(bone, scale) end
end

hook.Add("Think", "VCityLVS.FirstPersonHead", function()
    local ply = LocalPlayer()
    local active = firstPerson(ply)
    local rag = active and ownRagdoll(ply) or nil
    for ent, data in pairs(saved) do
        if not active or (ent ~= ply and ent ~= rag) then restore(ent, data) saved[ent] = nil end
    end
    if active then shrink(ply) shrink(rag) end
end)

-- Z-City resets the head matrix later in its draw routine. Apply once more
-- after that routine, only to this client's own current first-person body.
local wrapped
local function installDrawWrapper()
    if wrapped or not isfunction(DrawPlayerRagdoll) then return wrapped end
    local previous = DrawPlayerRagdoll
    DrawPlayerRagdoll = function(ent, ply, ...)
        local result = previous(ent, ply, ...)
        if IsValid(ent) and ply == LocalPlayer() and firstPerson(ply) and (ent == ply or ent == ownRagdoll(ply)) then
            local bone = ent:LookupBone("ValveBiped.Bip01_Head1")
            local mat = bone and ent:GetBoneMatrix(bone)
            if mat then
                mat:SetScale(scale)
                if istable(hg) and isfunction(hg.bone_apply_matrix) then hg.bone_apply_matrix(ent, bone, mat)
                else ent:SetBoneMatrix(bone, mat) end
            end
        end
        return result
    end
    wrapped = true
    return true
end
if not installDrawWrapper() then
    hook.Add("InitPostEntity", "VCityLVS.InstallFirstPersonHead", installDrawWrapper)
    timer.Create("VCityLVS.InstallFirstPersonHeadRetry", 1, 30, function()
        if installDrawWrapper() then timer.Remove("VCityLVS.InstallFirstPersonHeadRetry") end
    end)
end
