-- Presets for the actual physics ragdoll. No Z-City or LVS base files are changed.
if SERVER then AddCSLuaFile() end
VCityLVS = VCityLVS or {}

-- Zero offsets keep the original unmodified seat behaviour.
function VCityLVS.HasBodyOffset(offset)
    if not istable(offset) then return false end
    for part = 1, 2 do
        if istable(offset[part]) then
            for i = 1, 3 do
                local n = tonumber(offset[part][i])
                if n and n == n and math.abs(n) > 0.00001 then return true end
            end
        end
    end
    return false
end

-- A stable, server-side origin in vehicle-local coordinates (never client supplied).
function VCityLVS.ValidBodyOrigin(origin)
    if not istable(origin) or not istable(origin.pos) or not istable(origin.ang) then return false end
    for _, spec in ipairs({{origin.pos, 8192}, {origin.ang, 36000}}) do
        for i = 1, 3 do
            local n = tonumber(spec[1][i])
            if not n or n ~= n or math.abs(n) > spec[2] then return false end
        end
    end
    return true
end

function VCityLVS.NormalizeBodyPose(value)
    if value == "sit" or value == "lie" then return value end
    return "default"
end

-- A sequence named "sit" is not necessarily a sitting animation on every
-- custom model. Keep alternatives and verify the resulting bone geometry.
function VCityLVS.PoseSequenceCandidates(model, pose, preferDriver)
    pose = VCityLVS.NormalizeBodyPose(pose)
    local names
    if pose == "sit" then
        names = {"sit", "sit_passive", "sit_rollercoaster", "ACT_HL2MP_SIT", "ACT_GMOD_SIT"}
    elseif pose == "lie" then
        names = {"lying", "lying_idle", "prone_idle", "death_01", "ragdoll", "idle_all_01", "idle"}
    else
        return {}
    end
    local out, seen = {}, {}
    for _, name in ipairs(names) do
        local id = model:LookupSequence(name)
        if isnumber(id) and id >= 0 and not seen[id] then
            seen[id] = true
            local rotate = pose == "lie" and (name == "ragdoll" or name == "idle_all_01" or name == "idle")
            -- Some "sit" sequences transition from standing before reaching
            -- the seated frame. Test more than just their first frame.
            local cycles = pose == "sit" and {0, 0.5, 0.99} or {name == "death_01" and 0.99 or 0}
            for _, cycle in ipairs(cycles) do
                out[#out + 1] = {id = id, rotate = rotate, cycle = cycle, name = name}
            end
        end
    end
    return out
end

function VCityLVS.SelectPoseSequence(model, pose)
    local c = VCityLVS.PoseSequenceCandidates(model, pose)[1]
    if c then return c.id, c.rotate, c.cycle end
    return nil, false
end

local function finiteVector(v)
    return v and v.x == v.x and v.y == v.y and v.z == v.z
        and math.abs(v.x) < 1000000 and math.abs(v.y) < 1000000 and math.abs(v.z) < 1000000
end

local function finiteAngle(a)
    return a and a.p == a.p and a.y == a.y and a.r == a.r
        and math.abs(a.p) < 1000000 and math.abs(a.y) < 1000000 and math.abs(a.r) < 1000000
end

-- Test geometry, not just the name of the animation: in a seated pose both
-- upper legs should be angled away from the pelvis-to-torso direction.
-- Return nil when the skeleton/matrices cannot be measured, not a fake success.
function VCityLVS.IsSittingPose(model)
    local function position(name)
        local id = model:LookupBone(name)
        local mat = id and model:GetBoneMatrix(id) or nil
        local pos = mat and mat:GetTranslation() or nil
        if finiteVector(pos) then return pos end
    end
    local pelvis = position("ValveBiped.Bip01_Pelvis")
    local upper = position("ValveBiped.Bip01_Spine4") or position("ValveBiped.Bip01_Spine2") or position("ValveBiped.Bip01_Head1")
    if not pelvis or not upper then return nil, "нет матриц таза или спины" end
    local torso = upper - pelvis
    if torso:LengthSqr() < 9 then return nil, "некорректные матрицы спины" end
    torso:Normalize()
    for _, side in ipairs({"L", "R"}) do
        local thigh = position("ValveBiped.Bip01_" .. side .. "_Thigh")
        local calf = position("ValveBiped.Bip01_" .. side .. "_Calf")
        if not thigh or not calf then return nil, "нет матриц ног" end
        local femur = calf - thigh
        if femur:LengthSqr() < 9 then return nil, "некорректные матрицы ног" end
        femur:Normalize()
        if math.abs(femur:Dot(torso)) > 0.72 then return false, "анимация выглядит стоячей" end
    end
    return true
end

if not SERVER then return end

-- Take a snapshot from a temporary animated model, expressed relative to its
-- pelvis. Nothing is changed on the ragdoll until the snapshot is validated.
function VCityLVS.SampleBodyPose(ragdoll, pose, callback, preferDriver)
    pose = VCityLVS.NormalizeBodyPose(pose)
    if pose == "default" or not IsValid(ragdoll) then callback(nil, "нет рэгдолла или позы") return end
    local mdl = ragdoll:GetModel()
    if not isstring(mdl) or mdl == "" then callback(nil, "нет модели игрока") return end
    local proxy = ents.Create("prop_dynamic")
    if not IsValid(proxy) then callback(nil, "не удалось создать модель позы") return end
    proxy:SetModel(mdl)
    proxy:SetPos(ragdoll:GetPos())
    proxy:SetAngles(Angle(0, 0, 0))
    -- Keep server-side bone evaluation active; make the short-lived sample
    -- invisible through alpha instead of EF_NODRAW.
    proxy:SetRenderMode(RENDERMODE_TRANSALPHA)
    proxy:SetColor(Color(255, 255, 255, 0))
    proxy:DrawShadow(false)
    proxy:Spawn()
    proxy:SetSolid(SOLID_NONE)
    proxy:SetMoveType(MOVETYPE_NONE)
    local done = false
    local function finish(sample, err)
        if done then return end
        done = true
        if IsValid(proxy) then proxy:Remove() end
        callback(sample, err)
    end
    -- ResetSequence cannot be called immediately after SetModel. In addition,
    -- SetupBones/InvalidateBoneCache are client-only APIs, so wait for the
    -- server animation tick and read the server's GetBoneMatrix instead.
    timer.Simple(0, function()
        if not IsValid(proxy) or not IsValid(ragdoll) then finish(nil, "модель удалена") return end
        local ok, candidates = pcall(VCityLVS.PoseSequenceCandidates, proxy, pose, preferDriver)
        if not ok or #candidates == 0 then finish(nil, "в модели нет подходящей анимации") return end
        local index, lastError = 0, nil
        local function tryNext()
            index = index + 1
            local candidate = candidates[index]
            if not candidate then
                finish(nil, lastError or "сидячая анимация не найдена")
                return
            end
            if not IsValid(proxy) or not IsValid(ragdoll) then finish(nil, "модель удалена") return end
            proxy:ResetSequence(candidate.id)
            proxy:SetCycle(candidate.cycle)
            proxy:SetPlaybackRate(0)
            timer.Simple(engine.TickInterval(), function()
                if not IsValid(proxy) or not IsValid(ragdoll) then finish(nil, "модель удалена") return end
                if pose == "sit" then
                    local measured, seated, reason = pcall(VCityLVS.IsSittingPose, proxy)
                    if not measured or seated ~= true then
                        lastError = measured and reason or "ошибка чтения костей"
                        tryNext()
                        return
                    end
                end
            local success, result, err = pcall(function()
                local pelvis = proxy:LookupBone("ValveBiped.Bip01_Pelvis")
                local pelvisMat = pelvis and proxy:GetBoneMatrix(pelvis)
                if not pelvisMat or not finiteVector(pelvisMat:GetTranslation()) then
                    return nil, "матрица таза недоступна на сервере"
                end
                local ppos, pang = pelvisMat:GetTranslation(), pelvisMat:GetAngles()
                if not finiteAngle(pang) then return nil, "некорректный угол таза" end
                if ppos:DistToSqr(proxy:GetPos()) > 128 * 128 then
                    return nil, "некорректная матрица таза"
                end
                -- A physics object's frame may be offset from its render bone.
                -- When the current ragdoll matrix is trustworthy, preserve that
                -- offset instead of treating the render bone as a PhysObj.
                local function physicsTransform(mat, ragBone, physNum)
                    local pos, ang = mat:GetTranslation(), mat:GetAngles()
                    local ph = ragdoll:GetPhysicsObjectNum(physNum)
                    local rm = ragdoll.GetBoneMatrix and ragdoll:GetBoneMatrix(ragBone) or nil
                    if IsValid(ph) and rm and finiteVector(rm:GetTranslation()) and finiteAngle(rm:GetAngles())
                        and rm:GetTranslation():DistToSqr(ph:GetPos()) < 64 * 64 then
                        local offPos, offAng = WorldToLocal(ph:GetPos(), ph:GetAngles(), rm:GetTranslation(), rm:GetAngles())
                        if finiteVector(offPos) and finiteAngle(offAng) then
                            pos, ang = LocalToWorld(offPos, offAng, pos, ang)
                        end
                    end
                    return pos, ang
                end
                local ragPelvis = ragdoll:LookupBone("ValveBiped.Bip01_Pelvis")
                local ragPelvisPhys = ragPelvis and ragdoll:TranslateBoneToPhysBone(ragPelvis) or -1
                if ragPelvisPhys < 0 then return nil, "нет физической кости таза" end
                ppos, pang = physicsTransform(pelvisMat, ragPelvis, ragPelvisPhys)
                if not finiteVector(ppos) or not finiteAngle(pang) then return nil, "некорректная физика таза" end
                local bones, count, maxDist = {}, 0, 0
                for physNum = 0, ragdoll:GetPhysicsObjectCount() - 1 do
                    local boneID = ragdoll:TranslatePhysBoneToBone(physNum)
                    local name = boneID and boneID >= 0 and ragdoll:GetBoneName(boneID) or nil
                    local srcBone = name and proxy:LookupBone(name) or nil
                    local mat = srcBone and proxy:GetBoneMatrix(srcBone) or nil
                    if mat and finiteVector(mat:GetTranslation()) and finiteAngle(mat:GetAngles()) then
                        local worldPos, worldAng = physicsTransform(mat, boneID, physNum)
                        local pos, ang = WorldToLocal(worldPos, worldAng, ppos, pang)
                        if finiteVector(pos) and finiteAngle(ang) and pos:LengthSqr() <= 128 * 128 then
                            bones[physNum] = {pos, ang}
                            maxDist = math.max(maxDist, pos:LengthSqr())
                            count = count + 1
                        end
                    end
                end
                if count < 5 or maxDist < 4 or not bones[ragPelvisPhys] then
                    return nil, "недостаточно костей модели для позы"
                end
                return {bones = bones, rotate = candidate.rotate, sequence = candidate.name}
            end)
            if not success or not result then
                lastError = success and err or "ошибка чтения костей модели"
                tryNext()
                return
            end
            finish(result, nil)
            end)
        end
        tryNext()
    end)
end
