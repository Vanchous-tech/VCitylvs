-- Make the bridge's shared/client autorun scripts available when installed
-- server-side as loose addon files, not only through Workshop.
if not SERVER then return end
for _, name in ipairs({
    "vcity_lvs_camera.lua", "vcity_lvs_seats.lua", "vcity_lvs_seat_menu.lua",
    "vcity_lvs_zcity_bridge.lua", "vcity_lvs_bodyposes.lua", "vcity_lvs_bodyvisibility.lua", "vcity_lvs_steering.lua", "vcity_lvs_sandbox.lua", "vcity_lvs_sandbox_steering.lua", "vcity_lvs_steering_config.lua", "vcity_lvs_head.lua", "vcity_lvs_doors.lua", "vcity_lvs_physicalhands.lua",
}) do
    AddCSLuaFile("autorun/" .. name)
end
