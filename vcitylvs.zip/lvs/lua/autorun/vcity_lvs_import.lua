-- Import one vehicle type from an existing bridge JSON in the server's DATA.
-- No client file upload and no changes to unrelated vehicle classes.
if not SERVER then return end
VCityLVS = VCityLVS or {}
local DIR = "vcity_rp/lvs_import"
local MAX_BYTES, MAX_FILES = 2 * 1024 * 1024, 128
util.AddNetworkString("vcity_lvs_import_list")
util.AddNetworkString("vcity_lvs_import_run")

local function safeName(name)
    return isstring(name) and #name > 5 and #name <= 120
        and not string.find(name, "..", 1, true)
        and string.match(name, "^[%w_%.%-]+%.json$") ~= nil
end

function VCityLVS.ListImportFiles()
    file.CreateDir("vcity_rp")
    file.CreateDir(DIR)
    local found = file.Find(DIR .. "/*.json", "DATA") or {}
    local files = {}
    for _, name in ipairs(found) do
        if safeName(name) then files[#files + 1] = name end
    end
    table.sort(files)
    while #files > MAX_FILES do table.remove(files) end
    return files
end

local function triple(v, limit)
    if not istable(v) then return false end
    for i = 1, 3 do
        local n = tonumber(v[i])
        if not n or n ~= n or math.abs(n) > limit then return false end
    end
    return true
end
local function seatKey(k)
    return isstring(k) and #k <= 16 and VCityLVS.SeatKey(k) == k
end
local function seatMap(map, isCamera)
    if not istable(map) then return false end
    local count = 0
    for k, v in pairs(map) do
        count = count + 1
        if count > 256 or not seatKey(k) then return false end
        if isCamera then
            if v ~= "lvs" and v ~= "zcity" and v ~= "default" and v ~= "" then return false end
        elseif v ~= "show" and v ~= "hide" and v ~= "default" and v ~= "" then return false end
    end
    return true
end
local function validSeat(s)
    if not istable(s) then return false end
    if s.pos ~= nil and not triple(s.pos, 8192) then return false end
    if s.ang ~= nil and not triple(s.ang, 36000) then return false end
    for _, key in ipairs({"attach", "bone"}) do
        local n = s[key]
        if n ~= nil and (not isstring(n) or #n < 1 or #n > 128 or string.find(n, "%c")) then return false end
    end
    if s.attach and s.bone then return false end
    if s.body_lock ~= nil and type(s.body_lock) ~= "boolean" then return false end
    if s.body_origin ~= nil and (not istable(s.body_origin)
        or not triple(s.body_origin.pos, 8192) or not triple(s.body_origin.ang, 36000)) then return false end
    if s.pose ~= nil and s.pose ~= "default" and s.pose ~= "sit" and s.pose ~= "lie" then return false end
    if s.attach_offset ~= nil then
        if not istable(s.attach_offset) or not triple(s.attach_offset[1], 8192) or not triple(s.attach_offset[2], 36000) then return false end
    end
    return true
end

function VCityLVS.ValidateImportEntry(entry)
    if not istable(entry) then return false, "запись машины не является таблицей" end
    if entry.camera ~= nil and entry.camera ~= "lvs" and entry.camera ~= "zcity" and entry.camera ~= "default" and entry.camera ~= "" then return false, "неверный режим камеры" end
    if entry.cameras ~= nil and not seatMap(entry.cameras, true) then return false, "неверные камеры кресел" end
    if entry.body_draw ~= nil and entry.body_draw ~= "show" and entry.body_draw ~= "hide" and entry.body_draw ~= "default" and entry.body_draw ~= "" then return false, "неверная видимость тела" end
    if entry.body_draw_seats ~= nil and not seatMap(entry.body_draw_seats, false) then return false, "неверная видимость тела в креслах" end
    if entry.steering_target ~= nil then
        if not istable(entry.steering_target) then return false, "неверная точка руля" end
        if entry.steering_target.mode ~= "auto" and (not VCityLVS.ValidateSteeringTarget or not VCityLVS.ValidateSteeringTarget(entry.steering_target)) then
            return false, "неверная точка руля"
        end
    end
    local count = 0
    for key, seat in pairs(entry) do
        if seatKey(key) then
            count = count + 1
            if count > 256 or not validSeat(seat) then return false, "неверные данные кресла " .. key end
        end
    end
    return true
end

local function backupPath()
    local base = "vcity_rp/lvs_seats_before_import_" .. tostring(os.time())
    for i = 0, 999 do
        local path = base .. (i > 0 and ("_" .. i) or "") .. ".json"
        if not file.Exists(path, "DATA") then return path end
    end
end

function VCityLVS.ImportVehicleFile(veh, name)
    if not IsValid(veh) or not isfunction(veh.GetDriverSeat) or not VCityLVS.IsLVSRelated(veh) then return false, "Выберите машину LVS." end
    if not safeName(name) then return false, "Некорректное имя файла." end
    local path = DIR .. "/" .. name
    local size = file.Size(path, "DATA")
    if not size or size < 1 or size > MAX_BYTES then return false, "Файл не найден, пуст или больше 2 МБ." end
    local raw = file.Read(path, "DATA")
    if not isstring(raw) or #raw < 1 or #raw > MAX_BYTES then return false, "Не удалось прочитать файл." end
    local parsed = util.JSONToTable(raw)
    if not istable(parsed) or not istable(parsed.vehicles) then return false, "Это не JSON конфига моста (нет vehicles)." end
    if parsed.version ~= nil and parsed.version ~= 1 then return false, "Версия конфига не поддерживается." end
    local class, model = veh:GetClass(), veh:GetModel()
    if not isstring(class) or class == "" then return false, "У машины нет класса." end
    -- Prefer exactly the same class; fall back to this vehicle's model key.
    local imported = parsed.vehicles[class]
    if not istable(imported) and isstring(model) then imported = parsed.vehicles[model] end
    if not istable(imported) then return false, "Для класса или модели машины в файле нет записи." end
    local valid, reason = VCityLVS.ValidateImportEntry(imported)
    if not valid then return false, "Импорт отменён: " .. reason .. "." end
    if not istable(VCityLVS.SeatConfig) or not istable(VCityLVS.SeatConfig.vehicles) or not isstring(VCityLVS.SeatFile) then return false, "Текущий конфиг недоступен." end

    if VCityLVS.CanWriteSeatConfig then
        local ok, reason = VCityLVS.CanWriteSeatConfig()
        if not ok then return false, reason end
    end

    -- Only replace a class-keyed record. Never overwrite a model-keyed record
    -- that may be shared by different classes. Keep all other config entries.
    local nextConfig = table.Copy(VCityLVS.SeatConfig)
    nextConfig.vehicles[class] = table.Copy(imported)
    local before = util.TableToJSON(VCityLVS.SeatConfig, true)
    local after = util.TableToJSON(nextConfig, true)
    if not isstring(before) or not isstring(after) then return false, "Не удалось подготовить конфиг." end
    file.CreateDir("vcity_rp")
    local backup = backupPath()
    if not backup or not file.Write(backup, before) or file.Read(backup, "DATA") ~= before then
        return false, "Не удалось создать резервную копию; импорт отменён."
    end
    local oldDisk = file.Read(VCityLVS.SeatFile, "DATA")
    if not file.Write(VCityLVS.SeatFile, after) or file.Read(VCityLVS.SeatFile, "DATA") ~= after then
        if oldDisk then file.Write(VCityLVS.SeatFile, oldDisk) else file.Delete(VCityLVS.SeatFile) end
        if file.Read(VCityLVS.SeatFile, "DATA") ~= oldDisk then VCityLVS.SeatConfigLocked = true end
        return false, "Не удалось записать конфиг. Резервная копия: data/" .. backup
    end
    VCityLVS.SeatConfig = nextConfig
    VCityLVS.SeatDiskSnapshot = after
    if VCityLVS.PublishAllCameras then VCityLVS.PublishAllCameras() end
    if VCityLVS.PublishAllBodyVisibility then VCityLVS.PublishAllBodyVisibility() end
    return true, "Настройки класса " .. class .. " импортированы. Для кресел и поз пересоздайте машину. Копия: data/" .. backup
end

net.Receive("vcity_lvs_import_list", function(_, ply)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end
    local files = VCityLVS.ListImportFiles()
    net.Start("vcity_lvs_import_list")
        net.WriteUInt(#files, 8)
        for _, name in ipairs(files) do net.WriteString(name) end
    net.Send(ply)
end)

net.Receive("vcity_lvs_import_run", function(_, ply)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end
    local veh, name = net.ReadEntity(), net.ReadString()
    local ok, msg = VCityLVS.ImportVehicleFile(veh, name)
    ply:ChatPrint("[V-City LVS] " .. msg)
    if ok and VCityLVS.SendSeatMenu then VCityLVS.SendSeatMenu(ply, veh) end
end)
