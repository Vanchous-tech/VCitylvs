--[[---------------------------------------------------------
	V-City LVS: якорь тела экипажа.

	Прямой порт sv_gunner_anchor.lua с БРДМ-2 «dobruja digger»
	(структура сохранена функция в функцию), обобщение одно:
	класс машины, точка крепления и смещение берутся из
	конфига кресел (data/vcity_rp/lvs_seats.json, меню
	vcity_rp_sidalishe), а не захардкожены.

	Как это работает (как в БРДМ):
	* Z-City при посадке делает рэгдолл и приваривает таз/ноги
	  к корпусу. Мы снимаем сварки (колбэк "removeOwO" отключается
	  первым — иначе он выкинет игрока из машины) и создаём
	  невидимый якорь, который каждый тик переезжает за точкой
	  крепления (attachment или кость).
    * При едином креплении туловище и ноги привариваются к якорю;
      руки и голова остаются свободными.
	* Якорь едет с упреждением по скорости (компенсация
	  отставания тика на скорости).

	Смещение (attach_offset) — в осях ТОЧКИ КРЕПЛЕНИЯ:
	X — вперёд, Y — влево, Z — вверх; углы — pitch/yaw/roll.

	Отладка: vcity_rp_lvs_anchor_debug 1, vcity_rp_lvs_anchor_mode 1.
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}

if not SERVER then return end

local cvDebug = CreateConVar("vcity_rp_lvs_anchor_debug", "0", FCVAR_ARCHIVE, "V-City LVS anchor debug")
local cvMode = CreateConVar("vcity_rp_lvs_anchor_mode", "0", FCVAR_ARCHIVE, "0 = shadow (UpdateShadow), 1 = frozen + SetPos")
local cvLead = CreateConVar("vcity_rp_lvs_anchor_lead", "1", FCVAR_ARCHIVE, "Упреждение якоря на N тиков вперёд (компенсация отставания на скорости)")

local PINNED_BONES = {
	["ValveBiped.Bip01_Pelvis"] = true,
	["ValveBiped.Bip01_L_Thigh"] = true,
	["ValveBiped.Bip01_R_Thigh"] = true,
	["ValveBiped.Bip01_L_Calf"] = true,
	["ValveBiped.Bip01_R_Calf"] = true,
}

-- Hull lock fixes the torso and legs; head and arms remain unwelded.
local HULL_BONES = {
    ["ValveBiped.Bip01_Spine"] = true, ["ValveBiped.Bip01_Spine1"] = true,
    ["ValveBiped.Bip01_Spine2"] = true, ["ValveBiped.Bip01_Spine3"] = true,
    ["ValveBiped.Bip01_Spine4"] = true,
    ["ValveBiped.Bip01_L_Foot"] = true, ["ValveBiped.Bip01_R_Foot"] = true,
}

local ActiveAnchors = {} -- [anchor] = veh

local function dbg(...)
	if cvDebug:GetBool() then print("[V-City LVS]", ...) end
end

---------------------------------------------------------------------------
-- Контекст сиденья: pod -> машина -> ключ кресла -> конфиг крепления
---------------------------------------------------------------------------
-- Обобщение GetBRDMSeatContext: вместо захардкоженного класса/роли —
-- любая LVS-машина и ключ кресла из конфига.
local function GetSeatContext(ply)
	if not IsValid(ply) or not ply:IsPlayer() or not ply:InVehicle() then return end

	local pod = ply:GetVehicle()
	if not IsValid(pod) then return end

	local base = ply.lvsGetVehicle and ply:lvsGetVehicle() or nil
	if not IsValid(base) then
		base = pod:GetParent()
		if not IsValid(base) or not base.GetDriverSeat then return end
	end

	local key = VCityLVS.SeatKeyByIndex(pod:lvsGetPodIndex() or 1)
	if not key then return end

	local entry = VCityLVS.FindVehicleEntry(base)
	local extra = entry and entry[key] or nil
	if not istable(extra) then return end
    local pose = VCityLVS.NormalizeBodyPose and VCityLVS.NormalizeBodyPose(extra.pose) or "default"
    if not extra.attach and not extra.bone and pose == "default" and not extra.body_lock and not VCityLVS.HasBodyOffset(extra.attach_offset) then return end

	return pod, base, key, extra
end

---------------------------------------------------------------------------
-- Точка крепления: текущий transform (как GetAttachmentNow в БРДМ,
-- с той же защитой от мусорных данных)
---------------------------------------------------------------------------
local function GetAttachmentNow(base, extra)
    if not istable(extra) then return end
    -- Unconfigured seats use the pelvis position captured before detaching.
    if extra._seatPos and extra._seatAng and not extra.attach and not extra.bone then
        return base:LocalToWorld(extra._seatPos), base:LocalToWorldAngles(extra._seatAng)
    end
	if extra.attach then
		local id = base:LookupAttachment(extra.attach)
		if not isnumber(id) or id <= 0 then return end

		local att = base:GetAttachment(id)
		if not att then return end

		-- защита от мусорных данных (NaN или далеко от корпуса)
		local pos = att.Pos
		if pos.x ~= pos.x or pos.y ~= pos.y or pos.z ~= pos.z then return end
		if pos:DistToSqr(base:GetPos()) > 400 * 400 then return end

		return pos, att.Ang
	end

	if extra.bone then
		local bone = base:LookupBone(extra.bone)
		if not isnumber(bone) or bone < 0 then return end

		local m = base:GetBoneMatrix(bone)
		if not m then return end

		local pos = m:GetTranslation()
		if pos.x ~= pos.x or pos.y ~= pos.y or pos.z ~= pos.z then return end
		if pos:DistToSqr(base:GetPos()) > 400 * 400 then return end

		return pos, m:GetAngles()
	end
end

---------------------------------------------------------------------------
-- Перенос рэгдолла (как MoveRagdollRigid в БРДМ)
---------------------------------------------------------------------------
local function MoveRagdollRigid(ragdoll, pelvisNum, tpos, tang)
	local pelvis = ragdoll:GetPhysicsObjectNum(pelvisNum)
	if not IsValid(pelvis) then return end

	local cpos, cang = pelvis:GetPos(), pelvis:GetAngles()
	local results = {}

	for i = 0, ragdoll:GetPhysicsObjectCount() - 1 do
		local ph = ragdoll:GetPhysicsObjectNum(i)
		if IsValid(ph) then
			local lp, la = WorldToLocal(ph:GetPos(), ph:GetAngles(), cpos, cang)
			local np, na = LocalToWorld(lp, la, tpos, tang)
			results[i] = { np, na }
		end
	end

	for i, r in pairs(results) do
		local ph = ragdoll:GetPhysicsObjectNum(i)
		if IsValid(ph) then
			ph:SetPos(r[1])
			ph:SetAngles(r[2])
			ph:SetVelocityInstantaneous(vector_origin)
			ph:AddAngleVelocity(-ph:GetAngleVelocity())
		end
	end
end

---------------------------------------------------------------------------
-- Якорь (как CreateGunnerAnchor в БРДМ)
---------------------------------------------------------------------------
local function CreateGunnerAnchor(base, pos, ang)
	local anchor = ents.Create("prop_physics")
	if not IsValid(anchor) then return nil end

	anchor:SetModel("models/props_junk/PopCan01a.mdl")
	anchor:SetPos(pos)
	anchor:SetAngles(ang)
	anchor:Spawn()
	anchor:Activate()
	anchor:SetCollisionGroup(COLLISION_GROUP_WORLD)

	if cvDebug:GetBool() then
		anchor:SetNoDraw(false)
		anchor:SetColor(Color(255, 0, 0))
		anchor:SetRenderMode(RENDERMODE_TRANSALPHA)
	else
		anchor:SetNoDraw(true)
	end

	local phys = anchor:GetPhysicsObject()
	if not IsValid(phys) then
		anchor:Remove()
		return nil
	end

	phys:SetMass(50)
	phys:EnableGravity(false)
	phys:EnableDrag(false)

	if cvMode:GetInt() == 1 then
		phys:EnableMotion(false)
	else
		anchor:MakePhysicsObjectAShadow(false, false)
		phys:Wake()
	end

	anchor.VCityLVSMode = cvMode:GetInt()
	ActiveAnchors[anchor] = base
	if IsValid(base) then base:DeleteOnRemove(anchor) end

	return anchor
end

local function PoseAngle(ang, rotate)
    local result = Angle(ang.p, ang.y, ang.r)
    if rotate then result:RotateAroundAxis(result:Right(), 90) end
    return result
end

-- Каждый тик переносим якорь: точка крепления(t) * offset
-- (как BRDM2_GunnerAnchorFollow в БРДМ — с упреждением по скорости)
hook.Add("Tick", "VCityLVS_GunnerAnchorFollow", function()
	for anchor, base in pairs(ActiveAnchors) do
		if not IsValid(anchor) or not IsValid(base) then
			ActiveAnchors[anchor] = nil
			if IsValid(anchor) then anchor:Remove() end
		else
			local apos, aang = GetAttachmentNow(base, anchor.VCityLVSExtra)
			local phys = anchor:GetPhysicsObject()

			if apos and anchor.VCityLVSOffPos and anchor.VCityLVSOffAng and IsValid(phys) then
				local pos, ang = LocalToWorld(anchor.VCityLVSOffPos, anchor.VCityLVSOffAng, apos, aang)
                ang = PoseAngle(ang, anchor.VCityLVSPoseRotate)

				-- Tick идёт ДО шага физики: точка отстаёт от машины на тик,
				-- на скорости это метры. Упреждаем по скорости корпуса.
				local lead = cvLead:GetFloat() * engine.TickInterval()
				if lead > 0 then
					local bphys = base:GetPhysicsObject()
					if IsValid(bphys) then
						pos = pos + bphys:GetVelocityAtPoint(pos) * lead
					end
				end

				if anchor.VCityLVSMode == 1 then
					phys:SetPos(pos)
					phys:SetAngles(ang)
				else
					phys:UpdateShadow(pos, ang, engine.TickInterval())
				end
			end
		end
	end
end)

---------------------------------------------------------------------------
-- Привязка рагдолла (как Detach / Finish / Attach в БРДМ)
---------------------------------------------------------------------------
local function Detach(ragdoll)
	-- Z-City убирает рэгдолл из pod.rags в колбэке "removeOwO". Мы этот колбэк
	-- отключаем (иначе игрока выкинет из машины), значит чистим список сами —
	-- иначе в кресле остаётся «призрак» и fake_enterveh больше не пускает (см. vcity_lvs_enterfix.lua).
	if VCityLVS.ForgetRagdoll then VCityLVS.ForgetRagdoll(ragdoll) end

	-- Старые сварки Z-City (и наши, если это перепривязка). Колбэк "removeOwO"
	-- у Z-City выкидывает игрока из машины при удалении сварки, а Entity:Remove()
	-- откладывает колбэки на конец кадра, поэтому отключаем сам колбэк.
	ragdoll.removingwelds = true
	for _, weld in ipairs(ragdoll.welds or {}) do
		if IsValid(weld) then
			weld:RemoveCallOnRemove("removeOwO")
			weld:Remove()
		end
	end
	ragdoll.welds = nil

	local old = ragdoll.VCityLVSAnchor
	if IsValid(old) then
		ActiveAnchors[old] = nil
		old:Remove()
	end
	ragdoll.VCityLVSAnchor = nil

	timer.Simple(0.5, function()
		if IsValid(ragdoll) then ragdoll.removingwelds = nil end
	end)
end

local function Finish(ragdoll, base, extra, token, sample, requester)
	if not IsValid(ragdoll) or not IsValid(base) then return end
	if ragdoll.VCityLVSToken ~= token then return end -- уже есть более новая перепривязка
    local owner, pod = ragdoll.ply, ragdoll.VCityLVSPod
    if not IsValid(owner) or not IsValid(pod) or owner:GetVehicle() ~= pod then return end

    local function reportFailure(message)
        if IsValid(owner) and owner.ChatPrint then owner:ChatPrint("[V-City LVS] " .. message) end
        if IsValid(requester) and requester ~= owner and requester.ChatPrint then requester:ChatPrint("[V-City LVS] " .. message) end
    end
    local function failSandbox()
        reportFailure("Не удалось привязать тело. Смотрите консоль сервера.")
        if ragdoll.VCityLVSSandbox and not IsValid(ragdoll.VCityLVSAnchor) and VCityLVS.RemoveSandboxRagdoll then
            VCityLVS.RemoveSandboxRagdoll(owner, ragdoll)
        end
    end
	local pinned, pelvisNum = {}, nil
    local hasSpine, hasLeftLeg, hasRightLeg = false, false, false
    local pose = VCityLVS.NormalizeBodyPose and VCityLVS.NormalizeBodyPose(extra.pose) or "default"
	for physNum = 0, ragdoll:GetPhysicsObjectCount() - 1 do
		local boneID = ragdoll:TranslatePhysBoneToBone(physNum)
		if boneID >= 0 then
			local name = ragdoll:GetBoneName(boneID)
            local spine = name == "ValveBiped.Bip01_Spine" or name == "ValveBiped.Bip01_Spine1"
                or name == "ValveBiped.Bip01_Spine2" or name == "ValveBiped.Bip01_Spine3" or name == "ValveBiped.Bip01_Spine4"
            if spine then hasSpine = true end
            if name == "ValveBiped.Bip01_L_Thigh" or name == "ValveBiped.Bip01_L_Calf" then hasLeftLeg = true end
            if name == "ValveBiped.Bip01_R_Thigh" or name == "ValveBiped.Bip01_R_Calf" then hasRightLeg = true end
            if PINNED_BONES[name] or (extra.body_lock and HULL_BONES[name]) or (pose == "lie" and spine) then
                pinned[#pinned + 1] = physNum
            end
			if name == "ValveBiped.Bip01_Pelvis" then pelvisNum = physNum end
		end
	end

	if #pinned == 0 or pelvisNum == nil then
		print("[V-City LVS] Не нашёл кости таза/ног у рагдолла.")
        failSandbox()
		return
	end

    if extra.body_lock and (not hasSpine or not hasLeftLeg or not hasRightLeg) then
        print("[V-City LVS] Модель не имеет физкостей туловища или обеих ног; прежнее крепление сохранено.")
        reportFailure("Не удалось закрепить туловище и ноги: у модели нет подходящих физических костей. Прежнее крепление сохранено.")
        if ragdoll.VCityLVSSandbox and not IsValid(ragdoll.VCityLVSAnchor) and VCityLVS.RemoveSandboxRagdoll then
            VCityLVS.RemoveSandboxRagdoll(owner, ragdoll)
        end
        return
    end

	-- Цель для таза: точка крепления * смещение из конфига
	local apos, aang = GetAttachmentNow(base, extra)
	if not apos then
		dbg("точка крепления не найдена.")
        failSandbox()
		return
	end

	local offPos, offAng = VCityLVS.ParseOffset(extra.attach_offset)
	local tpos, tang = LocalToWorld(offPos, offAng, apos, aang)
    tang = PoseAngle(tang, sample and sample.rotate)

    -- Prepare the new anchor before touching old constraints. All transforms
    -- and welds are then changed within this callback, before the next physics
    -- step; failure restores the previous physics transforms and old welds.
    local anchor = CreateGunnerAnchor(base, tpos, tang)
    if not IsValid(anchor) then
        print("[V-City LVS] Не удалось создать якорь; старые сварки сохранены.")
        failSandbox()
        return
    end
    local oldTransforms = {}
    for i = 0, ragdoll:GetPhysicsObjectCount() - 1 do
        local ph = ragdoll:GetPhysicsObjectNum(i)
        if IsValid(ph) then oldTransforms[i] = {ph:GetPos(), ph:GetAngles(), ph:GetVelocity(), ph:GetAngleVelocity()} end
    end
    local oldParent = ragdoll:GetParent()
    ragdoll:SetParent(NULL) -- PhysObj movements must not fight the old parent.
    if sample then
        -- Position every physics object, not just the rendered model.
        for physNum, transform in pairs(sample.bones) do
            local ph = ragdoll:GetPhysicsObjectNum(physNum)
            if IsValid(ph) then
                local pos, ang = LocalToWorld(transform[1], transform[2], tpos, tang)
                ph:SetPos(pos)
                ph:SetAngles(ang)
                ph:SetVelocityInstantaneous(vector_origin)
                ph:AddAngleVelocity(-ph:GetAngleVelocity())
            end
        end
    else
        MoveRagdollRigid(ragdoll, pelvisNum, tpos, tang)
    end

	anchor.VCityLVSExtra = extra
    anchor.VCityLVSPose = pose
    anchor.VCityLVSPoseRotate = sample and sample.rotate or false
	anchor.VCityLVSOffPos = offPos
	anchor.VCityLVSOffAng = offAng

	local newWelds = {}
	for _, physNum in ipairs(pinned) do
		local weld = constraint.Weld(ragdoll, anchor, physNum, 0, 0, false, false)
		if IsValid(weld) then newWelds[#newWelds + 1] = weld end
	end

	if #newWelds ~= #pinned then
		for _, weld in ipairs(newWelds) do
			if IsValid(weld) then weld:Remove() end
		end
		ActiveAnchors[anchor] = nil
		anchor:Remove()
        ragdoll:SetParent(oldParent or NULL)
        for i, old in pairs(oldTransforms) do
            local ph = ragdoll:GetPhysicsObjectNum(i)
            if IsValid(ph) then
                ph:SetPos(old[1])
                ph:SetAngles(old[2])
                ph:SetVelocityInstantaneous(old[3])
                ph:AddAngleVelocity(old[4] - ph:GetAngleVelocity())
            end
        end
		print("[V-City LVS] Не все сварки создались; старые сварки сохранены.")
        failSandbox()
		return
	end

    Detach(ragdoll)
	if not ragdoll.VCityLVSNoCollided then
		ragdoll.VCityLVSNoCollided = true
		for physNum = 0, ragdoll:GetPhysicsObjectCount() - 1 do
			constraint.NoCollide(ragdoll, base, physNum, 0)
		end
	end

	ragdoll.welds = newWelds
	ragdoll.VCityLVSAnchor = anchor

	dbg("рагдолл привязан к", extra.attach or extra.bone, offPos)

	if not ragdoll.VCityLVSCleanupSet then
		ragdoll.VCityLVSCleanupSet = true
		ragdoll:CallOnRemove("VCityLVS_AnchorCleanup", function()
			local a = ragdoll.VCityLVSAnchor
			if IsValid(a) then
				ActiveAnchors[a] = nil
				a:Remove()
			end
		end)
	end
end

local function CaptureOriginalPose(ragdoll, pelvisPhys)
    local ppos, pang = pelvisPhys:GetPos(), pelvisPhys:GetAngles()
    local bones = {}
    for i = 0, ragdoll:GetPhysicsObjectCount() - 1 do
        local ph = ragdoll:GetPhysicsObjectNum(i)
        if IsValid(ph) then
            local pos, ang = WorldToLocal(ph:GetPos(), ph:GetAngles(), ppos, pang)
            bones[i] = {pos, ang}
        end
    end
    return {bones = bones, rotate = false}
end

local function Attach(ragdoll, base, extra, requester)
    if not IsValid(ragdoll) or not IsValid(base) or not istable(extra) then return false end
    local work = table.Copy(extra)
    local expectedPod = ragdoll.VCityLVSPod
    if not IsValid(expectedPod) then return false end
    local pelvis = ragdoll:LookupBone("ValveBiped.Bip01_Pelvis")
    local physNum = pelvis and ragdoll:TranslateBoneToPhysBone(pelvis) or -1
    local pelvisPhys = physNum >= 0 and ragdoll:GetPhysicsObjectNum(physNum) or nil
    if not IsValid(pelvisPhys) then return false end
    if not ragdoll.VCityLVSOriginalPose then
        ragdoll.VCityLVSOriginalPose = CaptureOriginalPose(ragdoll, pelvisPhys)
        ragdoll.VCityLVSOriginalSeat = {
            pos = base:WorldToLocal(pelvisPhys:GetPos()),
            ang = base:WorldToLocalAngles(pelvisPhys:GetAngles()),
        }
    end
    if not work.attach and not work.bone then
        if work.body_lock and VCityLVS.ValidBodyOrigin(work.body_origin) then
            -- The same vehicle-local reference for every entry and player.
            work._seatPos, work._seatAng = VCityLVS.ParseOffset({work.body_origin.pos, work.body_origin.ang})
        else
            -- Legacy entries without a saved origin retain their previous
            -- behaviour until an admin saves this seat once in the new menu.
            local origin = ragdoll.VCityLVSOriginalSeat
            work._seatPos = origin and origin.pos or base:WorldToLocal(pelvisPhys:GetPos())
            work._seatAng = origin and origin.ang or base:WorldToLocalAngles(pelvisPhys:GetAngles())
        end
    end
    -- Validate before removing the original Z-City welds.
    local pos = GetAttachmentNow(base, work)
    if not pos then
        dbg("точка крепления не найдена; старые сварки сохранены")
        local owner = ragdoll.ply
        if IsValid(owner) and owner.ChatPrint then owner:ChatPrint("[V-City LVS] Точка крепления не найдена; старая поза сохранена.") end
        if IsValid(requester) and requester ~= owner and requester.ChatPrint then requester:ChatPrint("[V-City LVS] Точка крепления не найдена; старая поза сохранена.") end
        if ragdoll.VCityLVSSandbox and not IsValid(ragdoll.VCityLVSAnchor) and VCityLVS.RemoveSandboxRagdoll then
            VCityLVS.RemoveSandboxRagdoll(owner, ragdoll)
        end
        return false
    end
    local pose = VCityLVS.NormalizeBodyPose and VCityLVS.NormalizeBodyPose(work.pose) or "default"
    work.pose = pose
    if not work.attach and not work.bone and pose == "default" and not work.body_lock and not VCityLVS.HasBodyOffset(work.attach_offset) and not IsValid(ragdoll.VCityLVSAnchor) then return false end
    ragdoll.VCityLVSToken = (ragdoll.VCityLVSToken or 0) + 1
    local token = ragdoll.VCityLVSToken
    local function ready(sample, err)
        if not IsValid(ragdoll) or not IsValid(base) or ragdoll.VCityLVSToken ~= token then return end
        local owner = ragdoll.ply
        if not IsValid(owner) or not IsValid(expectedPod) or owner:GetVehicle() ~= expectedPod then return end
        if pose ~= "default" and not sample then
            local message = "Поза не применена: " .. tostring(err) .. ". Старая поза сохранена."
            print("[V-City LVS] " .. message .. " Модель: " .. tostring(ragdoll:GetModel()))
            if owner.ChatPrint then owner:ChatPrint("[V-City LVS] " .. message) end
            if IsValid(requester) and requester ~= owner and requester.ChatPrint then requester:ChatPrint("[V-City LVS] " .. message) end
            if ragdoll.VCityLVSSandbox and not IsValid(ragdoll.VCityLVSAnchor) and VCityLVS.RemoveSandboxRagdoll then
                VCityLVS.RemoveSandboxRagdoll(owner, ragdoll)
                return
            end
            if not IsValid(ragdoll.VCityLVSAnchor) then
                ragdoll.VCityLVSOriginalPose = nil
                ragdoll.VCityLVSOriginalSeat = nil
            end
            return
        end
        -- Do not touch old constraints until the replacement is ready.
        -- Never modify constraints inside the physics callback.
        timer.Simple(0.06, function() Finish(ragdoll, base, work, token, sample, requester) end)
    end
    if pose ~= "default" then
        -- General seated pose; no steering-wheel/driver arm pose.
        VCityLVS.SampleBodyPose(ragdoll, pose, ready, false)
    else
        local original = IsValid(ragdoll.VCityLVSAnchor) and ragdoll.VCityLVSOriginalPose or nil
        timer.Simple(0, function() ready(original) end)
    end
    return true
end

---------------------------------------------------------------------------
-- Точки входа (как хуки в БРДМ)
---------------------------------------------------------------------------
local function OnRagdollCreate(ply, ragdoll)
	if not IsValid(ragdoll) then return end

	local pod, base, _, extra = GetSeatContext(ply)
	if not IsValid(base) or not extra then return end

	-- кресло, в чьём списке rags Z-City держит этот рэгдолл
	ragdoll.VCityLVSPod = pod

	-- Z-City может повторно использовать тот же FakeRagdoll после выхода
	-- из сиденья. Если старый якорь уже очищен, привязываем снова.
	if ragdoll.VCityLVSDefault then
		if not IsValid(ragdoll.VCityLVSAnchor) then
			Attach(ragdoll, base, extra)
		end
		return
	end

	-- Запоминаем, куда Z-City посадила таз (в осях корпуса)
	local pelvisNum
	for physNum = 0, ragdoll:GetPhysicsObjectCount() - 1 do
		local boneID = ragdoll:TranslatePhysBoneToBone(physNum)
		if boneID >= 0 and ragdoll:GetBoneName(boneID) == "ValveBiped.Bip01_Pelvis" then
			pelvisNum = physNum
		end
	end
	if pelvisNum == nil then return end

	local pelvisPhys = ragdoll:GetPhysicsObjectNum(pelvisNum)
	if not IsValid(pelvisPhys) then return end

	ragdoll.VCityLVSDefault = {
		pos = base:WorldToLocal(pelvisPhys:GetPos()),
		ang = base:WorldToLocalAngles(pelvisPhys:GetAngles()),
	}

	Attach(ragdoll, base, extra)
end
VCityLVS.AttachRagdollForSeat = OnRagdollCreate
hook.Add("Ragdoll_Create", "VCityLVS_GunnerSeatRagdollAnchor", OnRagdollCreate)

hook.Add("PlayerLeaveVehicle", "VCityLVS_GunnerSeatAnchorCleanup", function(ply, pod)
	if not IsValid(ply) or not IsValid(pod) then return end

	local ragdoll = ply.FakeRagdoll
	if not IsValid(ragdoll) then return end

    -- Cancel an asynchronous pose sample even if no anchor exists yet.
    if ragdoll.VCityLVSPod == pod then
        ragdoll.VCityLVSToken = (ragdoll.VCityLVSToken or 0) + 1
    end
	-- трогаем только рэгдоллы, с которыми работал якорь
	if not ragdoll.VCityLVSDefault and not IsValid(ragdoll.VCityLVSAnchor) then
        ragdoll.VCityLVSOriginalPose = nil
        ragdoll.VCityLVSOriginalSeat = nil
        return
    end

	ragdoll.VCityLVSToken = (ragdoll.VCityLVSToken or 0) + 1 -- отменяем отложенную привязку
	Detach(ragdoll)
    ragdoll.VCityLVSOriginalPose = nil
    ragdoll.VCityLVSOriginalSeat = nil
end)

---------------------------------------------------------------------------
-- Перепривязка/живая правка из меню «Седалище» (vcity_rp_sidalishe)
---------------------------------------------------------------------------
function VCityLVS.ReattachSeatPlayers(veh, key, requester, forcePose)
	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and ply:InVehicle() then
			local pod = ply:GetVehicle()
			local base = ply.lvsGetVehicle and ply:lvsGetVehicle() or nil
			if IsValid(base) and base == veh then
				local pkey = VCityLVS.SeatKeyByIndex((IsValid(pod) and pod:lvsGetPodIndex()) or 1)
				if pkey == key then
					local entry = VCityLVS.FindVehicleEntry(veh)
					local extra = entry and entry[key] or nil
					local ragdoll = ply.FakeRagdoll
                    local wantsAnchor = istable(extra) and (extra.attach or extra.bone or extra.body_lock or VCityLVS.NormalizeBodyPose(extra.pose) ~= "default" or VCityLVS.HasBodyOffset(extra.attach_offset))
                    if not IsValid(ragdoll) and wantsAnchor and VCityLVS.EnsureSandboxRagdoll then
                        ragdoll = VCityLVS.EnsureSandboxRagdoll(ply, pod, base)
                    elseif IsValid(ragdoll) and ragdoll.VCityLVSSandbox and not wantsAnchor and VCityLVS.RemoveSandboxRagdoll then
                        VCityLVS.RemoveSandboxRagdoll(ply, ragdoll)
                        ragdoll = nil
                    end
                    if IsValid(ragdoll) then
                        ragdoll.VCityLVSPod = pod
                        -- Also cancel an in-flight sample when the new config
                        -- no longer needs an anchor.
                        ragdoll.VCityLVSToken = (ragdoll.VCityLVSToken or 0) + 1
                    end

                    local pose = istable(extra) and VCityLVS.NormalizeBodyPose(extra.pose) or "default"
                    if not istable(extra) and IsValid(ragdoll) and IsValid(ragdoll.VCityLVSAnchor) then extra = {} end
					if IsValid(ragdoll) and istable(extra) and (extra.attach or extra.bone or extra.body_lock or pose ~= "default" or VCityLVS.HasBodyOffset(extra.attach_offset) or IsValid(ragdoll.VCityLVSAnchor)) then
						local anchor = ragdoll.VCityLVSAnchor
                        -- Re-sample and re-weld when the physical pose or attachment changes.
                        local oldExtra = IsValid(anchor) and anchor.VCityLVSExtra or nil
                        local sameTarget = istable(oldExtra) and oldExtra.attach == extra.attach and oldExtra.bone == extra.bone and (oldExtra.body_lock == true) == (extra.body_lock == true)
						if IsValid(anchor) and anchor.VCityLVSPose == pose and sameTarget and not (forcePose and pose ~= "default") then
							-- Живая правка: у якоря меняется только смещение —
							-- тело плавно переедет, без перепривязки (как в БРДМ)
							local offPos, offAng = VCityLVS.ParseOffset(extra.attach_offset)
                            local updated = table.Copy(extra)
                            if not updated.attach and not updated.bone then
                                if updated.body_lock and VCityLVS.ValidBodyOrigin(updated.body_origin) then
                                    updated._seatPos, updated._seatAng = VCityLVS.ParseOffset({updated.body_origin.pos, updated.body_origin.ang})
                                else
                                    updated._seatPos = oldExtra._seatPos
                                    updated._seatAng = oldExtra._seatAng
                                end
                            end
							anchor.VCityLVSExtra = updated
							anchor.VCityLVSOffPos = offPos
							anchor.VCityLVSOffAng = offAng
						else
							Attach(ragdoll, base, extra, requester)
						end
                    elseif IsValid(ragdoll) and not IsValid(ragdoll.VCityLVSAnchor) then
                        ragdoll.VCityLVSOriginalPose = nil
                        ragdoll.VCityLVSOriginalSeat = nil
					end
				end
			end
		end
	end
end

print("[V-City LVS] Якорь тела экипажа подключён (порт схемы БРДМ).")
