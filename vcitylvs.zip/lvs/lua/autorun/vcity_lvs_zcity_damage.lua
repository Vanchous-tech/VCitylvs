--[[---------------------------------------------------------
	V-City LVS ↔ Z-City: урон и организм.

	1. Раневые подсказки. Z-City (homigrad-damage) считает раны
	   по полям инфликтора: Penetration, PenetrationSize, MaxPenLen,
	   BleedMultiplier, PainMultiplier. LVS-стволы этих полей не имеют,
	   и рана считается «вслепую» (pen = урон/2). Мы выставляем поля
	   на LVS-оружие и машины при создании — существующий конвейер
	   Z-City работает как есть, но с честной пробиваемостью.

	2. Сбитие пешехода. Z-City блокирует DMG_CRUSH целиком
	   (анти-гриф от физики), и машину нельзя сбить. Мы ловим
	   заблокированный урон от LVS-техники в PostEntityTakeDamage
	   и заносим его в организм (боль + кровотечение) напрямую —
	   порядок хуков не важен.

	Счётчики — в VCityLVS.Perf (vcity_rp_lvs_perf).
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}
VCityLVS.Perf = VCityLVS.Perf or { fullTicks = 0, throttledTicks = 0, busyTicks = 0 }
VCityLVS.Perf.crushTrauma = VCityLVS.Perf.crushTrauma or 0
VCityLVS.Perf.woundHints = VCityLVS.Perf.woundHints or 0

-- Раневые подсказки для LVS-сущностей (общая логика, тестируется)
-- scale: 1 = пехотное, >1 = крупнокалиберное/техника
function VCityLVS.WoundHints(scale)
	scale = tonumber(scale) or 1
	if scale < 0.2 then scale = 0.2 end
	if scale > 4 then scale = 4 end

	return {
		Penetration = 8 * scale,
		PenetrationSize = 0.4 * scale,
		MaxPenLen = 20 * scale,
		BleedMultiplier = 1.2 * scale,
		PainMultiplier = 1.0 * scale,
	}
end

if SERVER then
	CreateConVar("vcity_rp_lvs_organism", "1", FCVAR_ARCHIVE,
		"Связка LVS-урона с организмом Z-City: раны от стволов и сбития (1/0)")
	-- Z-City считает пробитие как inf.Penetration или (если поля нет) урон/2. Фиксированные
	-- подсказки (6.4 у техники, 12 у стрелков) для мощных снарядов (Bradley и т.п.) СНИЖАЛИ пробитие
	-- ниже штатного, и игроки «танкуют» выстрелы. По умолчанию подсказки пробития выключены.
	CreateConVar("vcity_rp_lvs_wound_pen", "0", FCVAR_ARCHIVE,
		"Фиксированные подсказки пробития для LVS-стволов (1/0). 0 = Z-City считает по урону")
	CreateConVar("vcity_rp_lvs_crush_scale", "1", FCVAR_ARCHIVE,
		"Множитель травмы при сбитии пешехода LVS-техникой")

	local function OrganismEnabled()
		local cv = GetConVar("vcity_rp_lvs_organism")
		return cv and cv:GetBool()
	end

	-- LVS shells use DMG_AIRBOAT for direct hits. The BTR-80A's HE
	-- splash uses DMG_SONIC. Z-City's organism traces bullet/blast
	-- wounds but does not classify those LVS types as either one.
	-- Convert the existing DamageInfo inside Z-City's own pre-damage
	-- hook, before its wound trace. Never issue a second TakeDamageInfo.
	local cvDamageCompat = CreateConVar("vcity_rp_lvs_damage_compat", "1", FCVAR_ARCHIVE,
		"Совместимость прямых попаданий LVS и взрыва БТР-80А с организмом Z-City (1/0)")
	local cvDamageDebug = CreateConVar("vcity_rp_lvs_damage_debug", "0", FCVAR_ARCHIVE,
		"Отладка преобразования урона LVS для организма Z-City (1/0)")

	hook.Add("PreHomigradDamage", "VCityLVS.ProjectileDamageCompat", function(ply, dmginfo, hitgroup, victim)
		if not OrganismEnabled() or not cvDamageCompat:GetBool() then return end
		if not IsValid(victim) or not victim.organism then return end

		local source = dmginfo:GetInflictor()
		if not IsValid(source) then return end
		if not (VCityLVS.IsLVSRelated and VCityLVS.IsLVSRelated(source)) then return end

		local dtype = dmginfo:GetDamageType()
		local kind
		if bit.band(dtype, DMG_AIRBOAT) ~= 0 and bit.band(dtype, DMG_BULLET + DMG_BLAST) == 0 then
			-- Direct hit: retain AIRBOAT for LVS/other addons, add bullet
			-- so Z-City computes penetration, wounds, pain and bleeding.
			dmginfo:SetDamageType(bit.bor(dtype, DMG_BULLET))
			kind = "прямое попадание"
		elseif source:GetClass() == "lvs_wheeldrive_btr80a"
			and bit.band(dtype, DMG_SONIC) ~= 0
			and bit.band(dtype, DMG_BULLET + DMG_BLAST) == 0 then
			-- Only this verified BTR uses SONIC for its HE splash. Keep
			-- SONIC for LVS and add BLAST for Z-City's explosion path.
			dmginfo:SetDamageType(bit.bor(dtype, DMG_BLAST))
			kind = "взрыв БТР-80А"
		end

		if kind and cvDamageDebug:GetBool() then
			print(string.format("[V-City LVS] %s: %s -> %s, урон %.1f, тип %d -> %d",
				kind, source:GetClass(), victim:GetClass(), dmginfo:GetDamage(), dtype, dmginfo:GetDamageType()))
		end
	end)

	-- 1. Раневые подсказки на создаваемые LVS-сущности
	hook.Add("OnEntityCreated", "VCityLVS.WoundHints", function(ent)
		timer.Simple(0, function()
			if not IsValid(ent) then return end

			local class = ent:GetClass()
			if not isstring(class) then return end

			local isGunner = class == "lvs_base_gunner"
			local isVehicle = string.sub(class, 1, 4) == "lvs_"
			if not isGunner and not isVehicle then return end

			-- у машин рана честнее от снаряда, чем от корпуса
			local hints = VCityLVS.WoundHints(isGunner and 1.5 or 0.8)

			local pen = GetConVar("vcity_rp_lvs_wound_pen")
			local usePen = pen and pen:GetBool()

			for key, value in pairs(hints) do
				local isPen = key == "Penetration" or key == "PenetrationSize" or key == "MaxPenLen"
				if ent[key] == nil and (usePen or not isPen) then
					ent[key] = value
				end
			end

			VCityLVS.Perf.woundHints = VCityLVS.Perf.woundHints + 1
		end)
	end)

	-- 2. Сбитие пешехода: Z-City заблокирует DMG_CRUSH — заносим травму сами
	hook.Add("PostEntityTakeDamage", "VCityLVS.CrushTrauma", function(ent, dmginfo, took)
		if not OrganismEnabled() then return end
		if took then return end -- урон прошёл штатно — организм уже всё посчитал

		if not IsValid(ent) or not ent:IsPlayer() or not ent:Alive() then return end

		local dtype = dmginfo:GetDamageType()
		local isCrush = bit.band(dtype, DMG_CRUSH) ~= 0 or bit.band(dtype, DMG_VEHICLE) ~= 0
		if not isCrush then return end

		-- источник должен быть LVS-техникой
		local src = dmginfo:GetAttacker()
		if not IsValid(src) then src = dmginfo:GetInflictor() end
		if not IsValid(src) then return end
		if not (VCityLVS.IsLVSRelated and VCityLVS.IsLVSRelated(src)) then return end

		local org = ent.organism
		if not istable(org) then return end
		if org.godmode then return end

		local damage = dmginfo:GetDamage()
		if damage <= 0 then return end

		local scale = GetConVar("vcity_rp_lvs_crush_scale"):GetFloat()
		local trauma = damage * scale

		-- поля организма используются тем же способом, что и в модулях Z-City
		org.pain = math.min((org.pain or 0) + trauma * 0.4, 255)
		org.internalBleed = math.min((org.internalBleed or 0) + trauma * 0.25, 100)
		org.bleed = math.min((org.bleed or 0) + trauma * 0.02, 20)

		VCityLVS.Perf.crushTrauma = VCityLVS.Perf.crushTrauma + 1
	end)

	print("[V-City LVS] Мост урона с организмом Z-City подключён.")
end
