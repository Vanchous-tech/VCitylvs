--[[---------------------------------------------------------
	V-City LVS ↔ Z-City: мост.

	1. Фейк-рэгдоллы в LVS-технике РАБОТАЮТ — как у Glide:
	   рэгдолл игрока в машине приклеивается к транспорту
	   (fake/sv_tier_0.lua, ragdoll:SetParent(veh:GetParent())).

	2. Тело следует за башней. У LVS-танков экипаж сидит по
	   attachments модели (пример — cl_attached_playermodels.lua
	   Абрамса: "gunner", "comm_seat", "loader", "mg_gunner"),
	   и эти точки ездят вместе с башней (pose-параметры).
	   Если в конфиге кресла указать "attach" — фейк-рэгдолл
	   переносится на кость этой точки и ворочается за башней.

	3. Вид. Z-City и LVS висят на CalcView и конфликтуют
	   («смотрю в одну сторону, башня в другую»). Решение как
	   у Glide (lua/glide/client/camera.lua): финальное слово —
	   хук PostPostHGCalcView, возвращаем вид LVS (расчёт
	   повторяет lvs_framework/autorun/cl_camera.lua, включая
	   LVSCalcView танка с его sight/gunner_eye). Пока игрок
	   без сознания (organism.otrub) — вид не трогаем.

	4. Переключение кресел на ходу — правило Z-City (как у Glide).
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}

-- LVS publishes its own marker on the vehicle base. GetDriverSeat is not
-- unique to LVS and Vehicle metatable methods exist on EVERY Source seat.
local function isBase(ent)
    return IsValid(ent) and ent.LVS == true
end
function VCityLVS.IsLVSSeat(ent)
    if not IsValid(ent) or not isfunction(ent.GetParent) then return false end
    return isBase(ent:GetParent())
end
function VCityLVS.IsLVSRelated(ent)
    if not IsValid(ent) then return false end
    if isBase(ent) then return true end
    local class = isfunction(ent.GetClass) and ent:GetClass() or ""
    if isstring(class) and string.sub(class, 1, 4) == "lvs_" then return true end
    local parent = isfunction(ent.GetParent) and ent:GetParent() or nil
    if isBase(parent) then return true end
    -- LVS parts sometimes have an intermediate owner; do not treat a random
    -- GetDriverSeat method or an unrelated child as proof of LVS ownership.
    local owner = isfunction(ent.GetOwner) and ent:GetOwner() or nil
    return isBase(owner)
end

-- attach_offset из JSON: {{x,y,z},{p,y,r}} -> Vector, Angle (общая логика, тестируется)
function VCityLVS.ParseOffset(data)
    local pos, ang = Vector(0, 0, 0), Angle(0, 0, 0)
    local function triple(t, limit)
        if not istable(t) then return false end
        for i = 1, 3 do
            local n = tonumber(t[i])
            if not n or n ~= n or math.abs(n) > limit then return false end
        end
        return true
    end
    if istable(data) then
        if triple(data[1], 8192) then pos = Vector(tonumber(data[1][1]), tonumber(data[1][2]), tonumber(data[1][3])) end
        if triple(data[2], 36000) then ang = Angle(tonumber(data[2][1]), tonumber(data[2][2]), tonumber(data[2][3])) end
    end
    return pos, ang
end

-- Конвары создаются в ОБЕИХ реальмах (как hg_no_camera_in_cars у Z-City):
-- реплицируемый конвар должен существовать и на клиенте, иначе
-- в клиентской консоли будет «Unknown command».
VCityLVS.cvCamera = ConVarExists("vcity_rp_lvs_zcity_camera") and GetConVar("vcity_rp_lvs_zcity_camera")
	or CreateConVar("vcity_rp_lvs_zcity_camera", "1", FCVAR_ARCHIVE + FCVAR_REPLICATED,
		"Вид в LVS-технике: 1 — камера LVS (как у Glide), 0 — камера Z-City")

VCityLVS.cvRagdollDraw = ConVarExists("vcity_rp_lvs_ragdoll_draw") and GetConVar("vcity_rp_lvs_ragdoll_draw")
	or CreateConVar("vcity_rp_lvs_ragdoll_draw", "1", FCVAR_ARCHIVE + FCVAR_REPLICATED,
		"Рендер своего фейк-рэгдолла в LVS-технике: 1 — показывать, 0 — скрывать")

VCityLVS.cvThirdPerson = ConVarExists("vcity_rp_lvs_thirdperson") and GetConVar("vcity_rp_lvs_thirdperson")
	or CreateConVar("vcity_rp_lvs_thirdperson", "0", FCVAR_ARCHIVE + FCVAR_REPLICATED,
		"Третье лицо в LVS-технике: 0 — только от первого лица (по умолчанию), 1 — разрешить")

-- Блокировка третьего лица в LVS. Флаг живёт на поде
-- (Vehicle:GetThirdPersonMode — API движка), LVS переключает его клавишей
-- THIRDPERSON. Оборачиваем сеттер: пока блокировка включена, флаг всегда false
-- — переключатель не сработает ни у кого.
do
	local vmeta = FindMetaTable("Vehicle")
	if vmeta and not vmeta.__vcityThirdPersonWrapped then
		vmeta.__vcityThirdPersonWrapped = true

		local original = vmeta.SetThirdPersonMode
		if isfunction(original) then
			vmeta.SetThirdPersonMode = function(self, enable)
				local cv = VCityLVS.cvThirdPerson
				if cv and not cv:GetBool() and VCityLVS.IsLVSSeat(self) then
					enable = false
				end
				return original(self, enable)
			end
		end
	end
end

-- Принудительный сброс уже включённого третьего лица (обе реальности)
local function ForceFirstPerson()
	local cv = VCityLVS.cvThirdPerson
	if cv and cv:GetBool() then return end

	for _, ply in ipairs(player.GetAll()) do
		if IsValid(ply) and ply:InVehicle() then
			local pod = ply:GetVehicle()
			if VCityLVS.IsLVSSeat(pod) and pod.GetThirdPersonMode and pod:GetThirdPersonMode() then
				pod:SetThirdPersonMode(false)
			end
		end
	end
end

hook.Add("Tick", "VCityLVS.ForceFirstPerson", ForceFirstPerson)

if SERVER then
	-- Камера (и только камера) — по контракту Z-City/Glide.
	-- Фейк-рэгдоллы НЕ трогаем.
	local function WrapCameraOnly()
		if not istable(hg) or not isfunction(hg.NoCameraInCar) then return end
		if hg.__vcityLvsCameraWrapped then return end
		hg.__vcityLvsCameraWrapped = true

		local original = hg.NoCameraInCar
		hg.NoCameraInCar = function(veh)
			local result = original(veh)
			if result then return result end

			-- камера по машинам/креслам: см. vcity_lvs_camera.lua
			if VCityLVS.IsLVSRelated(veh) and VCityLVS.ResolveCamera(veh) == "lvs" then
				return true
			end

			return false
		end
	end

	hook.Add("Initialize", "VCityLVS.ZCityBridge", function()
		WrapCameraOnly()
	end)

	-- Правило переключения кресел на ходу — копия поведения Glide в Z-City
	hook.Add("LVS.OnPlayerRequestSeatSwitch", "VCityLVS.SlowSeatSwitch", function(ply, vehicle, curPod, pod)
		if not IsValid(ply) then return end

		local host = IsValid(vehicle) and vehicle or (IsValid(curPod) and curPod:GetParent() or NULL)
		if not IsValid(host) then return end

		if host:GetVelocity():LengthSqr() > 256 * 256 and not ply.switchingseat then
			return false
		end
	end)

	-- Тело экипажа: см. vcity_lvs_anchor.lua (схема БРДМ: якорь + сварки)

	print("[V-City LVS] Мост с Z-City подключён (фейк-рэгдоллы активны, вид — камера LVS).")
end

if CLIENT then
	-- Рендер СВОЕГО рэгдолла: кресло > машина > серверный конвар.
	-- Чужие тела не трогаем; вне LVS рэгдолл рисуется как обычно.
    local hiddenRagdoll
    local function restoreRagdoll(rag)
        if IsValid(rag) and rag.VCityLVSHidden then
            rag:SetNoDraw(rag.VCityLVSPreviousNoDraw and true or false)
            rag.VCityLVSHidden = nil
            rag.VCityLVSPreviousNoDraw = nil
        end
    end
	hook.Add("Think", "VCityLVS.RagdollDraw", function()
		local ply = LocalPlayer()
        if not IsValid(ply) then restoreRagdoll(hiddenRagdoll) hiddenRagdoll = nil return end
		local rag = ply.FakeRagdoll
		if not IsValid(rag) and ply.GetNWEntity then rag = ply:GetNWEntity("FakeRagdoll") end
        if not IsValid(rag) and ply.GetNWEntity then rag = ply:GetNWEntity("VCityLVS_SandboxRagdoll") end
        local inLVS = ply:InVehicle() and ply.lvsGetVehicle and IsValid(ply:lvsGetVehicle())
        if hiddenRagdoll ~= rag or not inLVS then
            restoreRagdoll(hiddenRagdoll)
            hiddenRagdoll = nil
        end
        if not IsValid(rag) or not inLVS then return end
        local cv = VCityLVS.cvRagdollDraw
        local show = VCityLVS.ResolveBodyDraw and VCityLVS.ResolveBodyDraw(ply:GetVehicle())
        if not VCityLVS.ResolveBodyDraw then show = (not cv) or cv:GetBool() end
        if not show then
            if not rag.VCityLVSHidden then
                rag.VCityLVSPreviousNoDraw = rag:GetNoDraw()
                rag:SetNoDraw(true)
                rag.VCityLVSHidden = true
            end
            hiddenRagdoll = rag
        else
            restoreRagdoll(rag)
            hiddenRagdoll = nil
        end
	end)

    -- Z-City may render the character and its attachments through
    -- hg.renderOverride, bypassing ordinary player visibility decisions.
    -- Suppress only the local player / its own fake body while in LVS.
    local wrappedRender
    local function InstallOwnBodyRenderFilter()
        if wrappedRender or not istable(hg) or not isfunction(hg.renderOverride) then return wrappedRender end
        local previous = hg.renderOverride
        hg.renderOverride = function(owner, ent, ...)
            local ply = LocalPlayer()
            if IsValid(ply) and ply:InVehicle() and isfunction(ply.lvsGetVehicle)
                and IsValid(ply:lvsGetVehicle()) and isfunction(VCityLVS.ResolveBodyDraw)
                and not VCityLVS.ResolveBodyDraw(ply:GetVehicle()) then
                local rag = ply.FakeRagdoll
                if not IsValid(rag) and ply.GetNWEntity then rag = ply:GetNWEntity("FakeRagdoll") end
                if not IsValid(rag) and ply.GetNWEntity then rag = ply:GetNWEntity("VCityLVS_SandboxRagdoll") end
                if (ent == ply and owner == ply) or (IsValid(rag) and ent == rag) then return end
            end
            return previous(owner, ent, ...)
        end
        wrappedRender = true
        return true
    end
    if not InstallOwnBodyRenderFilter() then
        hook.Add("InitPostEntity", "VCityLVS.OwnBodyRenderFilter", InstallOwnBodyRenderFilter)
        timer.Create("VCityLVS.OwnBodyRenderFilterRetry", 1, 60, function()
            if InstallOwnBodyRenderFilter() then timer.Remove("VCityLVS.OwnBodyRenderFilterRetry") end
        end)
    end

	-- Финальное слово за камерой LVS — по образцу Glide
	-- (lua/glide/client/camera.lua, hook PostPostHGCalcView).
	-- Расчёт повторяет lvs_framework/autorun/cl_camera.lua.
	local function BuildLVSView(ply, view)
		if ply:GetViewEntity() ~= ply then return end

		local pod = ply:GetVehicle()
		local vehicle = ply:lvsGetVehicle()
		if not IsValid(pod) or not IsValid(vehicle) then return end

		local pos, angles, fov = view.origin, view.angles, view.fov
		local newfov = vehicle:LVSCalcFov(fov, ply)

		local base = pod:lvsGetWeapon()

		if IsValid(base) then
			local weapon = base:GetActiveWeapon()

			if base:IsAimVectorUnlocked() then
				angles = ply:EyeAngles()
			end

			if weapon and weapon.CalcView then
				return ply:lvsSetView(weapon.CalcView(base, ply, pos, angles, newfov, pod))
			end

			return ply:lvsSetView(vehicle:LVSCalcView(ply, pos, angles, newfov, pod))
		end

		local weapon = vehicle:GetActiveWeapon()
		if weapon and weapon.CalcView then
			return ply:lvsSetView(weapon.CalcView(vehicle, ply, pos, angles, newfov, pod))
		end

		return ply:lvsSetView(vehicle:LVSCalcView(ply, pos, angles, newfov, pod))
	end

	hook.Add("PostPostHGCalcView", "VCityLVS.CalcView", function(ply, view)
		if not IsValid(ply) then return end

		-- без сознания — вид остаётся за Z-City (голова рэгдолла)
		if ply.organism and ply.organism.otrub then return end

		local vehicle = ply.lvsGetVehicle and ply:lvsGetVehicle()
		if not IsValid(vehicle) then return end

		-- режим камеры для этой машины и этого кресла (конфиг, затем глобальный конвар)
		if VCityLVS.ResolveCamera(ply:GetVehicle()) ~= "lvs" then return end

		return BuildLVSView(ply, view)
	end, HOOK_HIGH)
end
