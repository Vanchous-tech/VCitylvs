-- Operate only the LVS door linked to the player's occupied seat.
if SERVER then AddCSLuaFile() end
VCityLVS = VCityLVS or {}

if SERVER then
    function VCityLVS.ToggleOwnSeatDoor(ply)
        if not IsValid(ply) or not ply:Alive() or not ply:InVehicle() or not isfunction(ply.lvsGetVehicle) then return false, "Вы не в машине LVS." end
        local base, seat = ply:lvsGetVehicle(), ply:GetVehicle()
        if not IsValid(base) or not IsValid(seat) or not isfunction(base.GetDoorHandlers) then return false, "У машины нет системы дверей LVS." end
        if isfunction(seat.GetDriver) and seat:GetDriver() ~= ply then return false, "Вы больше не в этом кресле." end
        if (ply.VCityLVSNextDoor or 0) > CurTime() then return false end
        ply.VCityLVSNextDoor = CurTime() + 0.5
        local selected, distance
        for _, door in pairs(base:GetDoorHandlers() or {}) do
            if IsValid(door) and isfunction(door.GetLinkedSeat) and door:GetLinkedSeat() == seat
                and isfunction(door.GetBase) and door:GetBase() == base and isfunction(door.Use) then
                local d = door:GetPos():DistToSqr(seat:GetPos())
                if not distance or d < distance then selected, distance = door, d end
            end
        end
        if not IsValid(selected) then return false, "К этому креслу не привязана дверь или люк LVS." end
        -- Use the native handler, including its lock/team/permission checks;
        -- never choose a hood, another seat's door, or send a client-picked entity.
        selected:Use(ply, ply)
        return true
    end
    concommand.Add("vcity_lvs_door", function(ply)
        local ok, message = VCityLVS.ToggleOwnSeatDoor(ply)
        if not ok and message and IsValid(ply) then ply:ChatPrint("[V-City LVS] " .. message) end
    end)
    return
end

-- GMod blocks the "bind" console command from Lua even after confirmation.
-- Let players choose a key, copy the resulting command, and execute it
-- themselves. No existing bindings are changed by this menu.
concommand.Add("vcity_lvs_controls", function()
    local frame = vgui.Create("DFrame")
    frame:SetSize(480, 230)
    frame:Center()
    frame:SetTitle("LVS — дверь своего кресла")
    frame:MakePopup()
    local label = vgui.Create("DLabel", frame)
    label:SetPos(16, 32)
    label:SetSize(448, 40)
    label:SetWrap(true)
    label:SetText("Выберите клавишу, скопируйте команду и вставьте её в консоль. Игра не разрешает аддонам менять bind автоматически.")
    local current = vgui.Create("DLabel", frame)
    current:SetPos(16, 75)
    current:SetSize(448, 20)
    current:SetText("Сейчас назначена: " .. tostring(input.LookupBinding("vcity_lvs_door") or "нет"))
    local chosen = vgui.Create("DLabel", frame)
    chosen:SetPos(16, 99)
    chosen:SetSize(448, 20)
    chosen:SetText("Сначала выберите свободную клавишу.")
    local command = vgui.Create("DTextEntry", frame)
    command:SetPos(16, 151)
    command:SetSize(448, 23)
    command:SetEditable(false)
    local binder = vgui.Create("DBinder", frame)
    binder:SetPos(16, 122)
    binder:SetSize(200, 24)
    local copy = vgui.Create("DButton", frame)
    copy:SetPos(16, 184)
    copy:SetSize(200, 26)
    copy:SetText("Копировать команду")
    copy.DoClick = function()
        local text = command:GetValue()
        if isstring(text) and text ~= "" then SetClipboardText(text) end
    end
    binder.OnChange = function(_, code)
        local key = input.GetKeyName(code)
        if not isstring(key) or not string.match(key, "^[%w_]+$") then return end
        local old = input.LookupKeyBinding(code)
        local warning = isstring(old) and old ~= "" and old ~= "vcity_lvs_door"
            and ("Занята: " .. old .. ". Команда заменит привязку!") or "Клавиша свободна или уже назначена двери."
        chosen:SetText(warning)
        command:SetValue('bind "' .. key .. '" "vcity_lvs_door"')
    end
end)
