-- Sandbox fallback when Z-City's fake-ragdoll system is not installed.
-- Z-City retains full ownership of its own ragdolls when it is present.
if SERVER then AddCSLuaFile() end
VCityLVS = VCityLVS or {}

if SERVER then
    local pinned = {
        ["ValveBiped.Bip01_Pelvis"] = true,
        ["ValveBiped.Bip01_L_Thigh"] = true, ["ValveBiped.Bip01_R_Thigh"] = true,
        ["ValveBiped.Bip01_L_Calf"] = true, ["ValveBiped.Bip01_R_Calf"] = true,
    }

    function VCityLVS.RemoveSandboxRagdoll(ply, rag)
        if not IsValid(rag) or not rag.VCityLVSSandbox then return end
        rag.VCityLVSToken = (rag.VCityLVSToken or 0) + 1
        if IsValid(ply) then
            if ply.FakeRagdoll == rag then ply.FakeRagdoll = nil end
            if ply.VCityLVSSandboxRagdoll == rag then ply.VCityLVSSandboxRagdoll = nil end
            if ply:GetNWEntity("VCityLVS_SandboxRagdoll") == rag then
                ply:SetNWEntity("VCityLVS_SandboxRagdoll", NULL)
            end
        end
        rag:Remove()
    end

    function VCityLVS.EnsureSandboxRagdoll(ply, pod, base)
        if not IsValid(ply) or not ply:Alive() or ply:GetVehicle() ~= pod or not IsValid(base) then return nil end
        if IsValid(ply.FakeRagdoll) then return ply.FakeRagdoll end
        if istable(hg) and isfunction(hg.Ragdoll_Create) then return nil end
        local rag = ents.Create("prop_ragdoll")
        if not IsValid(rag) then return nil end
        rag:SetModel(ply:GetModel())
        rag:SetPos(ply:GetPos())
        rag:SetAngles(ply:GetAngles())
        rag:Spawn()
        if not IsValid(rag) or rag:GetPhysicsObjectCount() == 0 then
            if IsValid(rag) then rag:Remove() end
            return nil
        end
        rag.VCityLVSSandbox = true
        rag.ply = ply
        rag.VCityLVSPod = pod
        rag:SetNWEntity("VCityLVS_SandboxOwner", ply)
        rag:SetCollisionGroup(COLLISION_GROUP_WEAPON)
        rag:SetSkin(ply:GetSkin())
        for i = 0, ply:GetNumBodyGroups() - 1 do rag:SetBodygroup(i, ply:GetBodygroup(i)) end
        local welds, hasPelvis = {}, false
        for i = 0, rag:GetPhysicsObjectCount() - 1 do
            local bone = rag:TranslatePhysBoneToBone(i)
            local name = bone and bone >= 0 and rag:GetBoneName(bone) or nil
            if pinned[name] then
                local weld = constraint.Weld(rag, base, i, 0, 0, false, false)
                if IsValid(weld) then
                    welds[#welds + 1] = weld
                    if name == "ValveBiped.Bip01_Pelvis" then hasPelvis = true end
                end
            end
            constraint.NoCollide(rag, base, i, 0)
        end
        if not hasPelvis then
            for _, weld in ipairs(welds) do if IsValid(weld) then weld:Remove() end end
            rag:Remove()
            return nil
        end
        rag.welds = welds
        rag.VCityLVSNoCollided = true
        ply.FakeRagdoll = rag
        ply.VCityLVSSandboxRagdoll = rag
        ply:SetNWEntity("VCityLVS_SandboxRagdoll", rag)
        base:DeleteOnRemove(rag)
        return rag
    end

    hook.Add("PlayerEnteredVehicle", "VCityLVS.SandboxSeatBody", function(ply, pod)
        timer.Simple(0.2, function()
            if not IsValid(ply) or not IsValid(pod) or ply:GetVehicle() ~= pod then return end
            local base = isfunction(ply.lvsGetVehicle) and ply:lvsGetVehicle() or nil
            if not IsValid(base) or not isfunction(pod.lvsGetPodIndex) then return end
            local entry = VCityLVS.FindVehicleEntry(base)
            local key = VCityLVS.SeatKeyByIndex(pod:lvsGetPodIndex())
            local extra = entry and entry[key]
            if not istable(extra) or (not extra.attach and not extra.bone
                and VCityLVS.NormalizeBodyPose(extra.pose) == "default" and not extra.body_lock and not VCityLVS.HasBodyOffset(extra.attach_offset)) then return end
            local rag = VCityLVS.EnsureSandboxRagdoll(ply, pod, base)
            if IsValid(rag) and rag.VCityLVSSandbox and VCityLVS.AttachRagdollForSeat then
                VCityLVS.AttachRagdollForSeat(ply, rag)
            end
        end)
    end)

    local function clearFallback(ply)
        if not IsValid(ply) then return end
        local rag = ply.VCityLVSSandboxRagdoll
        if not IsValid(rag) then rag = ply.FakeRagdoll end
        if IsValid(rag) and rag.VCityLVSSandbox then VCityLVS.RemoveSandboxRagdoll(ply, rag) end
    end
    hook.Add("PlayerLeaveVehicle", "VCityLVS.SandboxSeatBodyLeave", function(ply)
        -- Let anchor/Z-City cleanup hooks finish before deleting the fallback.
        timer.Simple(0, function() clearFallback(ply) end)
    end)
    hook.Add("Ragdoll_Create", "VCityLVS.SandboxYieldToZCity", function(ply, newRagdoll)
        if not IsValid(ply) then return end
        local old = ply.VCityLVSSandboxRagdoll
        if IsValid(old) and old ~= newRagdoll then VCityLVS.RemoveSandboxRagdoll(ply, old) end
    end)
    hook.Add("PlayerDeath", "VCityLVS.SandboxSeatBodyDeath", clearFallback)
    hook.Add("PlayerDisconnected", "VCityLVS.SandboxSeatBodyDisconnect", clearFallback)
    return
end

local function LocalLVS(ply)
    return IsValid(ply) and ply:InVehicle() and isfunction(ply.lvsGetVehicle)
        and IsValid(ply:lvsGetVehicle())
end

hook.Add("PrePlayerDraw", "VCityLVS.SandboxSeatPlayerDraw", function(ply)
    -- The fallback ragdoll replaces the normal seated player for every viewer.
    if IsValid(ply:GetNWEntity("VCityLVS_SandboxRagdoll")) then return true end
    -- For an ordinary Sandbox player without a fake ragdoll, the same per-seat
    -- setting hides the local player's model, never another player's model.
    if ply == LocalPlayer() and LocalLVS(ply) and VCityLVS.ResolveBodyDraw
        and not VCityLVS.ResolveBodyDraw(ply:GetVehicle()) then return true end
end)

hook.Add("ShouldDrawLocalPlayer", "VCityLVS.SandboxSeatSelf", function(ply)
    if not LocalLVS(ply) or IsValid(ply:GetNWEntity("VCityLVS_SandboxRagdoll")) then return end
    if IsValid(ply.FakeRagdoll) or IsValid(ply:GetNWEntity("FakeRagdoll")) then return end
    if VCityLVS.ResolveBodyDraw and VCityLVS.ResolveBodyDraw(ply:GetVehicle()) then return true end
end)

-- LVS camera views normally set drawviewer=false. For a normal Sandbox player
-- with no separate ragdoll, respect the menu choice in the LVS view itself;
-- ShouldDrawLocalPlayer alone can be overridden by that drawviewer flag.
local function InstallSandboxViewVisibility()
    local meta = FindMetaTable("Player")
    if not meta or not isfunction(meta.lvsSetView) then return false end
    if meta.__vcityLvsBodyViewWrapped then return true end
    local previous = meta.lvsSetView
    meta.lvsSetView = function(ply, view, ...)
        local result = previous(ply, view, ...)
        if ply == LocalPlayer() and LocalLVS(ply) and istable(result)
            and not IsValid(ply.FakeRagdoll)
            and not IsValid(ply:GetNWEntity("FakeRagdoll"))
            and not IsValid(ply:GetNWEntity("VCityLVS_SandboxRagdoll"))
            and VCityLVS.ResolveBodyDraw then
            result.drawviewer = VCityLVS.ResolveBodyDraw(ply:GetVehicle())
        end
        return result
    end
    meta.__vcityLvsBodyViewWrapped = true
    return true
end
if not InstallSandboxViewVisibility() then
    hook.Add("InitPostEntity", "VCityLVS.SandboxViewVisibility", function() InstallSandboxViewVisibility() end)
    timer.Create("VCityLVS.SandboxViewVisibilityRetry", 1, 30, function()
        if InstallSandboxViewVisibility() then timer.Remove("VCityLVS.SandboxViewVisibilityRetry") end
    end)
end
