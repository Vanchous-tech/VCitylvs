--[[---------------------------------------------------------
	V-City LVS: оптимизация тика машин.

	Суть: пустые наземные машины (без водителя, пассажиров и AI)
	прокручивают тяжёлую часть тика (физика-эффекты, оружие, щиты,
	OnTick) с пониженной частотой. Полный тик остаётся для всего,
	что занято, и для типов с постоянной физикой (вертолёты, ховеры,
	ходьба) — они НЕ трогаются.

	Типы для прокрутки задаются convar-ом (подстроки через запятую);
	неизвестный тип = полный тик (fail-open).

	Счётчики: vcity_rp_lvs_perf — сколько тиков прокручено и сколько
	полных прошло. Замеры снимай на своём сервере.
-----------------------------------------------------------]]

VCityLVS = VCityLVS or {}
VCityLVS.Perf = VCityLVS.Perf or { fullTicks = 0, throttledTicks = 0, busyTicks = 0 }

-- Решение «можно ли прокрутить тик» — общая логика, тестируется моками
function VCityLVS.ShouldThrottle(vehicleType, hasDriver, hasPassengers, hasAI, pendingWork, initialized)
	if not initialized then return false end
	if hasDriver or hasPassengers or hasAI then return false end
	if pendingWork then return false end
	if not isstring(vehicleType) or vehicleType == "" then return false end

	local list = VCityLVS.ThrottleTypes or ""
	for raw in string.gmatch(list, "[^,]+") do
		local pattern = string.lower(string.match(raw, "^%s*(.-)%s*$") or raw)
		if pattern ~= "" and string.find(string.lower(vehicleType), pattern, 1, true) then
			return true
		end
	end

	return false
end

local function HasPassengers(veh)
    -- Avoid populating LVS's pSeats cache prematurely on clients, before all
    -- children have been transmitted. Inspect currently known child pods.
    local seats = CLIENT and isfunction(veh.GetChildren) and veh:GetChildren() or veh.pSeats
    if istable(seats) then
        for _, pod in ipairs(seats) do
            if IsValid(pod) and isfunction(pod.GetDriver) and IsValid(pod:GetDriver()) then return true end
        end
    end
    return false
end

local function HasPendingWork(veh)
	local t = veh:GetTable()
	return t.MarkForDestruction ~= nil or t._pdsPartsAutoProgress ~= nil
end

if SERVER then
	CreateConVar("vcity_rp_lvs_optimize", "1", FCVAR_ARCHIVE, "Оптимизация тика пустых LVS-машин (1/0)")
	CreateConVar("vcity_rp_lvs_idlehz", "10", FCVAR_ARCHIVE, "Частота полного тика пустых машин, Гц")
	CreateConVar("vcity_rp_lvs_throttle_types", "car,tank,wheeldrive,bike,trailer", FCVAR_ARCHIVE,
		"Типы машин для прокрутки (подстроки через запятую)")

	local function Enabled()
		return GetConVar("vcity_rp_lvs_optimize"):GetBool()
	end

	local function IdleHz()
		return math.Clamp(GetConVar("vcity_rp_lvs_idlehz"):GetInt(), 1, 30)
	end

	-- Обёртка ENT:Think у базового класса: наследники найдут её через цепочку.
	-- Классы, переопределившие Think сами, просто остаются на полном тике (fail-open).
	function VCityLVS.PatchThink()
		local stored = scripted_ents.GetStored("lvs_base")
		local tbl = istable(stored) and stored.t or nil
		if not istable(tbl) then return end
		if tbl.__vcityThinkWrapped then return end
		local oldThink = rawget(tbl, "Think")
		if not isfunction(oldThink) then return end
        tbl.__vcityThinkWrapped = true

		tbl.Think = function(self)
			self:NextThink(CurTime())

			if not Enabled() then
				VCityLVS.Perf.busyTicks = VCityLVS.Perf.busyTicks + 1
				return oldThink(self)
			end

			VCityLVS.ThrottleTypes = GetConVar("vcity_rp_lvs_throttle_types"):GetString()
            local initialized = not isfunction(self.IsInitialized) or self:IsInitialized()
            if not initialized then return oldThink(self) end

			local throttle = VCityLVS.ShouldThrottle(
				self.GetVehicleType and self:GetVehicleType() or "",
				IsValid(self:GetDriver()),
                initialized and HasPassengers(self) or false,
				self.GetAI and self:GetAI() or false,
				HasPendingWork(self),
                initialized
			)

			if not throttle then
				VCityLVS.Perf.busyTicks = VCityLVS.Perf.busyTicks + 1
				return oldThink(self)
			end

			local now = CurTime()
			if now < (self.VCityLVSNextFull or 0) then
				VCityLVS.Perf.throttledTicks = VCityLVS.Perf.throttledTicks + 1
				return true
			end

			self.VCityLVSNextFull = now + 1 / IdleHz()
			VCityLVS.Perf.fullTicks = VCityLVS.Perf.fullTicks + 1

			return oldThink(self)
		end

		print("[V-City LVS] Оптимизация тика подключена.")
	end

	hook.Add("Initialize", "VCityLVS.PatchThink", function()
		VCityLVS.PatchThink()
	end)

	hook.Add("InitPostEntity", "VCityLVS.PatchThinkLate", function()
		VCityLVS.PatchThink()
	end)

	VCityLVS.PatchThink()

	concommand.Add("vcity_rp_lvs_perf", function(ply)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end

		local p = VCityLVS.Perf
		local total = p.fullTicks + p.throttledTicks + p.busyTicks
		local saved = total > 0 and math.Round(p.throttledTicks / total * 100, 1) or 0

		local lines = {
			"[V-City LVS] Счётчики тика:",
			"  полных тиков: " .. p.fullTicks,
			"  прокручено (пустые машины): " .. p.throttledTicks .. " (" .. saved .. "% от всех)",
			"  занятых/без оптимизации: " .. p.busyTicks,
			"  частота пустых: " .. GetConVar("vcity_rp_lvs_idlehz"):GetInt() .. " Гц, типы: " .. GetConVar("vcity_rp_lvs_throttle_types"):GetString(),
		}

		for _, line in ipairs(lines) do
			if IsValid(ply) then
				ply:ChatPrint(line)
			else
				print(line)
			end
		end
	end)

	concommand.Add("vcity_rp_lvs_perf_reset", function(ply)
		if IsValid(ply) and not ply:IsSuperAdmin() then return end
		VCityLVS.Perf = { fullTicks = 0, throttledTicks = 0, busyTicks = 0, crushTrauma = 0, woundHints = 0 }
		if IsValid(ply) then ply:ChatPrint("[V-City LVS] Счётчики обнулены.") end
	end)
end

if CLIENT then
	CreateConVar("vcity_rp_lvs_optimize_cl", "1", FCVAR_ARCHIVE, "Оптимизация клиентского тика пустых LVS-машин (1/0)")
	CreateConVar("vcity_rp_lvs_idlehz_cl", "15", FCVAR_ARCHIVE, "Частота клиентского тика пустых машин, Гц")

	function VCityLVS.PatchThinkClient()
		local stored = scripted_ents.GetStored("lvs_base")
		local tbl = istable(stored) and stored.t or nil
		if not istable(tbl) then return end
		if tbl.__vcityThinkWrappedCL then return end
		local oldThink = rawget(tbl, "Think")
		if not isfunction(oldThink) then return end
        tbl.__vcityThinkWrappedCL = true

		tbl.Think = function(self)
			if not GetConVar("vcity_rp_lvs_optimize_cl"):GetBool() then
				return oldThink(self)
			end

			VCityLVS.ThrottleTypes = "car,tank,wheeldrive,bike,trailer"
            local initialized = not isfunction(self.IsInitialized) or self:IsInitialized()
            if not initialized then return oldThink(self) end

			local throttle = VCityLVS.ShouldThrottle(
				self.GetVehicleType and self:GetVehicleType() or "",
				IsValid(self:GetDriver()),
                initialized and HasPassengers(self) or false,
                self.GetAI and self:GetAI() or false,
                false,
                initialized
			)

			if not throttle then
				return oldThink(self)
			end

			local now = CurTime()
			if now < (self.VCityLVSNextFullCL or 0) then
				return true
			end

			self.VCityLVSNextFullCL = now + 1 / math.Clamp(GetConVar("vcity_rp_lvs_idlehz_cl"):GetInt(), 1, 60)

			return oldThink(self)
		end
	end

	hook.Add("Initialize", "VCityLVS.PatchThinkClient", function()
		VCityLVS.PatchThinkClient()
	end)

	VCityLVS.PatchThinkClient()
end
