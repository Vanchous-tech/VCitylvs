-- V-City LVS: steering-wheel hand posing has been removed.
-- Retained as an inert file so updating the addon replaces the old module.
if SERVER then AddCSLuaFile() end
