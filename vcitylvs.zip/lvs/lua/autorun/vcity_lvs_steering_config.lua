-- Legacy JSON validation only: old wheel data is retained, never used.
if SERVER then AddCSLuaFile() end
VCityLVS = VCityLVS or {}

function VCityLVS.ValidateSteeringTarget(data)
    if not istable(data) or data.mode == "auto" or data.mode == nil then return nil end
    if data.mode ~= "manual" or not istable(data.pos) then return nil end
    local x, y, z, width = tonumber(data.pos[1]), tonumber(data.pos[2]), tonumber(data.pos[3]), tonumber(data.width)
    if not x or not y or not z or not width then return nil end
    if x ~= x or y ~= y or z ~= z or width ~= width then return nil end
    if math.abs(x) > 400 or math.abs(y) > 400 or math.abs(z) > 400 or width < 1 or width > 25 then return nil end
    return {mode = "manual", pos = {math.Round(x, 1), math.Round(y, 1), math.Round(z, 1)}, width = math.Round(width, 1)}
end

