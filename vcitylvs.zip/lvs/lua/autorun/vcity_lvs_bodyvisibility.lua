-- Visibility of the local player's body: seat > vehicle > global convar.
if SERVER then AddCSLuaFile() end
VCityLVS = VCityLVS or {}

function VCityLVS.NormalizeBodyDraw(value)
    if value == "show" or value == "hide" then return value end
    return nil
end

function VCityLVS.PickBodyDraw(seatMode, vehicleMode, globalShow)
    local mode = VCityLVS.NormalizeBodyDraw(seatMode) or VCityLVS.NormalizeBodyDraw(vehicleMode)
    if mode == "show" then return true end
    if mode == "hide" then return false end
    return globalShow and true or false
end

function VCityLVS.ResolveBodyDraw(ent, key)
    local cv = VCityLVS.cvRagdollDraw
    local globalShow = not cv or cv:GetBool()
    local host, podKey = VCityLVS.CamHost(ent)
    key = key or podKey
    if not IsValid(host) then return globalShow end
    local seat = key and host:GetNWString("VCityLVS_Body_" .. key, "") or ""
    return VCityLVS.PickBodyDraw(seat, host:GetNWString("VCityLVS_Body", ""), globalShow)
end

if not SERVER then return end
util.AddNetworkString("vcity_lvs_body_visibility_save")

function VCityLVS.PublishBodyVisibility(veh)
    if not IsValid(veh) or not isfunction(veh.GetDriverSeat) or not VCityLVS.IsLVSRelated(veh) then return end
    local entry = VCityLVS.FindVehicleEntry and VCityLVS.FindVehicleEntry(veh) or nil
    local bodySeats = istable(entry) and istable(entry.body_draw_seats) and entry.body_draw_seats or {}
    veh:SetNWString("VCityLVS_Body", VCityLVS.NormalizeBodyDraw(istable(entry) and entry.body_draw) or "")
    -- Include current, saved and formerly published seats to clear removed overrides.
    local keys = {driver = true}
    for k in pairs(veh.VCityLVSBodyKeys or {}) do keys[k] = true end
    for k in pairs(bodySeats) do
        if isstring(k) and #k <= 16 and VCityLVS.SeatKey(k) == k then keys[k] = true end
    end
    if VCityLVS.ListSeats then
        for _, seat in ipairs(VCityLVS.ListSeats(veh)) do
            if seat.key then keys[seat.key] = true end
        end
    end
    for key in pairs(keys) do
        veh:SetNWString("VCityLVS_Body_" .. key, VCityLVS.NormalizeBodyDraw(bodySeats[key]) or "")
    end
    veh.VCityLVSBodyKeys = keys
end

function VCityLVS.PublishAllBodyVisibility()
    for _, veh in ipairs(ents.GetAll()) do VCityLVS.PublishBodyVisibility(veh) end
end

function VCityLVS.SetBodyVisibility(veh, scope, mode)
    if not IsValid(veh) or not isfunction(veh.GetDriverSeat) or not VCityLVS.IsLVSRelated(veh) then return false end
    if scope ~= nil and (not isstring(scope) or #scope > 16 or VCityLVS.SeatKey(scope) ~= scope) then return false end
    if mode ~= "default" and mode ~= "show" and mode ~= "hide" then return false end
    local entry, configKey = VCityLVS.FindVehicleEntry(veh)
    if not entry then
        configKey = veh:GetClass()
        VCityLVS.SeatConfig.vehicles[configKey] = VCityLVS.SeatConfig.vehicles[configKey] or {}
        entry = VCityLVS.SeatConfig.vehicles[configKey]
    end
    local value = VCityLVS.NormalizeBodyDraw(mode)
    if scope then
        entry.body_draw_seats = istable(entry.body_draw_seats) and entry.body_draw_seats or {}
        entry.body_draw_seats[scope] = value
        if next(entry.body_draw_seats) == nil then entry.body_draw_seats = nil end
    else
        entry.body_draw = value
    end
    VCityLVS.PublishAllBodyVisibility()
    if VCityLVS.SaveSeatConfig then
        local ok, why = VCityLVS.SaveSeatConfig()
        if not ok then return false, why end
    end
    return true
end

net.Receive("vcity_lvs_body_visibility_save", function(_, ply)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end
    local veh = net.ReadEntity()
    if not IsValid(veh) or not isfunction(veh.GetDriverSeat) or not VCityLVS.IsLVSRelated(veh) then return end
    local scope = net.ReadString()
    if scope == "vehicle" then scope = nil
    else
        if #scope > 16 or VCityLVS.SeatKey(scope) ~= scope then return end
    end
    local mode = net.ReadString()
    local ok, why = VCityLVS.SetBodyVisibility(veh, scope, mode)
    if ok then
        ply:ChatPrint("[V-City LVS] Видимость своего тела " .. (scope and ("для " .. scope) or "для машины") .. " сохранена.")
    elseif why then
        ply:ChatPrint("[V-City LVS] Не сохранено: " .. tostring(why) .. " Изменения только в памяти.")
    end
end)

hook.Add("OnEntityCreated", "VCityLVS.PublishBodyVisibility", function(ent)
    timer.Simple(0.1, function() if IsValid(ent) then VCityLVS.PublishBodyVisibility(ent) end end)
end)
hook.Add("InitPostEntity", "VCityLVS.PublishBodyVisibilityInit", function()
    VCityLVS.PublishAllBodyVisibility()
end)
